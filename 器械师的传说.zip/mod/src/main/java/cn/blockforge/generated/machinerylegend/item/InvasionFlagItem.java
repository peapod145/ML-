package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import java.util.List;
import java.util.Map;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.BannerItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;

/**
 * 入侵旗帜：代表着一大波怪物的到来。
 *
 * <p>物品栏里仍然是原来那张平面贴图，手持与放置时则是印着入侵图案的原版红色旗帜，
 * 也能和原版旗帜一样与盾牌合成。
 */
public final class InvasionFlagItem extends BannerItem {
    /** 名字沿用原来的语言键，不跟着方块走。 */
    private static final String DESCRIPTION_ID = "item." + GeneratedMod.MOD_ID + ".invasion_flag";

    public InvasionFlagItem(Block standingBanner, Block wallBanner, Properties properties) {
        super(standingBanner, wallBanner, properties);
    }

    @Override
    public String getDescriptionId() {
        return DESCRIPTION_ID;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip." + GeneratedMod.MOD_ID + ".invasion_flag"));
    }

    @Override
    public void verifyComponentsAfterLoad(ItemStack stack) {
        InvasionFlagPatterns.ensurePattern(stack);
    }

    @Override
    public InteractionResult place(BlockPlaceContext context) {
        // 兜底：万一这面旗帜构造得比图案注册表还早，放置前再补一次。
        InvasionFlagPatterns.ensurePattern(context.getItemInHand());
        return super.place(context);
    }

    @Override
    public void registerBlocks(Map<Block, Item> blockToItem, Item self) {
        // 故意不登记：红色旗帜的“方块→物品”映射必须继续指向原版红色旗帜，
        // 否则拆掉任意一面红色旗帜都会掉出入侵旗帜。
    }
}
