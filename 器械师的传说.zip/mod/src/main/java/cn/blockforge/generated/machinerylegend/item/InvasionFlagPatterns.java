package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BannerPattern;
import net.minecraft.world.level.block.entity.BannerPatternLayers;
import net.neoforged.neoforge.server.ServerLifecycleHooks;

/**
 * 入侵旗帜的图案（数据包注册表 {@code machinery_legend:invasion}）。
 *
 * <p>图案属于数据包注册表，Item.Properties 注册时还拿不到它的 Holder，所以改为在物品堆构造时
 * （{@code Item#verifyComponentsAfterLoad}）补上 {@code minecraft:banner_patterns}。
 * 这样手持/放置/与盾牌合成都直接走原版旗帜那一套流程。
 *
 * <p><b>只在服务端逻辑线程上补图案。</b>数据包注册表在客户端与整合服里各有一份，
 * 同一个键在两份注册表里是两个不同的 {@code Holder} 实例。把客户端的 Holder 塞进服务端的物品堆，
 * 服务端发包（{@code Can't find id for Reference{...}}）和存档（{@code ... is not valid in current
 * registry set}）都会编码失败，玩家退出时直接崩档。客户端的物品堆是服务端同步过去的，本来就已经
 * 带着正确的图案层，不需要也不应该在客户端补。
 */
public final class InvasionFlagPatterns {
    public static final ResourceKey<BannerPattern> INVASION = ResourceKey.create(
            Registries.BANNER_PATTERN, ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "invasion"));
    /** 图案颜色：与物品贴图上的紫色印记一致。 */
    public static final DyeColor COLOR = DyeColor.PURPLE;

    private InvasionFlagPatterns() {}

    /** 给还没有图案的入侵旗帜补上图案；不在服务端逻辑线程上或注册表尚未就绪时静默跳过。 */
    public static void ensurePattern(ItemStack stack) {
        if (stack.isEmpty() || stack.has(DataComponents.BANNER_PATTERNS)) {
            return;
        }
        BannerPatternLayers layers = serverLayers();
        if (layers != null) {
            stack.set(DataComponents.BANNER_PATTERNS, layers);
        }
    }

    /**
     * 取当前服务端注册表里的图案层。
     *
     * <p>{@code isSameThread()} 用来把整合服里的客户端线程排除掉：那种线程上拿到的 Holder
     * 属于客户端注册表，放到服务端物品堆里必定编不出 ID。专用服只有服务端线程，不受影响。
     *
     * @return 当前服务端注册表可用的图案层，客户端线程/注册表未就绪时返回 {@code null}。
     */
    @Nullable
    private static BannerPatternLayers serverLayers() {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || !server.isSameThread()) {
            return null;
        }
        return resolve(server.registryAccess());
    }

    @Nullable
    private static BannerPatternLayers resolve(HolderLookup.Provider provider) {
        if (provider == null) {
            return null;
        }
        return provider.lookup(Registries.BANNER_PATTERN)
                .flatMap(lookup -> lookup.get(INVASION))
                .map(holder -> new BannerPatternLayers(List.of(new BannerPatternLayers.Layer(holder, COLOR))))
                .orElse(null);
    }
}
