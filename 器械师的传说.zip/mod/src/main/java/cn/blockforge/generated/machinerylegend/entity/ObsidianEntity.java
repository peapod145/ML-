package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class ObsidianEntity extends MachineryEntity {
    private static final EntityDataAccessor<Boolean> DATA_EMPOWERED = SynchedEntityData.defineId(ObsidianEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_CRACK_STAGE = SynchedEntityData.defineId(ObsidianEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ARMOR_STAGE = SynchedEntityData.defineId(ObsidianEntity.class, EntityDataSerializers.INT);
    private static final float MAX_SHELL_DAMAGE = 270.0f;
    /** 合金甲与本体都按 180 / 90 两个阈值分三档（护甲与血量上限都是 270）。 */
    private static final float STAGE_HIGH = 180.0f;
    private static final float STAGE_LOW = 90.0f;

    private float shellDamage;

    public ObsidianEntity(EntityType<? extends ObsidianEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.OBSIDIAN.defaultBlockState();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 270.0)
                .add(Attributes.MAX_ABSORPTION, MAX_SHELL_DAMAGE)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.MOVEMENT_SPEED, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_EMPOWERED, false);
        builder.define(DATA_CRACK_STAGE, 0);
        builder.define(DATA_ARMOR_STAGE, 0);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;

        // Keep every visible hostile mob in range focused on this stationary machine.
        // 只对尚未聚焦本器械、且看得到的非敌生物做昂贵的视线检测与目标写入；
        // 已聚焦的目标无需重复射线检测，避免每 tick 对范围内全部敌对生物做视线 raycast。
        level().getEntitiesOfClass(Mob.class, getBoundingBox().inflate(15.0), mob ->
                mob != this && mob.isAlive() && RebellionLogic.canMachineAttack(this, mob))
                .forEach(mob -> {
                    if (mob.getTarget() != this && hasLineOfSight(mob)) {
                        mob.setTarget(this);
                    }
                });
    }

    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        float oldAbsorption = getAbsorptionAmount();
        boolean hurt = super.hurt(source, amount);
        if (!hurt || level().isClientSide) return hurt;

        float absorbedDamage = Math.max(0.0f, oldAbsorption - getAbsorptionAmount());
        if (isEmpowered()) {
            shellDamage = Math.min(MAX_SHELL_DAMAGE, shellDamage + absorbedDamage);
            if (shellDamage >= MAX_SHELL_DAMAGE) {
                setEmpowered(false);
                setAbsorptionAmount(0.0f);
            }
        }

        updateVisualStages();
        return true;
    }

    public boolean isEmpowered() {
        return entityData.get(DATA_EMPOWERED);
    }

    /** 本体裂纹档位：0 无裂纹，1 用第一张破损图（>90 且 <180），2 用第二张破损图（<=90）。 */
    public int getCrackStage() {
        return entityData.get(DATA_CRACK_STAGE);
    }

    /** 合金甲档位：0 完好、1 受损、2 残破，对应三张观察窗侧贴图。 */
    public int getArmorStage() {
        return entityData.get(DATA_ARMOR_STAGE);
    }

    private void setEmpowered(boolean empowered) {
        entityData.set(DATA_EMPOWERED, empowered);
    }

    private void setCrackStage(int stage) {
        entityData.set(DATA_CRACK_STAGE, Math.max(0, Math.min(2, stage)));
    }

    private void setArmorStage(int stage) {
        entityData.set(DATA_ARMOR_STAGE, Math.max(0, Math.min(2, stage)));
    }

    /**
     * 刷新两套外观档位：
     * <ul>
     *   <li>合金甲按<b>剩余护甲值</b>分档，打完就换更残的观察窗侧贴图；</li>
     *   <li>本体裂纹按<b>剩余血量</b>分档——>=180 不叠破损图，低于 180 起随血量换用两张破损图。</li>
     * </ul>
     */
    private void updateVisualStages() {
        setArmorStage(isEmpowered() ? armorStageFor(getAbsorptionAmount()) : 0);
        setCrackStage(crackStageFor(getHealth()));
    }

    /** 合金甲档位：>=180 完好、90~180 受损、<=90 残破。 */
    private static int armorStageFor(float armorHealth) {
        if (armorHealth >= STAGE_HIGH) return 0;
        if (armorHealth > STAGE_LOW) return 1;
        return 2;
    }

    /** 本体裂纹档位：>=180（含满血）无裂纹、90~180 第一张破损图、<=90 第二张破损图。 */
    private static int crackStageFor(float health) {
        if (health >= STAGE_HIGH) return 0;
        if (health > STAGE_LOW) return 1;
        return 2;
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || isEmpowered()) return;
        setHealth(getMaxHealth());
        shellDamage = 0.0f;
        startEvocationEffect();
        setEmpowered(true);
        setAbsorptionAmount(MAX_SHELL_DAMAGE);
        updateVisualStages();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Empowered", isEmpowered());
        tag.putFloat("ShellDamage", shellDamage);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        shellDamage = Math.max(0.0f, Math.min(MAX_SHELL_DAMAGE, tag.getFloat("ShellDamage")));
        boolean empowered = tag.getBoolean("Empowered") && shellDamage < MAX_SHELL_DAMAGE;
        setEmpowered(empowered);
        if (empowered) setAbsorptionAmount(MAX_SHELL_DAMAGE - shellDamage);
        else setAbsorptionAmount(0.0f);
        updateVisualStages();
    }
}
