package cn.blockforge.generated.machinerylegend.entity;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;

import java.util.Optional;

/** 结构中的固定友善村民，保留原版村民的交互和被僵尸攻击行为。 */
public class CheatingVillagerEntity extends Villager {
    public CheatingVillagerEntity(EntityType<? extends Villager> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setCustomNameVisible(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Villager.createAttributes()
                .add(Attributes.MAX_HEALTH, 40.0);
    }

    /**
     * 坑爹村民固定为图书管理员职业，交易不依赖附近是否有工作方块。
     *
     * <p>交易面板会“抽搐一下然后关闭”，根因在原版 {@code Villager} 的两处逻辑：</p>
     * <ul>
     *   <li>{@code customServerAiStep()} 里有
     *       {@code if (getVillagerData().getProfession() == NONE && isTrading()) stopTrading();}。
     *       无业时面板刚打开就会被服务端停止交易，随后
     *       {@code MerchantMenu#stillValid}（{@code getTradingPlayer() == player}）变为 false，
     *       {@code ServerPlayer#tick()} 立刻 {@code closeContainer()}。</li>
     *   <li>光把职业改成图书管理员还不行：核心 AI 里的 {@code ResetProfession} 会在
     *       “无工作方块 + 0 经验 + 1 级”时把职业重置回 {@code NONE}，职业于是每 tick
     *       在两种之间来回跳，{@code setVillagerData} 每次都清空报价，面板抽动更厉害。</li>
     * </ul>
     * <p>因此这里做两件事：职业恒为 {@code LIBRARIAN}，并让经验读数至少为 1（首次交易后
     * 就会累积成真实经验），使 {@code ResetProfession} 的重置条件永远不成立。外观上仍是
     * 原来的图书管理员村民，交易数值、报价与补货规则都未改动。</p>
     */
    @Override
    public void tick() {
        super.tick();
        if (getVillagerData().getProfession() != VillagerProfession.LIBRARIAN) {
            setVillagerData(getVillagerData().setProfession(VillagerProfession.LIBRARIAN));
        }
        if (!level().isClientSide && getVillagerXp() <= 0) {
            // 只挡 ResetProfession 的 “0 经验” 判定；真实交易经验照常累加，显示几乎无差别。
            setVillagerXp(1);
        }
    }

    @Override
    public int getPlayerReputation(Player player) {
        // 本实体不参与原版声望折扣或加价计算。
        return 0;
    }

    @Override
    public MerchantOffers getOffers() {
        MerchantOffers offers = super.getOffers();
        // 已保存的空列表不会再次触发原版 updateTrades；这里保证交互时始终有本实体的交易。
        if (offers.isEmpty()) {
            updateTrades();
            return this.offers;
        }

        // 存档读取后报价会还原成原版 MerchantOffer，重新包装后可继续保持固定价格。
        for (int index = 0; index < offers.size(); index++) {
            MerchantOffer offer = offers.get(index);
            if (!(offer instanceof FixedPriceMerchantOffer)) {
                offers.set(index, FixedPriceMerchantOffer.from(offer));
            }
        }
        // 老存档里已存在的村民可能没有这条新交易，缺则补上，保证星之碎片流程可用。
        boolean hasShardUpgrade = false;
        for (MerchantOffer offer : offers) {
            if (offer.getResult().is(GeneratedMod.SHARD_SLOT_UPGRADE.get())) {
                hasShardUpgrade = true;
                break;
            }
        }
        if (!hasShardUpgrade) {
            offers.add(createShardSlotUpgradeOffer());
        }
        return offers;
    }

    /** 16 个钻石换取 1 个碎片槽位升级。 */
    private static FixedPriceMerchantOffer createShardSlotUpgradeOffer() {
        return new FixedPriceMerchantOffer(
                new ItemCost(Items.DIAMOND, 16),
                Optional.empty(),
                new ItemStack(GeneratedMod.SHARD_SLOT_UPGRADE.get()),
                12, 1, 0.05f, 0);
    }

    @Override
    public boolean shouldShowName() {
        return false;
    }

    @Override
    public void overrideOffers(MerchantOffers offers) {
        this.offers = offers;
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = new MerchantOffers();
        // 20 个绿宝石 + 1 个动力矿车，按村民交易机制限量并可补货。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 20),
                Optional.of(new ItemCost(Items.FURNACE_MINECART)),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.POWERED_CART.get()),
                12, 1, 0.05f, 0));
        // 40 个绿宝石 + 1 把铁锄，换取 1 个器械钉耙。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 40),
                Optional.of(new ItemCost(Items.IRON_HOE)),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.MACHINERY_RAKE.get()),
                12, 1, 0.05f, 0));
        // 64 个绿宝石 + 1 个奥格拉斯的机械臂，换取 1 个狙击发射器蓝图。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 64),
                Optional.of(new ItemCost(cn.blockforge.generated.machinerylegend.GeneratedMod.MECHANICAL_ARM.get())),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.SNIPER_EMITTER_BLUEPRINT.get()),
                12, 1, 0.05f, 0));
        // 64 个绿宝石 + 1 个小型发射器蓝图，换取 1 个传染发射器蓝图。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 64),
                Optional.of(new ItemCost(cn.blockforge.generated.machinerylegend.GeneratedMod.SMALL_EMITTER_BLUEPRINT.get())),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.INFECTENSER_BLUEPRINT.get()),
                12, 1, 0.05f, 0));
        // 16 个钻石，换取 1 个碎片槽位升级。
        offers.add(createShardSlotUpgradeOffer());
        overrideOffers(offers);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide()) {
            // 交易前再兜一次底：职业必须是非 NONE 且经验非 0，否则原版 AI 会在下一 tick
            // 因“无业”或 ResetProfession 把交易停掉，面板随即被服务端关闭。
            if (getVillagerData().getProfession() == VillagerProfession.NONE) {
                setVillagerData(getVillagerData().setProfession(VillagerProfession.LIBRARIAN));
            }
            if (getVillagerXp() <= 0) {
                setVillagerXp(1);
            }
            // 先生成自定义交易，避免无业状态下原版村民因交易为空而不打开界面。
            if (getOffers().isEmpty()) {
                updateTrades();
            }
            setTradingPlayer(player);
            openTradingScreen(player, Component.translatable("entity.machinery_legend.cheating_villager"), 1);
        }
        return InteractionResult.sidedSuccess(level().isClientSide());
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }
}
