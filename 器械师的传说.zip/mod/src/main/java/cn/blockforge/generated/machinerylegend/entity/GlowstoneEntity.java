package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import java.util.List;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import org.joml.Vector3f;

/**
 * 荧石器械：静止不动、不会攻击，外观与原版荧石方块一致。
 * 像荧石一样发出 15 级光并照亮周围方块；被下界之星激发潜能后发出强光，
 * 使以自身为中心半径 15 格内的敌对生物获得 5 秒缓慢 VIII、挖掘疲劳 V、失明与虚弱 VIII，
 * 并在受影响生物头顶浮现类似晕眩效果的粒子，随后恢复常态。
 */
public class GlowstoneEntity extends MachineryEntity {
    private static final double DEBUFF_RANGE = 15.0;
    private static final int DEBUFF_DURATION_TICKS = 5 * 20;
    private static final int SLOWNESS_AMPLIFIER = 7;
    private static final int DIG_SLOWDOWN_AMPLIFIER = 4;
    private static final int BLINDNESS_AMPLIFIER = 0;
    private static final int WEAKNESS_AMPLIFIER = 7;
    /** 晕眩计时同步到客户端，由客户端本地生成粒子，不依赖服务端粒子包。 */
    private static final EntityDataAccessor<Integer> DATA_DIZZY_TICKS =
            SynchedEntityData.defineId(GlowstoneEntity.class, EntityDataSerializers.INT);
    /** 晕眩光点：暖白色尘埃粒子，白天与暗处都清晰可见。 */
    private static final DustParticleOptions DIZZY_POINT =
            new DustParticleOptions(new Vector3f(1.0f, 0.95f, 0.66f), 1.25f);
    /** 每只受影响生物头顶每刻生成的光点数（绕头旋转，彼此相差半圈）。 */
    private static final int DIZZY_POINTS_PER_TICK = 2;
    private static final double DIZZY_RING_RADIUS = 0.42;
    /** 跟着本体走的一格隐形光照方块（15 级）。 */
    private final BodyLightTracker light = new BodyLightTracker(this, GeneratedMod.GLOWSTONE_LIGHT.get());

    public GlowstoneEntity(EntityType<? extends GlowstoneEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_DIZZY_TICKS, 0);
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.GLOWSTONE.defaultBlockState();
    }

    /** 潜能的眩晕余韵还剩多少刻；客户端据此渲染头顶光点。 */
    public int getDizzyTicks() {
        return entityData.get(DATA_DIZZY_TICKS);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            // 晕眩光点在客户端本地生成：只要同步的计时还活着就一定会画出来，
            // 不再依赖服务端粒子包，修复"游戏内看不到"的问题。
            tickClientDizzyParticles();
        } else {
            light.update();
            int dizzyTicks = getDizzyTicks();
            if (dizzyTicks > 0) entityData.set(DATA_DIZZY_TICKS, dizzyTicks - 1);
        }
    }

    @Override
    public void onRemovedFromLevel() {
        light.clear();
        super.onRemovedFromLevel();
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide) return;
        startEvocationEffect();
        spawnEmpowerLightParticles();
        entityData.set(DATA_DIZZY_TICKS, DEBUFF_DURATION_TICKS);
        List<LivingEntity> affected = level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(DEBUFF_RANGE), entity ->
                        entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity));
        affected.forEach(enemy -> {
            enemy.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,
                    DEBUFF_DURATION_TICKS, SLOWNESS_AMPLIFIER, true, false, true));
            enemy.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN,
                    DEBUFF_DURATION_TICKS, DIG_SLOWDOWN_AMPLIFIER, true, false, true));
            enemy.addEffect(new MobEffectInstance(MobEffects.BLINDNESS,
                    DEBUFF_DURATION_TICKS, BLINDNESS_AMPLIFIER, true, false, true));
            enemy.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,
                    DEBUFF_DURATION_TICKS, WEAKNESS_AMPLIFIER, true, false, true));
        });
        // 激发潜能与施加效果均为瞬时脉冲，本体随即恢复常态。
    }

    /**
     * 客户端每刻在范围内敌对生物的头顶生成一圈缓慢旋转的晕眩光点，
     * 直到同步的 5 秒计时结束、目标死亡或离开范围。
     */
    private void tickClientDizzyParticles() {
        if (getDizzyTicks() <= 0) return;
        List<LivingEntity> targets = level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(DEBUFF_RANGE),
                entity -> entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity));
        if (targets.isEmpty()) return;

        for (LivingEntity target : targets) {
            // 每只生物用自身 id 错开相位，避免所有光点整齐划一地同步旋转。
            float phase = tickCount * 0.22f + target.getId() * 0.7f;
            double headY = target.getY() + target.getBbHeight() + 0.3;
            for (int i = 0; i < DIZZY_POINTS_PER_TICK; i++) {
                double angle = phase + i * Math.PI;
                level().addParticle(DIZZY_POINT,
                        target.getX() + Math.cos(angle) * DIZZY_RING_RADIUS,
                        headY + Math.sin(angle * 2.0) * 0.08,
                        target.getZ() + Math.sin(angle) * DIZZY_RING_RADIUS,
                        0.0, 0.015, 0.0);
            }
            // 偶尔补一颗更亮的星点，强化"晕眩冒星星"的观感。
            if (tickCount % 4 == 0) {
                level().addParticle(ParticleTypes.END_ROD,
                        target.getX(), headY + 0.14, target.getZ(), 0.0, 0.02, 0.0);
            }
        }
    }

    private void spawnEmpowerLightParticles() {
        if (!(level() instanceof ServerLevel serverLevel)) return;
        serverLevel.sendParticles(ParticleTypes.END_ROD,
                getX(), getY() + getBbHeight() * 0.5, getZ(),
                80, getBbWidth() * 0.8, getBbHeight() * 0.8, getBbWidth() * 0.8, 0.10);
    }
}
