package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.SoulforgeFireballEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * 炽炎弹：用户提供的 16×16 火焰贴图做成始终面向玩家的面片，自发光渲染（FULL_BRIGHT），
 * 夜晚与暗处同样刺眼。
 * <p>尺寸修正：贴图里火焰剪影实测只占画布的 87.5%（14/16 像素、居中），面片尺寸按
 * 覆盖率反推。当前本体可见火焰恰好为 3/4 个方块表面（面片 0.75 ÷ 0.875 ≈ 0.857 格），
 * 每分裂一代仍缩到上一代的 2/3（一代可见 0.5 格、二代可见 0.375 格）。</p>
 * <p>本类只画本体一层，不再叠加黄色发光层：黄光渲染已按用户要求取消，弹体只保留
 * 贴图本身的颜色与 FULL_BRIGHT 自发光。</p>
 */
public class SoulforgeFireballRenderer extends EntityRenderer<SoulforgeFireballEntity> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/projectile/soulforge_fireball.png");
    private static final RenderType RENDER_TYPE = RenderType.entityCutoutNoCull(TEXTURE);
    /** 本体顶点色：不染色。 */
    private static final int BASE_COLOR = 0xFFFFFFFF;
    /** 贴图 alpha 实测：火焰剪影占画布 14/16 = 87.5%，四周约 12.5% 是透明边距。 */
    private static final float TEXTURE_COVERAGE = 0.875f;
    /** 本体可见火焰的目标尺寸：3/4 个方块表面。 */
    private static final float VISIBLE_BASE_SIZE = 0.75f;
    /** 面片边长 = 目标可见尺寸 ÷ 贴图覆盖率 ≈ 0.857 格；半宽/半高即其一半。 */
    private static final float HALF_SIZE = VISIBLE_BASE_SIZE / TEXTURE_COVERAGE / 2.0f;

    public SoulforgeFireballRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0f;
    }

    @Override
    public void render(SoulforgeFireballEntity entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        // 面片中心略抬高，避免贴图底边切进地面。
        poseStack.translate(0.0, 0.06, 0.0);
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
        float scale = entity.getRenderScale();
        poseStack.scale(scale, scale, scale);
        VertexConsumer consumer = buffer.getBuffer(RENDER_TYPE);
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        vertex(consumer, matrix, pose, -HALF_SIZE, HALF_SIZE, 0.0f, 0.0f, BASE_COLOR);
        vertex(consumer, matrix, pose, HALF_SIZE, HALF_SIZE, 1.0f, 0.0f, BASE_COLOR);
        vertex(consumer, matrix, pose, HALF_SIZE, -HALF_SIZE, 1.0f, 1.0f, BASE_COLOR);
        vertex(consumer, matrix, pose, -HALF_SIZE, -HALF_SIZE, 0.0f, 1.0f, BASE_COLOR);
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, light);
    }

    private static void vertex(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose,
                               float x, float y, float u, float v, int color) {
        consumer.addVertex(matrix, x, y, 0.0f)
                .setColor(color)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0.0f, 0.0f, 1.0f);
    }

    @Override
    public ResourceLocation getTextureLocation(SoulforgeFireballEntity entity) {
        return TEXTURE;
    }
}
