package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * 入侵旗帜的客户端渲染。
 *
 * <p>物品栏（{@link ItemDisplayContext#GUI}）沿用原来那张平面贴图；其余场合——手持、掉落物、
 * 展示框、怪物手上的旗帜——都交给原版旗帜渲染器，画出带入侵图案的红色旗帜。
 */
public final class InvasionFlagRenderer extends BlockEntityWithoutLevelRenderer {
    /**
     * 物品栏图标模型：{@code assets/machinery_legend/models/item/invasion_flag_icon.json}。
     *
     * <p>1.21.1 只为「已注册物品」烘焙 {@code models/item/*.json}，这里没有名为 invasion_flag_icon
     * 的物品，所以必须由 {@link ClientEvents#registerAdditionalModels} 显式登记成追加模型，
     * 否则 {@code ModelManager#getModel} 只会返回 MissingModel，物品栏里就是紫黑马赛克。
     * id 里的 {@code item/} 前缀不能省——登记时平台就是拿它当模型文件路径去加载的。
     *
     * <p>变体必须是 {@code standalone}：{@code ModelEvent.RegisterAdditional#register} 会断言
     * 「侧载模型必须使用 standalone 变体」，用 {@code inventory} 变体会在烘焙时直接抛
     * IllegalArgumentException，把整局资源重载连同模组加载一起打断（上一版崩溃即为此）。
     * 取用时 {@link #ICON_MODEL} 与服务端登记的是同一个值，{@code ModelManager#getModel} 能命中。
     */
    public static final ModelResourceLocation ICON_MODEL = ModelResourceLocation.standalone(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "item/invasion_flag_icon"));

    public InvasionFlagRenderer(BlockEntityRenderDispatcher dispatcher, EntityModelSet modelSet) {
        super(dispatcher, modelSet);
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext context, PoseStack pose,
                             MultiBufferSource buffer, int light, int overlay) {
        if (context == ItemDisplayContext.GUI) {
            renderIcon(stack, pose, buffer, light, overlay);
        } else {
            Minecraft.getInstance().getItemRenderer().getBlockEntityRenderer()
                    .renderByItem(stack, context, pose, buffer, light, overlay);
        }
    }

    /** 复刻 {@link ItemRenderer} 里渲染普通物品的那条分支，只是绕开自定义渲染器。 */
    private static void renderIcon(ItemStack stack, PoseStack pose, MultiBufferSource buffer, int light, int overlay) {
        Minecraft minecraft = Minecraft.getInstance();
        ItemRenderer itemRenderer = minecraft.getItemRenderer();
        BakedModel model = minecraft.getModelManager().getModel(ICON_MODEL);
        for (BakedModel pass : model.getRenderPasses(stack, true)) {
            for (RenderType type : pass.getRenderTypes(stack, true)) {
                VertexConsumer consumer = ItemRenderer.getFoilBufferDirect(buffer, type, true, stack.hasFoil());
                itemRenderer.renderModelLists(pass, stack, light, overlay, pose, consumer);
            }
        }
    }
}
