package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.ThrowingKnifeEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

/**
 * 飞刀：蓄力投掷武器，手感向"随手甩出"靠拢。
 * 长按右键蓄力，但不再有最短蓄力门槛——无论按住多久，松手即掷出（轻点也能立刻甩出）；
 * 蓄力越久初速越高，1 秒（20 tick）即蓄满，蓄力不增加伤害。
 * 基础初速 2.0、满蓄力 3.2，弹道比过去更平直，落点更贴近准星。
 * 第三人称持握形式与铁剑等工具一致（模型 display 走 handheld 的第三人称变换），
 * 第一人称与物品栏图标保持原样。
 */
public class ThrowingKnifeItem extends Item {
    /** 蓄力满程：1.0 秒 = 20 tick，之后初速不再提升。 */
    private static final int MAX_CHARGE_TICKS = 20;
    /** 未蓄力时的初速：轻点即掷也有足够射程。 */
    private static final float MIN_SPEED = 2.0F;
    /** 蓄力带来的额外初速：满蓄力时总初速 MIN_SPEED + SPEED_BONUS。 */
    private static final float SPEED_BONUS = 1.2F;

    public ThrowingKnifeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.SPEAR;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        // 与三叉戟相同：不自动结束使用，只在松手时结算。
        return 72000;
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof Player player)) {
            return;
        }
        // 没有最低蓄力门槛：usedTicks 可以为 0（同一刻点下又松开），照样掷出。
        int usedTicks = Math.max(0, this.getUseDuration(stack, entity) - timeLeft);
        player.awardStat(Stats.ITEM_USED.get(this));
        if (level.isClientSide) {
            return;
        }
        // 蓄力比例 0（轻点）到 1（满 1 秒），初速 2.0~3.2：蓄力越久投得越远、弹道越平。
        float ratio = Math.min(usedTicks, MAX_CHARGE_TICKS) / (float) MAX_CHARGE_TICKS;
        ThrowingKnifeEntity knife = new ThrowingKnifeEntity(GeneratedMod.THROWING_KNIFE_PROJECTILE.get(), level);
        knife.setPos(player.getX(), player.getEyeY() - 0.1D, player.getZ());
        knife.setOwner(player);
        knife.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, MIN_SPEED + SPEED_BONUS * ratio, 0.0F);
        if (player.hasInfiniteMaterials()) {
            knife.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
        }
        level.addFreshEntity(knife);
        level.playSound(null, knife, SoundEvents.TRIDENT_THROW.value(), SoundSource.PLAYERS, 1.0F, 1.25F);
        if (!player.hasInfiniteMaterials()) {
            stack.shrink(1);
        }
    }
}
