package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Shulker;
import net.minecraft.world.entity.projectile.ShulkerBullet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;

public abstract class MachineryEntity extends Mob {
    public static final int EVOCATION_EFFECT_TICKS = 40;
    /** 器械被潜影贝命中时施加的漂浮时长（3 秒）；原版固定 200 刻（10 秒），这里按用户要求缩短。 */
    private static final int SHULKER_LEVITATION_TICKS = 20 * 3;
    private static final EntityDataAccessor<Integer> DATA_EVOCATION_TICKS = SynchedEntityData.defineId(MachineryEntity.class, EntityDataSerializers.INT);
    private boolean deathParticlesSpawned;
    protected MachineryEntity(EntityType<? extends Mob> type, Level level) {
        super(type, level);
        setNoGravity(false);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 20.0).add(Attributes.KNOCKBACK_RESISTANCE, 1.0).add(Attributes.MOVEMENT_SPEED, 0.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_EVOCATION_TICKS, 0);
    }

    /**
     * 潜影贝命中器械时，把原版施加的 10 秒漂浮缩短为 3 秒。
     *
     * <p>原版 {@code ShulkerBullet.onHitEntity} 固定用
     * {@code new MobEffectInstance(MobEffects.LEVITATION, 200)} 施加漂浮，
     * 并把“主人（潜影贝）或弹体本身”作为施加者传进来；器械没有血肉，用户要求挨潜影贝时
     * 只漂浮 3 秒。这里只改潜影贝来源、且只改漂浮这一种状态，其余状态与来源一律原样透传，
     * 因此不影响反逆、机器寄染等任何其他效果。</p>
     */
    @Override
    public boolean addEffect(MobEffectInstance effectInstance, Entity source) {
        if (effectInstance != null && effectInstance.is(MobEffects.LEVITATION)
                && (source instanceof Shulker || source instanceof ShulkerBullet)) {
            effectInstance = new MobEffectInstance(MobEffects.LEVITATION, SHULKER_LEVITATION_TICKS,
                    effectInstance.getAmplifier(), effectInstance.isAmbient(), effectInstance.isVisible(),
                    effectInstance.showIcon());
        }
        return super.addEffect(effectInstance, source);
    }

    @Override
    protected void registerGoals() {
        // 器械固定在原地，索敌逻辑由各器械的 tick 自主驱动。
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            int effectTicks = getEvocationEffectTicks();
            if (effectTicks > 0) entityData.set(DATA_EVOCATION_TICKS, effectTicks - 1);
        }
        // 器械不主动移动，但保留原版重力带来的垂直位移。
        setDeltaMovement(new Vec3(0.0, getDeltaMovement().y, 0.0));
        if (!level().isClientSide) {
            if (tickCount % 5 == 0) {
                if (hasOffensiveCapability()) {
                    LivingEntity target = findTarget();
                    if (target != null) {
                        setTarget(target);
                        lookAt(target, 360.0f, 360.0f);
                    } else {
                        setTarget(null);
                    }
                } else if (getTarget() != null) {
                    // 没有攻击能力的器械生物（熔炉、月光传感器、荧石、黑曜石等）
                    // 不对敌对生物保持仇恨：清空目标，也不再转头注视。
                    setTarget(null);
                }
            }
        }
    }

    /**
     * 是否具备攻击能力。具备攻击能力的器械（各类发射器、地雷TNT）保留索敌与仇恨；
     * 没有攻击能力的器械不应对敌对生物保持仇恨，默认视为无攻击能力。
     */
    protected boolean hasOffensiveCapability() {
        return false;
    }

    @Override
    public void move(MoverType type, Vec3 movement) {
        // 锁定水平位移，同时让原版重力和落地碰撞处理垂直位移。
        super.move(type, new Vec3(0.0, movement.y, 0.0));
    }

    @Override
    public void push(Entity entity) {
        // 防止实体碰撞把器械推离放置位置。
    }

    @Override
    public void push(Vec3 movement) {
        // 防止外力把器械推离放置位置。
    }

    @Override
    public boolean shouldShowName() {
        return false;
    }

    /**
     * 返回这台器械主体占比最高的材质，用于受伤与死亡时的方块破坏粒子。
     */
    protected BlockState getDeathParticleState() {
        return Blocks.IRON_BLOCK.defaultBlockState();
    }

    /** 返回器械对应的主体方块状态，供拆除时复用原版方块音效。 */
    public final BlockState getMachineryBlockState() {
        return getDeathParticleState();
    }

    /**
     * 拆除（器械铁镐右击收回）时播放的音效：默认 null，沿用主体方块材质的破坏声；
     * 个别器械（如冲击活塞）在此挂上用户提供的专属采样。
     */
    public net.minecraft.sounds.SoundEvent getRemovalSound() {
        return null;
    }

    /**
     * 受伤音效：器械没有血肉，被打时改播它主体方块被挖掘/破坏时的材质声
     * （与铁镐拆除时用的 {@code getBreakSound()} 同一套声音，例如发射器就是木石混合声）。
     */
    @Override
    protected net.minecraft.sounds.SoundEvent getHurtSound(net.minecraft.world.damagesource.DamageSource source) {
        return getDeathParticleState().getSoundType().getBreakSound();
    }

    /**
     * 死亡音效：与受伤/拆除同一套材质声——器械死亡时播放它主体方块被破坏时的声音，
     * 替换掉原版生物通用的死亡叫声。所有器械子类共用这一份实现。
     */
    @Override
    protected net.minecraft.sounds.SoundEvent getDeathSound() {
        return getDeathParticleState().getSoundType().getBreakSound();
    }

    /**
     * 受伤反馈：器械没有血肉，每次真正吃到伤害时溅出一小片它主体方块的破坏粒子
     * （石头/木头/铁块等，和受伤音效用的是同一套材质）。致死的这一次不再重复溅射，
     * 由 {@link #spawnDeathParticles()} 统一给一大片。
     */
    @Override
    public boolean hurt(net.minecraft.world.damagesource.DamageSource source, float amount) {
        boolean damaged = super.hurt(source, amount);
        if (damaged && isAlive() && !level().isClientSide) {
            spawnHurtParticles();
        }
        return damaged;
    }

    @Override
    public void die(net.minecraft.world.damagesource.DamageSource source) {
        if (!level().isClientSide && !isRemoved() && !deathParticlesSpawned) {
            deathParticlesSpawned = true;
            spawnDeathParticles();
        }
        super.die(source);
    }

    /** 受伤时溅出的一小片主体方块碎屑（比死亡时少，作为挨打的即时反馈）。 */
    public final void spawnHurtParticles() {
        if (!(level() instanceof ServerLevel serverLevel)) return;
        BlockParticleOption particles = new BlockParticleOption(ParticleTypes.BLOCK, getDeathParticleState());
        serverLevel.sendParticles(particles, getX(), getY() + getBbHeight() * 0.5, getZ(),
                12, getBbWidth() * 0.55, getBbHeight() * 0.4, getBbWidth() * 0.55, 0.12);
    }

    public final void spawnDeathParticles() {
        if (!(level() instanceof ServerLevel serverLevel)) return;
        BlockParticleOption particles = new BlockParticleOption(ParticleTypes.BLOCK, getDeathParticleState());
        serverLevel.sendParticles(particles, getX(), getY() + getBbHeight() * 0.5, getZ(),
                64, getBbWidth() * 0.8, getBbHeight() * 0.6, getBbWidth() * 0.8, 0.18);
    }

    /** 默认索敌半径（格）。 */
    protected static final double DEFAULT_TARGET_SEARCH_RANGE = 15.0;

    protected LivingEntity findTarget() {
        return findTarget(DEFAULT_TARGET_SEARCH_RANGE, false);
    }

    /**
     * 搜索最近的敌对生物。{@code circularRange} 为 true 时把方形搜索盒裁剪成半径
     * {@code range} 的圆形区域，供小型/狙击发射器复用。
     */
    protected LivingEntity findTarget(double range, boolean circularRange) {
        LivingEntity nearest = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity candidate : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(range), entity ->
                entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity)
                        && (!circularRange || distanceToSqr(entity) <= range * range)
                        && hasLineOfSight(entity))) {
            double distance = distanceToSqr(candidate);
            if (distance < best) {
                best = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    /** 水平朝向向量（忽略俯仰），供各发射器计算枪口与弹道方向。 */
    protected Vec3 horizontalForward() {
        float yaw = getYRot() * ((float) Math.PI / 180.0f);
        return new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw)).normalize();
    }

    /**
     * 器械攻击不受目标当前无敌帧影响；伤害仍由原版 LivingEntity.hurt 处理。
     */
    protected final boolean hurtIgnoringInvulnerability(LivingEntity target,
                                                          net.minecraft.world.damagesource.DamageSource source,
                                                          float amount) {
        clearInvulnerabilityForMachineryAttack(target);
        return target.hurt(source, amount);
    }

    /** 小型发射器、狙击发射器共用的开火音效（用户提供的 Bow 采样）。 */
    protected void playBowShot() {
        level().playSound(null, blockPosition(), GeneratedMod.BOW_SHOT.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
    }

    static void clearInvulnerabilityForMachineryAttack(LivingEntity target) {
        target.invulnerableTime = 0;
    }

    public void triggerEmpowered() {
        startEvocationEffect();
    }

    protected final void startEvocationEffect() {
        if (!level().isClientSide) entityData.set(DATA_EVOCATION_TICKS, EVOCATION_EFFECT_TICKS);
    }

    public final int getEvocationEffectTicks() {
        return entityData.get(DATA_EVOCATION_TICKS);
    }
}
