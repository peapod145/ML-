package cn.blockforge.generated.machinerylegend.entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 器械生物“冲击活塞”（血量 20，外观为侧放的原版活塞、活塞头朝向视野方向，大小与碰撞箱同黑曜石器械）：
 * <ul>
 *   <li>视野：半径 15 格（继承 MachineryEntity 的索敌，见 findTarget）；</li>
 *   <li>攻击（群体）：任一怪物进入平面半径 3.5 格即触发，活塞头沿视野方向弹出，
 *       圈内所有带视线的怪物各受 10 点虚空伤害并被朝外击退约 2 格（本轮减半）；
 *       被击中的怪物会把冲击活塞记为攻击者并主动仇恨它；</li>
 *   <li>攻击后活塞头掉落消失（纯视觉，配合方块粒子），只剩石头部分露出活塞孔，冷却 20 秒，
 *       期间活塞头从活塞孔中慢慢重新生长；</li>
 *   <li>下界之星激发潜能：活塞头立刻恢复（取消弹出动画与生长冷却），随后朝面朝方向伸出并延展 10 格活塞臂
 *       （延长的是臂而不是头），沿路怪物受到一次 35 点虚空伤害并被持续推开；
 *       臂推出到收回期间锁定朝向，不再跟随目标自由转向；</li>
 *   <li>击退增伤：目标击退抗性 ≥50% 时，每高出 1% 击退抗性，本次伤害 +10%。</li>
 * </ul>
 */
public final class PunchPistonEntity extends MachineryEntity {
    /** 活塞头冷却：20 秒（400 tick），期间活塞头从活塞孔中缓慢重新生长。 */
    public static final int RECHARGE_TICKS = 400;
    /** 普通攻击的活塞弹出动画时长。 */
    public static final int THRUST_TOTAL_TICKS = 6;
    /** 激发潜能后活塞臂动画总时长：10 tick 快速推出 + 25 tick 保持 + 15 tick 收回。 */
    public static final int ARM_TOTAL_TICKS = 50;
    public static final int ARM_EXTEND_TICKS = 10;
    public static final int ARM_HOLD_END_TICKS = 35;
    public static final double ARM_LENGTH = 10.0;

    private static final float STRIKE_DAMAGE = 10.0f;
    private static final float ARM_DAMAGE = 35.0f;
    /** 普通攻击的平面触发距离：3.5 格（本轮从 4 格回调）。 */
    private static final double STRIKE_RANGE = 3.5;
    private static final double STRIKE_RANGE_SQR = STRIKE_RANGE * STRIKE_RANGE;
    /**
     * 击退初速度与滑行距离的折算：普通生物落地后水平速度每 tick 约乘 0.546（0.6 摩擦 ×0.91），
     * 总滑行距离 ≈ v/(1-0.546) ≈ 2.2v，故 1.8 ≈ 4 格。
     */
    /** 普通攻击的击退初速度：本轮减半（1.8 → 0.9），滑行距离由约 4 格变为约 2 格。 */
    private static final double STRIKE_KNOCKBACK_SPEED = 0.9;
    private static final double STRIKE_KNOCKBACK_LIFT = 0.19;
    /** 激发潜能活塞臂的持续推开：强度保持原样（约 4 格折算），不受本轮减半影响。 */
    private static final double ARM_KNOCKBACK_SPEED = 1.8;
    private static final double ARM_KNOCKBACK_LIFT = 0.38;

    private static final EntityDataAccessor<Boolean> DATA_HEAD_PRESENT =
            SynchedEntityData.defineId(PunchPistonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_RECHARGE_TICKS =
            SynchedEntityData.defineId(PunchPistonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_THRUST_TICKS =
            SynchedEntityData.defineId(PunchPistonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ARM_TICKS =
            SynchedEntityData.defineId(PunchPistonEntity.class, EntityDataSerializers.INT);

    /** 本轮活塞臂已经命中过的生物：单次激发内每只怪只结算一次伤害，但持续被推开。 */
    private final Set<UUID> armHits = new HashSet<>();

    public PunchPistonEntity(EntityType<? extends PunchPistonEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.PISTON.defaultBlockState();
    }

    /** 拆除（器械铁镐收回）音效：用户提供的第二个采样。 */
    @Override
    public SoundEvent getRemovalSound() {
        return GeneratedMod.PUNCH_PISTON_REMOVE.get();
    }

    /** 死亡音效：继承基类，播放主体方块（活塞，石质）被破坏的声音。 */

    /** 冲击活塞有攻击能力：保留基类的索敌（半径 15、带视线）与转头。 */
    @Override
    protected boolean hasOffensiveCapability() {
        return true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_HEAD_PRESENT, true);
        builder.define(DATA_RECHARGE_TICKS, 0);
        builder.define(DATA_THRUST_TICKS, 0);
        builder.define(DATA_ARM_TICKS, 0);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;

        int thrust = entityData.get(DATA_THRUST_TICKS);
        if (thrust > 0) {
            if (thrust == 1) loseHead();
            entityData.set(DATA_THRUST_TICKS, thrust - 1);
        }

        int arm = entityData.get(DATA_ARM_TICKS);
        if (arm > 0) {
            // 推出与保持阶段沿路结算；收回阶段臂已退出怪物身位，不再推人。
            if (ARM_TOTAL_TICKS - arm < ARM_HOLD_END_TICKS) sweepArm();
            entityData.set(DATA_ARM_TICKS, arm - 1);
        }

        if (!isHeadPresent()) {
            int recharge = entityData.get(DATA_RECHARGE_TICKS);
            if (recharge <= 1) {
                entityData.set(DATA_RECHARGE_TICKS, 0);
                entityData.set(DATA_HEAD_PRESENT, true);
                playSound(SoundEvents.PISTON_EXTEND, 0.7f, 1.45f);
            } else {
                entityData.set(DATA_RECHARGE_TICKS, recharge - 1);
            }
        } else if (thrust == 0 && arm == 0) {
            List<LivingEntity> targets = findStrikeTargets();
            if (!targets.isEmpty()) strike(targets);
        }
    }

    /**
     * 平面半径 3.5 格内、带视线的**全部**怪物（群体伤害：一次弹出同时命中入圈的每一只，不再只挑最近的一个）。
     * 虚空伤害无视护甲，这里不做额外判定；筛选条件与单体版完全一致，只是不再取最小距离。
     */
    private List<LivingEntity> findStrikeTargets() {
        List<LivingEntity> targets = new ArrayList<>();
        for (LivingEntity candidate : level().getEntitiesOfClass(LivingEntity.class,
                getBoundingBox().inflate(STRIKE_RANGE),
                entity -> entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity))) {
            double dx = candidate.getX() - getX();
            double dz = candidate.getZ() - getZ();
            if (dx * dx + dz * dz > STRIKE_RANGE_SQR || !hasLineOfSight(candidate)) continue;
            targets.add(candidate);
        }
        return targets;
    }

    /**
     * 弹出活塞头：对范围内所有目标立即各结算一次伤害与击退（群体伤害），动画走完（6 tick）后活塞头掉落进入 20 秒冷却。
     * 伤害、击退抗性增伤与冷却节奏都和原来一致，只是由"一只"变成"一圈"，且击退距离减半（约 4 格 → 约 2 格）；
     * 每只怪各按自己相对活塞的方向被推开，而不是统一朝视野方向。激发潜能活塞臂的推开强度不变。
     */
    private void strike(List<LivingEntity> targets) {
        for (LivingEntity target : targets) {
            hurtIgnoringInvulnerability(target, level().damageSources().fellOutOfWorld(),
                    resistanceScaledDamage(target, STRIKE_DAMAGE));
            provoke(target);
            Vec3 dir = strikeKnockbackDir(target);
            applyKnockback(target, dir.x, dir.z, STRIKE_KNOCKBACK_SPEED, STRIKE_KNOCKBACK_LIFT);
        }
        entityData.set(DATA_THRUST_TICKS, THRUST_TOTAL_TICKS);
        playSound(GeneratedMod.PUNCH_PISTON_PUNCH.get(), 1.0f, 1.1f);
    }

    /**
     * 让被活塞打中的怪物把活塞记成攻击者并开始仇恨它。
     *
     * <p>活塞的伤害走的是 {@code fellOutOfWorld}（虚空伤害，无视护甲），这个伤害源没有
     * 攻击者实体，原版就没有机会把活塞写进 {@code lastHurtByMob}，怪物自然不还手。
     * 这里补上原版挨打时该做的那一步：先写 {@code lastHurtByMob}（HurtByTargetGoal 靠它
     * 维持仇恨），再直接把目标指向活塞，保证没有该 Goal 的怪物也会反击。</p>
     */
    private void provoke(LivingEntity target) {
        target.setLastHurtByMob(this);
        if (target instanceof Mob mob && mob.getTarget() != this) {
            mob.setTarget(this);
        }
    }

    /** 单个目标的击退方向：由活塞指向目标；目标恰好与活塞重合时退回视野朝向（与单体版处理相同）。 */
    private Vec3 strikeKnockbackDir(LivingEntity target) {
        double dx = target.getX() - getX();
        double dz = target.getZ() - getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 1.0e-3) {
            Vec3 look = horizontalLook();
            return new Vec3(look.x, 0.0, look.z);
        }
        return new Vec3(dx / length, 0.0, dz / length);
    }

    /** 活塞头打完掉落：只留下石头部分（侧面贴图），开始 20 秒生长冷却，并撒一片活塞头方块碎块。 */
    private void loseHead() {
        entityData.set(DATA_HEAD_PRESENT, false);
        entityData.set(DATA_RECHARGE_TICKS, RECHARGE_TICKS);
        playSound(SoundEvents.PISTON_CONTRACT, 1.0f, 0.85f);
        if (level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.PISTON_HEAD.defaultBlockState()),
                    getX(), getY() + 0.95, getZ(), 18, 0.38, 0.08, 0.38, 0.12);
        }
    }

    /** 下界之星激发潜能：活塞头立刻恢复（取消弹出动画与生长冷却），再朝面朝方向推出一条 10 格活塞臂，
     * 沿路怪物被一次 35 点虚空伤害并持续推开。 */
    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || entityData.get(DATA_ARM_TICKS) > 0) return;
        armHits.clear();
        startEvocationEffect();
        // 活塞头立刻恢复：若正在弹出动画中则直接归位，若处于 20 秒生长冷却则马上长回，不再等冷却走完。
        entityData.set(DATA_THRUST_TICKS, 0);
        entityData.set(DATA_RECHARGE_TICKS, 0);
        entityData.set(DATA_HEAD_PRESENT, true);
        entityData.set(DATA_ARM_TICKS, ARM_TOTAL_TICKS);
        playSound(GeneratedMod.PUNCH_PISTON_PUNCH.get(), 1.0f, 0.65f);
    }

    /**
     * 激发潜能期间（活塞臂推出到收回的全程）不能自由转向：忽略基类每 5 tick 一次的跟随目标转头，
     * 活塞臂沿激发瞬间的面朝方向扫出；臂收回后转头照旧。
     */
    @Override
    public void lookAt(Entity target, float yMaxRot, float xMaxRot) {
        if (entityData.get(DATA_ARM_TICKS) > 0) return;
        super.lookAt(target, yMaxRot, xMaxRot);
    }

    /** 活塞臂每 tick 的沿路判定：臂是过中心轴向面朝方向（模型 -Z）伸出的盒子。 */
    private void sweepArm() {
        Vec3 look = horizontalLook();
        double originX = getX();
        double originY = getY() + 0.6;
        double originZ = getZ();
        double endX = originX + look.x * (ARM_LENGTH + 0.6);
        double endZ = originZ + look.z * (ARM_LENGTH + 0.6);
        AABB beam = new AABB(originX, originY - 0.65, originZ, endX, originY + 0.65, endZ).inflate(0.75);
        for (LivingEntity target : level().getEntitiesOfClass(LivingEntity.class, beam,
                entity -> entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity)
                        && entity.getBoundingBox().intersects(beam))) {
            if (armHits.add(target.getUUID())) {
                hurtIgnoringInvulnerability(target, level().damageSources().fellOutOfWorld(),
                        resistanceScaledDamage(target, ARM_DAMAGE));
            }
            provoke(target);
            applyKnockback(target, look.x, look.z, ARM_KNOCKBACK_SPEED, ARM_KNOCKBACK_LIFT);
        }
    }

    /**
     * 击退抗性增伤：目标击退抗性（属性值 ×100%）≥50% 时，每高出 1% 伤害 +10%。
     * 例：50% 不加成，75% 为 3.5 倍，100% 为 6 倍；石像鬼的 500% 抗性按 46 倍结算。
     */
    private static float resistanceScaledDamage(LivingEntity target, float baseDamage) {
        double resistancePercent = target.getAttributeValue(Attributes.KNOCKBACK_RESISTANCE) * 100.0;
        if (resistancePercent < 50.0) return baseDamage;
        return (float) (baseDamage * (1.0 + (resistancePercent - 50.0) * 0.1));
    }

    /** 直接写速度实现固定击退（绕过原版抗性公式——高抗性怪物改由伤害加成补偿）。 */
    private static void applyKnockback(LivingEntity target, double dirX, double dirZ,
                                       double speed, double lift) {
        Vec3 motion = target.getDeltaMovement();
        target.setDeltaMovement(dirX * speed, Math.max(motion.y, lift), dirZ * speed);
        target.hurtMarked = true;
    }

    private Vec3 horizontalLook() {
        Vec3 look = getLookAngle();
        Vec3 flat = new Vec3(look.x, 0.0, look.z);
        return flat.lengthSqr() < 1.0e-6 ? new Vec3(0.0, 0.0, 1.0) : flat.normalize();
    }

    // ---- 供渲染器读取的同步状态 ----

    public boolean isHeadPresent() {
        return entityData.get(DATA_HEAD_PRESENT);
    }

    public int getRechargeTicks() {
        return entityData.get(DATA_RECHARGE_TICKS);
    }

    public int getThrustTicks() {
        return entityData.get(DATA_THRUST_TICKS);
    }

    public int getArmTicks() {
        return entityData.get(DATA_ARM_TICKS);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("HeadPresent", isHeadPresent());
        tag.putInt("RechargeTicks", entityData.get(DATA_RECHARGE_TICKS));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(DATA_HEAD_PRESENT, tag.getBoolean("HeadPresent"));
        entityData.set(DATA_RECHARGE_TICKS, Math.max(0, Math.min(RECHARGE_TICKS, tag.getInt("RechargeTicks"))));
    }
}
