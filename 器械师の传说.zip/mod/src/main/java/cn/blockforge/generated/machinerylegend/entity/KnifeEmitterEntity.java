package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * 飞刀发射器：血量 20，碰撞箱、视野、攻击逻辑与攻击角度均与发射器相同（继承 EmitterEntity 的
 * 索敌、平射、提前量瞄准与 28 tick 冷却），只是把射出的箭换成飞刀——伤害规则与玩家投掷的飞刀一致，
 * 但不可回收，且射出 15 秒后消失。白天不睡觉（与发射器一样没有睡眠机制）。
 * 下界之星激发潜能：在攻击范围内选取至多 10 个敌人，以各自碰撞箱中心为圆心凝聚悬浮的飞刀圈
 * （圈半径已调大：最小 1.9 格），3 秒后飞刀朝圆心射入，每把造成与普通飞刀相同的伤害且无视目标
 * 无敌帧，并且只与敌对生物结算命中（玩家与中立/友好生物直接穿过）；分到的飞刀总数至多 60 把，
 * 被选中的敌人 4 秒内无法移动（255 级缓速把移动速度乘算到 0）。
 * 常规射击射出的飞刀同样只与敌对生物结算命中：飞行途中径直穿过其他器械生物、玩家等所有友军，
 * 不会被友军挡下；只有玩家自己投掷的飞刀保留"可命中一切生物"的原版表现。
 * 常规射击与飞刀圈的飞刀都不带弹道下坠：关闭重力后按瞄准方向直线飞行，出膛速度不变。
 */
public class KnifeEmitterEntity extends EmitterEntity {
    private static final EntityDataAccessor<String> DATA_RING_STATE =
            SynchedEntityData.defineId(KnifeEmitterEntity.class, EntityDataSerializers.STRING);

    private static final int RING_CHARGE_TICKS = 60;      // 飞刀圈悬浮 3 秒后射出
    private static final int RING_LOCK_TICKS = 80;        // 被选中的敌人 4 秒内无法移动
    private static final int RING_MAX_TARGETS = 10;
    private static final int RING_TOTAL_KNIVES = 60;      // 分配到的飞刀总数上限
    private static final float RING_KNIFE_SPEED = 2.6F;
    private static final int KNIFE_LIFETIME_TICKS = 300;  // 射出的飞刀 15 秒后消失
    private static final double ATTACK_RANGE = 15.0;      // 与发射器的索敌/射程一致

    /** 单个目标的飞刀圈计划：目标实体 id、圈半径、把数。渲染端从同步字符串里解析同一份数据。 */
    private record RingPlan(int targetId, double radius, int knives) {}

    private final List<RingPlan> pendingRings = new ArrayList<>();
    private int ringCountdown;

    public KnifeEmitterEntity(EntityType<? extends KnifeEmitterEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_RING_STATE, "");
    }

    /** 飞刀圈同步状态："targetId,radius,knives;…"，空串表示当前没有凝聚中的飞刀圈。 */
    public String getRingState() {
        return entityData.get(DATA_RING_STATE);
    }

    private void setRingState(String value) {
        entityData.set(DATA_RING_STATE, value);
    }

    @Override
    public void tick() {
        // 发射器同款主循环：平射、15 格视野、28 tick 冷却，performRangedAttack 已被替换为飞刀。
        super.tick();
        if (level().isClientSide) return;
        if (pendingRings.isEmpty()) {
            // 存档重载后倒计时不保留：若同步串还挂着圈状态则立即清掉，避免客户端残留虚影。
            if (!getRingState().isEmpty()) setRingState("");
            return;
        }
        if (--ringCountdown > 0) return;
        fireRings();
    }

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        Vec3 forward = horizontalForward();
        Vec3 start = new Vec3(getX(), getY() + MUZZLE_Y_OFFSET, getZ()).add(forward.scale(MUZZLE_FORWARD_OFFSET));
        Vec3 aim = calculateAim(target, start, velocity);
        ThrowingKnifeEntity knife = newLauncherKnife();
        knife.setPos(start);
        knife.shoot(aim.x, aim.y, aim.z, ARROW_SPEED * Math.max(velocity, 0.1f), ARROW_INACCURACY);
        level().addFreshEntity(knife);
    }

    /** 器械射出的飞刀：伤害规则同玩家飞刀，但不可回收，15 秒后消失。 */
    private ThrowingKnifeEntity newLauncherKnife() {
        ThrowingKnifeEntity knife = new ThrowingKnifeEntity(GeneratedMod.THROWING_KNIFE_PROJECTILE.get(), level());
        knife.setOwner(this);
        knife.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
        knife.setExpireTicks(KNIFE_LIFETIME_TICKS);
        // 器械射出的飞刀不带弹道下坠：关闭重力后沿瞄准方向直线飞行，出膛速度不变。
        // 一旦被弹开（盾牌格挡等），ThrowingKnifeEntity#onDeflection 会重新打开重力，反弹后正常下坠。
        knife.setNoGravity(true);
        // 器械生物的攻击不与友军结算：飞行途中径直穿过其他器械生物、玩家与中立/友好生物，
        // 只与敌对生物（Enemy）碰撞，不会被挡在友军身上停住；玩家自己投掷的飞刀不受影响。
        knife.setOnlyHitsHostile(true);
        return knife;
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || !pendingRings.isEmpty()) return;
        List<LivingEntity> targets = new ArrayList<>();
        for (LivingEntity candidate : level().getEntitiesOfClass(LivingEntity.class,
                getBoundingBox().inflate(ATTACK_RANGE), entity ->
                        entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity) && hasLineOfSight(entity))) {
            targets.add(candidate);
        }
        if (targets.isEmpty()) return;
        targets.sort(Comparator.comparingDouble(this::distanceToSqr));
        if (targets.size() > RING_MAX_TARGETS) {
            targets = new ArrayList<>(targets.subList(0, RING_MAX_TARGETS));
        }

        startEvocationEffect();
        // 60 把飞刀在至多 10 个目标间平均分配，余数分给最近的几个目标。
        int base = RING_TOTAL_KNIVES / targets.size();
        int remainder = RING_TOTAL_KNIVES % targets.size();
        StringBuilder state = new StringBuilder();
        for (int i = 0; i < targets.size(); i++) {
            LivingEntity target = targets.get(i);
            int knives = base + (i < remainder ? 1 : 0);
            // 半径随把数增大，保证相邻飞刀之间约 0.6 格的间距；外形尺寸已整体调大。
            double radius = Math.max(1.9, knives * 0.6 / (2.0 * Math.PI));
            pendingRings.add(new RingPlan(target.getId(), radius, knives));
            if (!state.isEmpty()) state.append(';');
            state.append(target.getId()).append(',').append(radius).append(',').append(knives);
            // 255 级缓速（不显示图标与粒子）把移动速度乘算到 0，4 秒内无法移动。
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, RING_LOCK_TICKS, 255, true, false));
        }
        ringCountdown = RING_CHARGE_TICKS;
        setRingState(state.toString());
    }

    /** 3 秒蓄力结束：每把飞刀从自己所在的圈上位置朝圆心（目标碰撞箱中心）射入。 */
    private void fireRings() {
        for (RingPlan plan : pendingRings) {
            if (!(level().getEntity(plan.targetId()) instanceof LivingEntity target) || !target.isAlive()) continue;
            double centerX = target.getX();
            double centerY = target.getY() + target.getBbHeight() * 0.5;
            double centerZ = target.getZ();
            for (int i = 0; i < plan.knives(); i++) {
                double angle = i * 2.0 * Math.PI / plan.knives();
                Vec3 point = new Vec3(centerX + plan.radius() * Math.cos(angle), centerY,
                        centerZ + plan.radius() * Math.sin(angle));
                Vec3 direction = new Vec3(centerX, centerY, centerZ).subtract(point).normalize();
                ThrowingKnifeEntity knife = newLauncherKnife();
                // 飞刀圈的飞刀与普通飞刀伤害一致（不再双倍），无视目标无敌帧，
                // 保证圈上的每一把都能各自结算伤害。
                knife.setIgnoresInvulnerability(true);
                // 与普通飞刀一样只与敌对生物结算命中（newLauncherKnife 已设 onlyHitsHostile），
                // 飞行途中径直穿过玩家、其他器械生物等所有友军。
                knife.setPos(point);
                knife.shoot(direction.x, direction.y, direction.z, RING_KNIFE_SPEED, 0.0F);
                level().addFreshEntity(knife);
            }
        }
        pendingRings.clear();
        ringCountdown = 0;
        setRingState("");
    }
}
