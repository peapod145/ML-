package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import cn.blockforge.generated.machinerylegend.entity.MachineryEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.sounds.SoundSource;

import java.util.List;

/** 器械铁镐：沿用铁镐挖掘等级和附魔等级，400耐久，并可拆除器械生物。 */
public class MachineryPickaxeItem extends PickaxeItem {
    public MachineryPickaxeItem(Properties properties) {
        super(Tiers.IRON, properties.attributes(DiggerItem.createAttributes(Tiers.IRON, 3.0f, -2.4f)));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.machinery_pickaxe"));
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND || !(target instanceof MachineryEntity machinery)) {
            return InteractionResult.PASS;
        }
        // 中了反逆的器械已经站到对立阵营那边，器械铁镐不能再把它收回。
        // 判定用带同步附件的客户端版本，服务端与客户端结论一致，不会出现一边拆、一边不拆的不同步。
        if (RebellionLogic.isRebelVisual(target)) {
            return InteractionResult.FAIL;
        }
        if (!player.level().isClientSide) {
            net.minecraft.sounds.SoundEvent removalSound = machinery.getRemovalSound();
            player.level().playSound(null, machinery.blockPosition(),
                    removalSound != null ? removalSound : machinery.getMachineryBlockState().getSoundType().getBreakSound(),
                    SoundSource.BLOCKS, 1.0f, 1.0f);
            machinery.spawnDeathParticles();
            machinery.discard();
            if (!player.getAbilities().instabuild) {
                stack.hurtAndBreak(1, player, EquipmentSlot.MAINHAND);
            }
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
