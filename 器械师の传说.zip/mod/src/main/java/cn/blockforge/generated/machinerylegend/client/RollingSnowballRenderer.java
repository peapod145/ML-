package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.RollingSnowballEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** 根据滚动时间放大雪球的实体渲染器。 */
public class RollingSnowballRenderer extends EntityRenderer<RollingSnowballEntity> {
    private static final ItemStack SNOWBALL_STACK = new ItemStack(Items.SNOWBALL);
    private static final ResourceLocation BLOCK_ATLAS = ResourceLocation.withDefaultNamespace("textures/atlas/blocks.png");
    private final ItemRenderer itemRenderer;

    public RollingSnowballRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
        this.shadowRadius = 0.12f;
    }

    @Override
    public void render(RollingSnowballEntity entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
        float scale = entity.getGrowthScale(partialTick);
        poseStack.scale(scale, scale, scale);
        itemRenderer.renderStatic(SNOWBALL_STACK, ItemDisplayContext.GROUND,
                light, 0, poseStack, buffer, entity.level(), entity.getId());
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, light);
    }

    @Override
    public ResourceLocation getTextureLocation(RollingSnowballEntity entity) {
        return BLOCK_ATLAS;
    }
}
