package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

public class EmitterEntity extends MachineryEntity implements RangedAttackMob {
    // 以下常量与 calculateAim 供"攻击逻辑与发射器相同"的子器械（飞刀发射器）复用；
    // horizontalForward 已上移到 MachineryEntity，各发射器共用一份。
    protected static final float ARROW_SPEED = 1.8f;
    protected static final float ARROW_INACCURACY = 0.08f;
    private static final int AIM_ITERATIONS = 3;
    private static final double MAX_TARGET_LEAD_TICKS = 10.0;
    protected static final double MUZZLE_Y_OFFSET = 1.08;
    protected static final double MUZZLE_FORWARD_OFFSET = 0.42;

    private int shotCooldown;
    private int empoweredShots;
    private int empoweredShotCooldown;
    private int empoweredSearchTicks;

    public EmitterEntity(net.minecraft.world.entity.EntityType<? extends EmitterEntity> type, Level level) { super(type, level); }

    @Override
    protected BlockState getDeathParticleState() {
        // 发射器的主体是顶部的发射器方块，栅栏只承担支架作用。
        return Blocks.DISPENSER.defaultBlockState();
    }

    @Override
    protected boolean hasOffensiveCapability() {
        // 发射器远程射击敌对生物，具备攻击能力，保留索敌与仇恨。
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        // 发射器只允许平射，继承的索敌朝向不能改变俯仰角。
        setXRot(0.0f);
        if (level().isClientSide) return;
        LivingEntity target = getTarget();
        boolean visibleTarget = target != null && target.isAlive() && hasLineOfSight(target) && distanceTo(target) <= 15.0;
        if (!visibleTarget) {
            if (empoweredShots > 0 && empoweredSearchTicks > 0 && --empoweredSearchTicks <= 0) {
                empoweredShots = 0;
                empoweredShotCooldown = 0;
            }
            return;
        }
        empoweredSearchTicks = 0;

        if (empoweredShots > 0) {
            if (empoweredShotCooldown <= 0) {
                performRangedAttack(target, 1.0f);
                playFireSound();
                empoweredShots--;
                empoweredShotCooldown = 4;
            } else {
                empoweredShotCooldown--;
            }
        } else if (shotCooldown <= 0) {
            performRangedAttack(target, 1.0f);
            playFireSound();
            shotCooldown = 28;
        } else {
            shotCooldown--;
        }
    }

    /** 发射器与飞刀发射器共用的开火音效（用户提供的 Shot 采样）。 */
    protected void playFireSound() {
        level().playSound(null, blockPosition(), GeneratedMod.GUN_SHOT.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
    }

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        Vec3 forward = horizontalForward();
        Vec3 start = new Vec3(getX(), getY() + MUZZLE_Y_OFFSET, getZ()).add(forward.scale(MUZZLE_FORWARD_OFFSET));
        Vec3 aim = calculateAim(target, start, velocity);
        MachineryArrow arrow = new MachineryArrow(level(), this);
        arrow.setPos(start);
        arrow.setBaseDamage(1.0);
        arrow.shoot(aim.x, aim.y, aim.z, ARROW_SPEED * Math.max(velocity, 0.1f), ARROW_INACCURACY);
        BlockPos pos = blockPosition();
        if (isOnFire() || level().getBlockState(pos).is(Blocks.FIRE) || level().getBlockState(pos).is(Blocks.LAVA)) arrow.setRemainingFireTicks(100);
        level().addFreshEntity(arrow);
    }

    /**
     * 提前计算目标的移动，并按飞行耗时做提前量，让远距离射击更稳定。
     * 迭代估算飞行时间可以同时处理移动目标和不同距离；箭矢已关闭重力直线飞行，
     * 瞄准高度直接取枪口高度（targetPosition.y = start.y），无需再抬高补偿下坠。
     */
    protected Vec3 calculateAim(LivingEntity target, Vec3 start, float velocity) {
        double speed = ARROW_SPEED * Math.max(velocity, 0.1f);
        Vec3 targetPosition = new Vec3(target.getX(), start.y, target.getZ());
        Vec3 targetMotion = new Vec3(target.getDeltaMovement().x, 0.0, target.getDeltaMovement().z);
        double flightTicks = Math.min(MAX_TARGET_LEAD_TICKS, Math.max(1.0, start.distanceTo(targetPosition) / speed));

        for (int i = 0; i < AIM_ITERATIONS; i++) {
            Vec3 predictedPosition = targetPosition.add(targetMotion.scale(flightTicks));
            flightTicks = Math.min(MAX_TARGET_LEAD_TICKS,
                    Math.max(1.0, start.distanceTo(predictedPosition) / speed));
        }

        return targetPosition.add(targetMotion.scale(flightTicks)).subtract(start).normalize();
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || empoweredShots > 0) return;
        startEvocationEffect();
        empoweredShots = 50;
        empoweredShotCooldown = 0;
        empoweredSearchTicks = 100;
    }
}
