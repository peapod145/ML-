package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.ParasiteBotEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * 寄生机器人：用户提供的 16×32 贴图做成始终面向玩家的面片，
 * 按贴图宽高比（1:2）绘制成 0.5 × 1.0 格，便于在飞行中看清形态。
 */
public class ParasiteBotRenderer extends EntityRenderer<ParasiteBotEntity> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/parasite_bot.png");
    private static final RenderType RENDER_TYPE = RenderType.entityCutoutNoCull(TEXTURE);
    private static final float HALF_WIDTH = 0.25f;
    private static final float HALF_HEIGHT = 0.5f;

    public ParasiteBotRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.15f;
    }

    @Override
    public void render(ParasiteBotEntity entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
        VertexConsumer consumer = buffer.getBuffer(RENDER_TYPE);
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        vertex(consumer, matrix, pose, -HALF_WIDTH, HALF_HEIGHT, 0.0f, 0.0f);
        vertex(consumer, matrix, pose, HALF_WIDTH, HALF_HEIGHT, 1.0f, 0.0f);
        vertex(consumer, matrix, pose, HALF_WIDTH, -HALF_HEIGHT, 1.0f, 1.0f);
        vertex(consumer, matrix, pose, -HALF_WIDTH, -HALF_HEIGHT, 0.0f, 1.0f);
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, light);
    }

    private static void vertex(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose,
                               float x, float y, float u, float v) {
        consumer.addVertex(matrix, x, y, 0.0f)
                .setColor(255, 255, 255, 255)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0.0f, 0.0f, 1.0f);
    }

    @Override
    public ResourceLocation getTextureLocation(ParasiteBotEntity entity) {
        return TEXTURE;
    }
}
