package cn.blockforge.generated.machinerylegend.mixin;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 反逆期间的本地玩家移动方向颠倒、跳跃与潜行互换。
 *
 * <p>{@link KeyboardInput#tick} 已经把 WASD 映射成前后左右的冲量，也把跳跃键/潜行键
 * 读进了 {@code jumping} / {@code shiftKeyDown}。这里在末尾把
 * {@code forwardImpulse} / {@code leftImpulse} 取反并同步交换 up/down、left/right，
 * 于是 W 变 S、A 变 D；再把 {@code jumping} 与 {@code shiftKeyDown} 互换，跳跃键变潜行、
 * 潜行键变跳跃。</p>
 */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin {
    @Inject(method = "tick(ZF)V", at = @At("TAIL"))
    private void machineryLegend$invertMovement(boolean isSneaking, float sneakingSpeed, CallbackInfo ci) {
        Player player = Minecraft.getInstance().player;
        if (player == null || !player.hasEffect(GeneratedMod.REBELLION)) return;
        Input self = (Input) (Object) this;
        self.forwardImpulse = -self.forwardImpulse;
        self.leftImpulse = -self.leftImpulse;
        boolean up = self.up;
        self.up = self.down;
        self.down = up;
        boolean left = self.left;
        self.left = self.right;
        self.right = left;
        // 跳跃与潜行对调：潜行键触发跳跃，跳跃键触发下蹲/潜行。
        boolean jumping = self.jumping;
        self.jumping = self.shiftKeyDown;
        self.shiftKeyDown = jumping;
    }
}
