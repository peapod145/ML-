package cn.blockforge.generated.machinerylegend.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** 转化器方块实体仅用于承载方块类型；输入物品存放在每位玩家自己的界面容器中。 */
public final class MechanicalEnergyConverterBlockEntity extends BlockEntity {
    public MechanicalEnergyConverterBlockEntity(BlockPos pos, BlockState state) {
        super(cn.blockforge.generated.machinerylegend.GeneratedMod.MECHANICAL_ENERGY_CONVERTER_ENTITY.get(), pos, state);
    }
}
