package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import cn.blockforge.generated.machinerylegend.block.SoulforgeFireballLightBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * 炽炎弹：可见弹体为 3/4 个方块表面大的自发光弹射物，关闭重力、沿直线飞行。
 * <p>命中敌人造成 4 点伤害并点燃 5 秒，随后以命中点为原点、沿自身飞行方向左右各 45°
 * 分裂出两发伤害减半、外形为母弹 2/3 的炽炎弹；最多分裂两次（4/2/1 点伤害，第三子代不再分裂）。</p>
 * <p>飞行全程拖出原版火焰（FLAME）粒子轨迹；本体每刻 1 粒，分裂子代体型更小、每 2 刻 1 粒。</p>
 * <p>命中伤害完全无视目标无敌帧：使用带 {@code minecraft:bypasses_cooldown} 标签的专用伤害类型，
 * 并在命中瞬间清零 {@code invulnerableTime} 双保险，目标哪怕正处于着火灼烧等刷新的无敌帧中，
 * 每一发也照常全额结算。该伤害类型除多一个 bypasses_cooldown 标签外与原版 {@code thrown}
 * 完全一致（message_id 同为 thrown、同样在 {@code is_projectile} 标签内），
 * 所以护甲、保护附魔、死亡消息等结算表现一律保持原样；它刻意不带 {@code is_fire} 标签，
 * 以免烈焰人等防火生物反而对整个炽炎弹免疫。</p>
 * <p>无论大小都持续发出 13 级光照：发光逻辑与荧石器械相同，隐形光照方块跟随所在格，
 * 只在空气格里放置、离开或消亡时清除；弹体中途随退出游戏消失而未清掉的光源方块，
 * 会在重载进入世界时由方块自身的延迟计划刻兜底清除。</p>
 * <p>碰到方块或飞出 5 秒后消失；命中幽灵时由 {@link GhostEntity} 侧放行，
 * 无视其半透明 90% 减伤。</p>
 */
public class SoulforgeFireballEntity extends Snowball {
    /** 最长存活 5 秒。 */
    private static final int MAX_LIFETIME_TICKS = 5 * 20;
    /** 分裂代数上限：0 代分裂出 1 代、1 代分裂出 2 代，2 代不再分裂（“最多分裂两次”）。 */
    private static final int MAX_GENERATION = 2;
    /** 各代伤害：4 → 2 → 1，每分裂一次减半。 */
    private static final float BASE_DAMAGE = 4.0f;
    /** 子弹与母弹同速直线飞行。 */
    private static final float FLIGHT_SPEED = 1.5f;
    /** 分裂时两发子弹相对母弹飞行方向各偏 45°。 */
    private static final double SPLIT_ANGLE_RADIANS = Math.PI / 4.0;
    /** 点燃时长 5 秒。 */
    private static final float IGNITE_SECONDS = 5.0f;
    /** 分裂代数同步给客户端，渲染端据此逐级缩小外形。 */
    private static final EntityDataAccessor<Integer> DATA_GENERATION =
            SynchedEntityData.defineId(SoulforgeFireballEntity.class, EntityDataSerializers.INT);
    /**
     * 炽炎弹专用伤害类型：打了 {@code minecraft:bypasses_cooldown} 标签，
     * 原版 {@code LivingEntity.hurt} 会跳过"受伤后 10 刻无敌帧内、伤害不超过
     * 上一刀就直接吞伤"的冷却判定，从机制上保证每一发伤害必然全额结算——
     * 即使目标正处于着火/岩浆/他人攻击刷新的无敌帧里也不会被骗伤。
     * <p>定义见 {@code data/machinery_legend/damage_type/soulforge_fireball.json}
     * （与原版 {@code thrown} 同 exhaustion/message_id/scaling），标签见
     * {@code data/minecraft/tags/damage_type/bypasses_cooldown.json} 与
     * {@code is_projectile.json}（均为 replace:false，只追加不覆盖原版成员）。</p>
     */
    public static final ResourceKey<DamageType> SOULFORGE_FIREBALL_DAMAGE =
            ResourceKey.create(Registries.DAMAGE_TYPE,
                    ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "soulforge_fireball"));

    /** 刚被母弹命中的敌人：子弹从它碰撞箱内部诞生，不能再立刻命中它本体。 */
    private int ignoredTargetId = -1;
    /** 当前拖着的光照方块位置（仅服务端）。 */
    private BlockPos lightPos;

    public SoulforgeFireballEntity(EntityType<? extends SoulforgeFireballEntity> type, Level level) {
        super(type, level);
        // 关闭重力：炽炎弹像烈焰弹一样直线飞行，15 格射程内无需抬枪补偿下坠。
        setNoGravity(true);
    }

    public SoulforgeFireballEntity(EntityType<? extends SoulforgeFireballEntity> type, Entity owner, Level level,
                                   int generation, int ignoredTargetId) {
        this(type, level);
        setOwner(owner);
        entityData.set(DATA_GENERATION, generation);
        this.ignoredTargetId = ignoredTargetId;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_GENERATION, 0);
    }

    /** 分裂代数（0=本体炽炎弹）。 */
    public int getGeneration() {
        return entityData.get(DATA_GENERATION);
    }

    /** 本代伤害：每分裂一次减半（4 → 2 → 1）。 */
    public float getDamageAmount() {
        return BASE_DAMAGE / (1 << getGeneration());
    }

    /** 渲染尺寸系数：每分裂一代缩到上一代的 2/3（本体可见火焰 3/4 个方块表面大）。 */
    public float getRenderScale() {
        return (float) Math.pow(2.0 / 3.0, getGeneration());
    }

    @Override
    public void tick() {
        super.tick();
        if (isRemoved()) return;
        if (tickCount >= MAX_LIFETIME_TICKS) {
            discard();
            return;
        }
        if (!level().isClientSide) updateWorldLight();
        spawnFlameTrail();
    }

    /**
     * 被弹开的回调（盾牌格挡、旋风投射等任何 deflect 路径）：出膛时关闭的重力在反弹后立刻恢复，
     * 炽炎弹不再直线飞行，改回正常下坠。
     */
    @Override
    protected void onDeflection(Entity cause, boolean playSound) {
        super.onDeflection(cause, playSound);
        setNoGravity(false);
    }

    /** 客户端：原版火焰粒子拖尾。本体每刻 1 粒，分裂子代每 2 刻 1 粒，量保持克制。 */
    private void spawnFlameTrail() {
        if (!level().isClientSide) return;
        if (getGeneration() > 0 && tickCount % 2 != 0) return;
        Vec3 velocity = getDeltaMovement();
        double jitter = 0.12 * getRenderScale();
        // 给粒子一点与飞行方向相反的初速，让它沿轨迹散开而不是瞬间被弹体甩远。
        level().addParticle(ParticleTypes.FLAME,
                getX() + (random.nextDouble() - 0.5) * jitter,
                getY() + (random.nextDouble() - 0.5) * jitter,
                getZ() + (random.nextDouble() - 0.5) * jitter,
                velocity.x * -0.12, velocity.y * -0.12, velocity.z * -0.12);
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return RebellionLogic.canMachineProjectileHit(getOwner(), entity) && entity != getOwner()
                && entity.getId() != ignoredTargetId
                && super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        // 不回调父类：Snowball 的默认命中只结算 0 点雪球伤害，这里换成炽炎弹自己的结算。
        if (result.getEntity() instanceof LivingEntity target && RebellionLogic.canMachineProjectileHit(getOwner(), target)) {
            // 无视无敌帧双保险：一是伤害类型带 bypasses_cooldown 标签，原版 hurt 对它的
            // 冷却窗口判定（invulnerableTime > 10 且 amount <= lastHurt 时整刀吞掉）整体短路，
            // 着火/岩浆等持续伤害刷新的无敌帧也骗不走这一发；
            // 二是沿用器械攻击的兜底，命中瞬间再把 invulnerableTime 清零一次。
            MachineryEntity.clearInvulnerabilityForMachineryAttack(target);
            target.hurt(soulforgeDamageSource(), getDamageAmount());
            target.igniteForSeconds(IGNITE_SECONDS);
            if (!level().isClientSide && getGeneration() < MAX_GENERATION) split(target);
        }
        discard();
    }

    /**
     * 炽炎弹伤害源：优先使用带 bypasses_cooldown 标签的专用伤害类型（除标签外与原版
     * {@code thrown} 完全等价）；万一数据包条目缺失，也退回原版 {@code thrown}，
     * 宁可退化成只靠 invulnerableTime 清零，也不能在命中瞬间抛异常打断服务端 tick。
     */
    private DamageSource soulforgeDamageSource() {
        Holder<DamageType> type = level().registryAccess().lookupOrThrow(Registries.DAMAGE_TYPE)
                .get(SOULFORGE_FIREBALL_DAMAGE).orElse(null);
        return type != null ? new DamageSource(type, this, getOwner())
                : level().damageSources().thrown(this, getOwner());
    }

    @Override
    protected void onHit(HitResult result) {
        // 必须保留父类的命中分派，否则实体命中不会进入 onHitEntity；
        // 碰到方块时父类已让弹体消失，这里兜底再 discard 一次。
        super.onHit(result);
        if (!isRemoved()) discard();
    }

    /**
     * 以命中点为原点，沿母弹飞行方向左右各偏 45° 射出两发子代炽炎弹；
     * 子代伤害减半、外形更小，命中后可再分裂一轮（总计最多分裂两次）。
     */
    private void split(LivingEntity hitTarget) {
        Vec3 direction = getDeltaMovement();
        if (direction.lengthSqr() < 1.0E-6) {
            // 极端情况（速度被清零）兜底：按母弹朝向水平向前分裂。
            float yaw = getYRot() * ((float) Math.PI / 180.0f);
            direction = new Vec3(-Math.sin(yaw), 0.0, Math.cos(yaw));
        }
        direction = direction.normalize();
        spawnChild(SoulforgeEntity.rotateYaw(direction, SPLIT_ANGLE_RADIANS), hitTarget.getId());
        spawnChild(SoulforgeEntity.rotateYaw(direction, -SPLIT_ANGLE_RADIANS), hitTarget.getId());
    }

    private void spawnChild(Vec3 direction, int hitTargetId) {
        SoulforgeFireballEntity child = new SoulforgeFireballEntity(
                GeneratedMod.SOULFORGE_FIREBALL.get(), getOwner(), level(), getGeneration() + 1, hitTargetId);
        child.setPos(getX(), getY(), getZ());
        child.shoot(direction.x, direction.y, direction.z, FLIGHT_SPEED, 0.0f);
        level().addFreshEntity(child);
    }

    /**
     * 发光逻辑与荧石器械一致：所在格是空气就放 13 级隐形光照方块，换格先清旧的。
     * 取得一格光源（含收养上一发弹残留的同款方块）时注册一次延迟计划刻，
     * 由 {@link cn.blockforge.generated.machinerylegend.block.SoulforgeFireballLightBlock}
     * 兜底清除"弹体消失后仍未消失"的无主残留（退出游戏重载时尤其依赖这条路径）。
     */
    private void updateWorldLight() {
        BlockPos currentPos = blockPosition();
        if (lightPos != null && !lightPos.equals(currentPos)) {
            removeWorldLight(lightPos);
            lightPos = null;
        }
        // 护栏：位置所在区块若已不在加载表里（退出存档的批量卸载循环就处于这种半程状态），
        // 直接读方块会让 ServerChunkCache 抛 "Chunk not there when requested"，
        // 该异常能把 stopServer() 打断在半路、连 level.dat 都写不出去。跳过本刻即可。
        if (lightPos == null && !level().isLoaded(currentPos)) return;
        if (lightPos == null) {
            BlockState currentState = level().getBlockState(currentPos);
            if (currentState.isAir() || currentState.is(GeneratedMod.SOULFORGE_FIREBALL_LIGHT.get())) {
                if (currentState.isAir()) {
                    level().setBlock(currentPos, GeneratedMod.SOULFORGE_FIREBALL_LIGHT.get().defaultBlockState(), 3);
                }
                lightPos = currentPos;
                if (level() instanceof ServerLevel serverLevel) {
                    serverLevel.scheduleTick(currentPos, GeneratedMod.SOULFORGE_FIREBALL_LIGHT.get(),
                            SoulforgeFireballLightBlock.RESIDUAL_CLEANUP_DELAY_TICKS);
                }
            }
        }
    }

    private void removeWorldLight(BlockPos pos) {
        // 护栏：区块已卸载（或在退出流程的卸载半途）时不碰方块——这种时刻抛出的异常
        // 会打断 MinecraftServer#stopServer 的收尾，让 level.dat 的落盘整段跳过。
        if (!level().isLoaded(pos)) return;
        if (level().getBlockState(pos).is(GeneratedMod.SOULFORGE_FIREBALL_LIGHT.get())) {
            level().removeBlock(pos, false);
        }
    }

    /**
     * 就地撤掉本弹当前拖着的那一格光源并复位引用。
     * <p>供服务端关停前的清场调用：{@code ServerStoppingEvent} 在区块写盘之前触发，此刻区块
     * 仍在加载表里，撤灯一定成功，写进存档的区块里就不会留下"弹体一消失就失效"的悬空灯。
     * 本弹若随存档重载，lightPos 归零后会在新位置重新点灯，行为与正常重载一致。</p>
     */
    public void clearTrailingLight() {
        if (level().isClientSide || lightPos == null) return;
        removeWorldLight(lightPos);
        lightPos = null;
    }

    @Override
    public void onRemovedFromLevel() {
        if (!level().isClientSide && lightPos != null) removeWorldLight(lightPos);
        super.onRemovedFromLevel();
    }
}
