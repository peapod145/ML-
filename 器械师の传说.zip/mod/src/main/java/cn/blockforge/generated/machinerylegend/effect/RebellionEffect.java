package cn.blockforge.generated.machinerylegend.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** 反逆药水效果的注册类型；目标关系由 RebellionLogic 统一处理。 */
public final class RebellionEffect extends MobEffect {
    public static final int COLOR = 0xFF2AD9D9;

    public RebellionEffect() {
        super(MobEffectCategory.HARMFUL, COLOR);
    }
}
