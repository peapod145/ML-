package cn.blockforge.generated.machinerylegend.entity;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;

import java.util.Optional;

/** 结构中的固定友善村民，保留原版村民的交互和被僵尸攻击行为。 */
public class CheatingVillagerEntity extends Villager {
    public CheatingVillagerEntity(EntityType<? extends Villager> type, Level level) {
        super(type, level);
        setPersistenceRequired();
        setCustomNameVisible(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Villager.createAttributes()
                .add(Attributes.MAX_HEALTH, 40.0);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            // 客户端渲染层根据职业选择服装；无论服务端职业状态如何，都显示图书管理员外观。
            if (getVillagerData().getProfession() != VillagerProfession.LIBRARIAN) {
                setVillagerData(getVillagerData().setProfession(VillagerProfession.LIBRARIAN));
            }
            return;
        }
        if (getVillagerData().getProfession() == VillagerProfession.LIBRARIAN) return;

        BlockPos center = blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-1, -1, -1), center.offset(1, 1, 1))) {
            if (level().getBlockState(pos).is(GeneratedMod.MECHANICAL_ENERGY_CONVERTER.get())) {
                setVillagerData(getVillagerData().setProfession(VillagerProfession.LIBRARIAN));
                return;
            }
        }
    }

    @Override
    public int getPlayerReputation(Player player) {
        // 本实体不参与原版声望折扣或加价计算。
        return 0;
    }

    @Override
    public MerchantOffers getOffers() {
        MerchantOffers offers = super.getOffers();
        // 已保存的空列表不会再次触发原版 updateTrades；这里保证交互时始终有本实体的交易。
        if (offers.isEmpty()) {
            updateTrades();
            return this.offers;
        }

        // 存档读取后报价会还原成原版 MerchantOffer，重新包装后可继续保持固定价格。
        for (int index = 0; index < offers.size(); index++) {
            MerchantOffer offer = offers.get(index);
            if (!(offer instanceof FixedPriceMerchantOffer)) {
                offers.set(index, FixedPriceMerchantOffer.from(offer));
            }
        }
        // 老存档里已存在的村民可能没有这条新交易，缺则补上，保证星之碎片流程可用。
        boolean hasShardUpgrade = false;
        for (MerchantOffer offer : offers) {
            if (offer.getResult().is(GeneratedMod.SHARD_SLOT_UPGRADE.get())) {
                hasShardUpgrade = true;
                break;
            }
        }
        if (!hasShardUpgrade) {
            offers.add(createShardSlotUpgradeOffer());
        }
        return offers;
    }

    /** 16 个钻石换取 1 个碎片槽位升级。 */
    private static FixedPriceMerchantOffer createShardSlotUpgradeOffer() {
        return new FixedPriceMerchantOffer(
                new ItemCost(Items.DIAMOND, 16),
                Optional.empty(),
                new ItemStack(GeneratedMod.SHARD_SLOT_UPGRADE.get()),
                12, 1, 0.05f, 0);
    }

    @Override
    public boolean shouldShowName() {
        return false;
    }

    @Override
    public void overrideOffers(MerchantOffers offers) {
        this.offers = offers;
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = new MerchantOffers();
        // 20 个绿宝石 + 1 个动力矿车，按村民交易机制限量并可补货。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 20),
                Optional.of(new ItemCost(Items.FURNACE_MINECART)),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.POWERED_CART.get()),
                12, 1, 0.05f, 0));
        // 40 个绿宝石 + 1 把铁锄，换取 1 个器械钉耙。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 40),
                Optional.of(new ItemCost(Items.IRON_HOE)),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.MACHINERY_RAKE.get()),
                12, 1, 0.05f, 0));
        // 64 个绿宝石 + 1 个奥格拉斯的机械臂，换取 1 个狙击发射器蓝图。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 64),
                Optional.of(new ItemCost(cn.blockforge.generated.machinerylegend.GeneratedMod.MECHANICAL_ARM.get())),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.SNIPER_EMITTER_BLUEPRINT.get()),
                12, 1, 0.05f, 0));
        // 64 个绿宝石 + 1 个小型发射器蓝图，换取 1 个传染发射器蓝图。
        offers.add(new FixedPriceMerchantOffer(
                new ItemCost(Items.EMERALD, 64),
                Optional.of(new ItemCost(cn.blockforge.generated.machinerylegend.GeneratedMod.SMALL_EMITTER_BLUEPRINT.get())),
                new ItemStack(cn.blockforge.generated.machinerylegend.GeneratedMod.INFECTENSER_BLUEPRINT.get()),
                12, 1, 0.05f, 0));
        // 16 个钻石，换取 1 个碎片槽位升级。
        offers.add(createShardSlotUpgradeOffer());
        overrideOffers(offers);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide()) {
            // 先生成自定义交易，避免无业状态下原版村民因交易为空而不打开界面。
            if (getOffers().isEmpty()) {
                updateTrades();
            }
            setTradingPlayer(player);
            openTradingScreen(player, Component.translatable("entity.machinery_legend.cheating_villager"), 1);
        }
        return InteractionResult.sidedSuccess(level().isClientSide());
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }
}
