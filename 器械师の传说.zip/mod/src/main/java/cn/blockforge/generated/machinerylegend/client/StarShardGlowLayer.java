package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import cn.blockforge.generated.machinerylegend.entity.StarShardCarrier;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/**
 * 携带星之碎片的怪物“浑身冒绿光”渲染层：
 * 在怪物自身模型之上再叠一层纯绿色发光，看起来就像 PVZ2 里吃了能量豆的僵尸。
 * 同一个渲染层也负责反逆效果的品红发光：中了 {@code rebellion} 的生物改成叠一层品红色，
 * 两者共用同一张遮罩、同一套渲染类型，只是顶点色不同。
 *
 * <p>用的是原版 {@link RenderType#eyes(ResourceLocation)}（原版 {@code EyesLayer}
 * 给蜘蛛/末影人叠整只模型用的那个渲染类型）。eyes 着色器只做 {@code 贴图 × 顶点色}：
 * 不需要 overlay(Sampler1)、不需要 lightmap(Sampler2)，也不依赖光照方向 uniform，
 * 顶点色就是输出色（不做 mix）——所以“纯白遮罩 + 绿色顶点色”必然得到一层与环境亮度无关的绿光，
 * 纯黑怪物（末影人）也照样整体发绿；加法混合让它真像在发光。</p>
 *
 * <p><strong>只画这一遍，且保持默认的深度测试（LEQUAL）。</strong>
 * 之前还有一遍“不测深度”的补光，那会让整层绿光无视地形深度缓冲、隔着墙也画出来
 * （也就是“发光透过方块”）。现在绿光和其他实体一样参与深度测试：
 * 怪物被方块/地形挡住时绿光同样被挡住，只有真正能看见怪物时才发绿。</p>
 *
 * <p>该层通过 {@link #decorate} 幂等地挂到活体渲染器上，最多只会挂一次。</p>
 */
public final class StarShardGlowLayer<T extends LivingEntity, M extends EntityModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation GLOW_MASK = ResourceLocation.fromNamespaceAndPath(
            "machinery_legend", "textures/entity/star_shard_glow.png");
    /** 绿光颜色：ARGB，加法混合下即为叠加到怪物身上的绿光强度。 */
    private static final int GLOW_COLOR = 0xFF2ECC44;
    /**
     * 品红发光颜色：比绿光弱一档。
     *
     * <p>{@code eyes} 用的是 {@code ONE / ONE} 加法混合，混合阶段只看 RGB、不看 alpha，
     * 所以“降低不透明度”必须落在 R/B 通道上：这里把亮度压到一半左右，叠出来的品红更柔和。</p>
     */
    private static final int REBELLION_GLOW_COLOR = 0x80800080;
    private static final RenderType GLOW_RENDER_TYPE = RenderType.eyes(GLOW_MASK);
    /** 已挂过绿光层的渲染器（按身份比较），避免同一渲染器被重复叠层。 */
    private static final Set<Object> DECORATED = Collections.newSetFromMap(new IdentityHashMap<>());

    public StarShardGlowLayer(RenderLayerParent<T, M> parent) {
        super(parent);
    }

    /**
     * 幂等地把绿光层挂到活体渲染器上；已挂过（或不是活体渲染器）就什么也不做。
     * 两个挂载入口（{@code EntityRenderersEvent.AddLayers} 与 {@code RenderLivingEvent.Pre}）
     * 都会调用它，所以即使其中一条路径没生效也不会漏掉绿光，同时不会重复叠层。
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static boolean decorate(Object renderer) {
        if (!(renderer instanceof LivingEntityRenderer living)) return false;
        if (!DECORATED.add(living)) return false;
        living.addLayer(new StarShardGlowLayer(living));
        return true;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isInvisible()) return;
        // 反逆判据必须走同步附件：非玩家实体的药水效果不会同步给其他客户端，
        // 只查 hasEffect 会让品红发光在所有非本地玩家身上都不亮（这正是之前的 bug）。
        boolean rebel = RebellionLogic.isRebelVisual(entity);
        if (!rebel && !StarShardCarrier.isCarrier(entity)) return;
        VertexConsumer consumer = buffer.getBuffer(GLOW_RENDER_TYPE);
        this.getParentModel().renderToBuffer(poseStack, consumer,
                LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                rebel ? REBELLION_GLOW_COLOR : GLOW_COLOR);
    }
}
