package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.GargoyleEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * 石像鬼渲染器。
 * <p>三张 64×64 僵尸版式贴图按血量整张切换（用户上传素材，逐像素未改动）：
 * 血量 &gt;40 → {@code gargoyle.png}（stone-2.png），
 * 20 &lt; 血量 ≤40 → {@code gargoyle_damaged.png}（stone2.png），
 * 血量 ≤20 → {@code gargoyle_broken.png}（stone3.png）。
 * 旧的"受击渐进裂纹叠加层"已按需求取消。</p>
 * <p>死亡时不再显示"倒下泛红的尸体"：原版 LivingEntityRenderer 会依据客户端本地递增的
 * {@code deathTime}（0→20）在死亡动画期间把模型侧翻并配白烟；这里在进入死亡动画后直接
 * 跳过渲染，石像鬼死亡瞬间即消失（掉落、经验与死亡音效不受影响），配合实体侧吞掉的
 * POOF 事件，死亡既无白烟也无尸体。</p>
 */
public final class GargoyleRenderer extends MobRenderer<GargoyleEntity, GargoyleModel> {
    public static final net.minecraft.client.model.geom.ModelLayerLocation MODEL_LAYER =
            new net.minecraft.client.model.geom.ModelLayerLocation(
                    ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "gargoyle"), "main");
    private static final ResourceLocation TEXTURE_INTACT = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/gargoyle.png");
    private static final ResourceLocation TEXTURE_DAMAGED = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/gargoyle_damaged.png");
    private static final ResourceLocation TEXTURE_BROKEN = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/gargoyle_broken.png");

    public GargoyleRenderer(EntityRendererProvider.Context context) {
        super(context, new GargoyleModel(context.bakeLayer(MODEL_LAYER)), 0.5F);
    }

    @Override
    public void render(GargoyleEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        // 死亡动画期间（客户端 deathTime 由本地 tickDeath 递增）不渲染任何躯体
        if (!entity.isAlive() || entity.deathTime > 0) {
            return;
        }
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(GargoyleEntity entity) {
        return switch (entity.getDamageStage()) {
            case 2 -> TEXTURE_BROKEN;
            case 1 -> TEXTURE_DAMAGED;
            default -> TEXTURE_INTACT;
        };
    }
}
