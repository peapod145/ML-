package cn.blockforge.generated.machinerylegend.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * 器械发光方块基类：完全隐形、无形状、无碰撞、不遮挡光线，只把光照等级写进世界
 * （等级由各子类注册时的 {@code BlockBehaviour.Properties#lightLevel} 决定）。
 *
 * <p>荧石、熔炉、炽炎熔炉三系发光方块的表现完全一致，差别只在光照等级与名字，
 * 因此共用这一份实现；炽炎熔炉系再在 {@link SoulforgeLightBlock} 上追加残留自愈。</p>
 */
public class MachineryLightBlock extends Block {
    public MachineryLightBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    protected VoxelShape getInteractionShape(BlockState state, BlockGetter level, BlockPos pos) {
        return Shapes.empty();
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return Shapes.empty();
    }

    @Override
    protected float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
        return 1.0f;
    }
}
