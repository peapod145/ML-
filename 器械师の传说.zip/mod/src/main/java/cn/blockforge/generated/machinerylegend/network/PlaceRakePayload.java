package cn.blockforge.generated.machinerylegend.network;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.item.RakeItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

/** 客户端按键请求在目标方块顶面放置钉耙，服务端会重新验证所有条件。 */
public record PlaceRakePayload(BlockPos blockPos) implements CustomPacketPayload {
    public static final Type<PlaceRakePayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "place_rake"));
    public static final StreamCodec<io.netty.buffer.ByteBuf, PlaceRakePayload> STREAM_CODEC =
            StreamCodec.composite(
                    BlockPos.STREAM_CODEC, PlaceRakePayload::blockPos,
                    PlaceRakePayload::new);

    @Override
    public Type<PlaceRakePayload> type() {
        return TYPE;
    }

    public static void handle(PlaceRakePayload payload,
                              net.neoforged.neoforge.network.handling.IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                RakeItem.tryPlace(player, payload.blockPos());
            }
        });
    }
}
