package cn.blockforge.generated.machinerylegend.client;

/** 客户端缓存的服务端碎片槽数据，只读，供 HUD 渲染。 */
public final class ClientShards {
    private static int count;
    private static int slots = 1;

    private ClientShards() {}

    public static int getCount() { return count; }

    public static int getSlots() { return slots; }

    public static void set(int count, int slots) {
        ClientShards.count = count;
        ClientShards.slots = slots;
    }
}
