package cn.blockforge.generated.machinerylegend.item;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import java.util.function.Supplier;

/**
 * 狼人刷怪蛋：严格使用用户提供的 16×16 贴图（textures/item/werewolf_spawn_egg.png）。
 * <p>与石像鬼刷怪蛋同一做法：自带贴图模型 + 白色乘色（恒等变换），
 * 使贴图逐像素原样显示；生成行为仍是原版刷怪蛋逻辑。</p>
 */
public final class WerewolfSpawnEggItem extends DeferredSpawnEggItem {
    public WerewolfSpawnEggItem(Supplier<? extends EntityType<? extends Mob>> type, Properties props) {
        super(type, 0xE8E0D0, 0x8A7A5A, props);
    }

    /** 白色乘色 = 恒等变换，保证贴图原样显示。 */
    @Override
    public int getColor(int tint) {
        return 0xFFFFFFFF;
    }
}
