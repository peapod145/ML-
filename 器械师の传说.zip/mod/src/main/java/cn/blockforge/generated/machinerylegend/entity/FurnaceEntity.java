package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class FurnaceEntity extends MachineryEntity {
    /** 跟着本体走的一格隐形光照方块（10 级）。 */
    private final BodyLightTracker light = new BodyLightTracker(this, GeneratedMod.FURNACE_LIGHT.get());

    public FurnaceEntity(EntityType<? extends FurnaceEntity> type, Level level) { super(type, level); }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.FURNACE.defaultBlockState();
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            light.update();
            if (tickCount % 480 == 0) dropRedstone(1);
        }
    }

    @Override
    public void onRemovedFromLevel() {
        light.clear();
        super.onRemovedFromLevel();
    }

    @Override
    public void triggerEmpowered() {
        if (!level().isClientSide) {
            startEvocationEffect();
            for (int i = 0; i < 6; i++) dropRedstone(1);
        }
    }

    private void dropRedstone(int count) {
        ItemEntity item = new ItemEntity(level(), getX(), getY() + 0.55, getZ(), new ItemStack(Items.REDSTONE, count));
        item.getPersistentData().putBoolean("machinery_legend_furnace_redstone", true);
        item.lifespan = 300;
        level().addFreshEntity(item);
    }
}
