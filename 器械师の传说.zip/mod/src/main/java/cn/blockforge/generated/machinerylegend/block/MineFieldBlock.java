package cn.blockforge.generated.machinerylegend.block;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.util.RandomSource;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.common.util.FakePlayer;
import com.mojang.serialization.MapCodec;


/** 矿场方块：白天定时生成原版矿物，并把库存导入周围容器。 */
public final class MineFieldBlock extends BaseEntityBlock {
    public static final MapCodec<MineFieldBlock> CODEC = simpleCodec(MineFieldBlock::new);
    private static final ItemStack[] ORE_ITEMS = {
            new ItemStack(Items.REDSTONE),
            new ItemStack(Items.COAL),
            new ItemStack(Items.RAW_COPPER),
            new ItemStack(Items.RAW_IRON),
            new ItemStack(Items.RAW_GOLD),
            new ItemStack(Items.DIAMOND)
    };
    private static final int[] ORE_CUMULATIVE_WEIGHTS = {30, 55, 72, 87, 95, 100};

    public static ItemStack rollOre(RandomSource random) {
        int roll = random.nextInt(100);
        for (int index = 0; index < ORE_CUMULATIVE_WEIGHTS.length; index++) {
            if (roll < ORE_CUMULATIVE_WEIGHTS[index]) return ORE_ITEMS[index].copy();
        }
        return ORE_ITEMS[ORE_ITEMS.length - 1].copy();
    }

    public MineFieldBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MineFieldBlockEntity(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, GeneratedMod.MINE_FIELD_ENTITY.get(), MineFieldBlockEntity::serverTick);
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            BlockEntity entity = level.getBlockEntity(pos);
            if (entity instanceof MineFieldBlockEntity mineField) {
                net.minecraft.world.Containers.dropContents(level, pos, mineField);
                level.removeBlockEntity(pos);
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        for (int chunkX = (pos.getX() >> 4) - 1; chunkX <= (pos.getX() >> 4) + 1; chunkX++) {
            for (int chunkZ = (pos.getZ() >> 4) - 1; chunkZ <= (pos.getZ() >> 4) + 1; chunkZ++) {
                if (!level.isLoaded(new BlockPos(chunkX << 4, pos.getY(), chunkZ << 4))) continue;
                for (BlockEntity entity : level.getChunk(chunkX, chunkZ).getBlockEntities().values()) {
                    if (entity instanceof MineFieldBlockEntity) {
                        if (!level.isClientSide && context.getPlayer() != null) {
                            context.getPlayer().displayClientMessage(Component.translatable("message.machinery_legend.mine_field_too_close"), true);
                        }
                        return null;
                    }
                }
            }
        }
        return defaultBlockState();
    }

    private InteractionResult openMineField(Level level, BlockPos pos, Player player) {
        if (player instanceof FakePlayer) return InteractionResult.PASS;
        if (!level.isClientSide && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            BlockEntity entity = level.getBlockEntity(pos);
            if (entity instanceof MineFieldBlockEntity mineField) {
                serverPlayer.openMenu(mineField, buf -> buf.writeBlockPos(pos));
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return openMineField(level, pos, player);
    }

    @Override
    protected ItemInteractionResult useItemOn(net.minecraft.world.item.ItemStack stack, BlockState state, Level level,
                                               BlockPos pos, Player player, net.minecraft.world.InteractionHand hand,
                                               BlockHitResult hit) {
        return ItemInteractionResult.sidedSuccess(openMineField(level, pos, player) == InteractionResult.SUCCESS || level.isClientSide);
    }
}
