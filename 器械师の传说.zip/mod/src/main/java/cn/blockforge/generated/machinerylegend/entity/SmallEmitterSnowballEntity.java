package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.level.Level;

/**
 * 小型发射器的普通雪球，射出 10 秒后消失并对敌对生物造成 2 点伤害。
 * 不带弹道下坠：关闭重力后沿枪口方向直线飞行，出膛速度 0.72 保持不变。
 */
public class SmallEmitterSnowballEntity extends Snowball {
    private static final int MAX_LIFETIME_TICKS = 10 * 20;

    public SmallEmitterSnowballEntity(EntityType<SmallEmitterSnowballEntity> type, Level level) {
        super(type, level);
        // 关闭重力：器械射出的弹药按直线弹道飞行，不随距离下坠（速度不变）。
        setNoGravity(true);
    }

    public SmallEmitterSnowballEntity(EntityType<SmallEmitterSnowballEntity> type, Entity owner, Level level) {
        this(type, level);
        setOwner(owner);
    }

    @Override
    public void tick() {
        super.tick();
        if (!isRemoved() && tickCount >= MAX_LIFETIME_TICKS) discard();
    }

    /**
     * 被弹开的回调（盾牌格挡、旋风投射等任何 deflect 路径）：出膛时关闭的重力在反弹后立刻恢复，
     * 雪球不再直线飞行，改回正常下坠。
     */
    @Override
    protected void onDeflection(Entity cause, boolean playSound) {
        super.onDeflection(cause, playSound);
        setNoGravity(false);
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return RebellionLogic.canMachineProjectileHit(getOwner(), entity) && super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(net.minecraft.world.phys.EntityHitResult result) {
        if (result.getEntity() instanceof LivingEntity target && RebellionLogic.canMachineProjectileHit(getOwner(), target)) {
            MachineryEntity.clearInvulnerabilityForMachineryAttack(target);
            Entity owner = getOwner();
            // 直接使用投射物伤害源并清除无敌帧，确保普通雪球实际扣除2点生命值。
            target.hurt(level().damageSources().thrown(this, owner), 2.0f);
        }
        discard();
    }

    @Override
    protected void onHit(net.minecraft.world.phys.HitResult result) {
        // 必须保留父类的命中分派，否则实体命中不会进入 onHitEntity，雪球就不会造成伤害。
        super.onHit(result);
        if (!isRemoved()) discard();
    }
}
