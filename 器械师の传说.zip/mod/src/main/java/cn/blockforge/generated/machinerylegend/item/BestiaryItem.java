package cn.blockforge.generated.machinerylegend.item;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.player.EnergyData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** 记录敌对生物的图鉴；记录内容保存在物品自身的数据组件中。 */
public final class BestiaryItem extends Item {
    public static final String RECORDS_KEY = "machinery_legend_records";
    public static final String DAY_KEY = "machinery_legend_records_day";

    public BestiaryItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    public static boolean isActive(Player player) {
        return !findActiveStack(player).isEmpty();
    }

    public static void tick(Player player) {
        if (player.level().isClientSide) return;
        long day = player.level().getDayTime() / 24000L;
        for (ItemStack stack : player.getInventory().items) {
            if (stack.is(GeneratedMod.BESTIARY.get())) clearIfNewDay(stack, day);
        }
        for (ItemStack stack : player.getInventory().offhand) {
            if (stack.is(GeneratedMod.BESTIARY.get())) clearIfNewDay(stack, day);
        }
        ItemStack curiosStack = CuriosCompat.findEquipped(player, GeneratedMod.BESTIARY.get());
        if (!curiosStack.isEmpty()) clearIfNewDay(curiosStack, day);
    }

    public static ItemStack findActiveStack(Player player) {
        for (int i = 0; i < 9 && i < player.getInventory().items.size(); i++) {
            ItemStack stack = player.getInventory().items.get(i);
            if (stack.is(GeneratedMod.BESTIARY.get())) return stack;
        }
        return CuriosCompat.findEquipped(player, GeneratedMod.BESTIARY.get());
    }

    public static void recordTarget(ServerPlayer player, int entityId) {
        if (!(player.level() instanceof ServerLevel level)) return;
        ItemStack stack = findActiveStack(player);
        if (stack.isEmpty()) return;
        clearIfNewDay(stack, level.getGameTime() / 24000L);
        Entity target = level.getEntity(entityId);
        if (!(target instanceof LivingEntity living) || !(target instanceof Enemy)
                || !living.isAlive() || target == player
                || player.distanceToSqr(target) > 36.0 || !player.hasLineOfSight(living)) return;
        String id = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(target.getType()).toString();
        if (hasRecord(stack, id)) {
            player.displayClientMessage(Component.translatable("message.machinery_legend.bestiary_failure")
                    .withStyle(ChatFormatting.RED), false);
            return;
        }
        addRecord(stack, id);
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1), player);
        EnergyData.add(player, 50);
        player.displayClientMessage(Component.translatable("message.machinery_legend.bestiary_success")
                .withStyle(ChatFormatting.GREEN), false);
    }

    public static boolean hasRecord(ItemStack stack, String id) {
        CompoundTag tag = data(stack);
        ListTag records = tag.getList(RECORDS_KEY, 8);
        for (int i = 0; i < records.size(); i++) if (id.equals(records.getString(i))) return true;
        return false;
    }

    public static void addRecord(ItemStack stack, String id) {
        CustomData.update(net.minecraft.core.component.DataComponents.CUSTOM_DATA, stack, tag -> {
            ListTag records = tag.getList(RECORDS_KEY, 8);
            if (!hasString(records, id)) records.add(net.minecraft.nbt.StringTag.valueOf(id));
            tag.put(RECORDS_KEY, records);
        });
    }

    public static void clearIfNewDay(ItemStack stack, long day) {
        CustomData.update(net.minecraft.core.component.DataComponents.CUSTOM_DATA, stack, tag -> {
            if (tag.getLong(DAY_KEY) == day) return;
            tag.putLong(DAY_KEY, day);
            tag.remove(RECORDS_KEY);
        });
    }

    public static List<String> records(ItemStack stack) {
        List<String> result = new java.util.ArrayList<>();
        ListTag records = data(stack).getList(RECORDS_KEY, 8);
        for (int i = 0; i < records.size(); i++) result.add(records.getString(i));
        return result;
    }

    private static boolean hasString(ListTag list, String value) {
        for (int i = 0; i < list.size(); i++) if (value.equals(list.getString(i))) return true;
        return false;
    }

    private static CompoundTag data(ItemStack stack) {
        CustomData customData = stack.get(net.minecraft.core.component.DataComponents.CUSTOM_DATA);
        return customData == null ? new CompoundTag() : customData.copyTag();
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.bestiary_key",
                Component.keybind("key.machinery_legend.record_bestiary")));
        tooltip.add(Component.translatable("tooltip.machinery_legend.bestiary_effect"));
        if (flag.hasShiftDown()) {
            List<String> records = records(stack);
            if (records.isEmpty()) {
                tooltip.add(Component.translatable("tooltip.machinery_legend.bestiary_empty").withStyle(ChatFormatting.GRAY));
            } else {
                tooltip.add(Component.translatable("tooltip.machinery_legend.bestiary_records").withStyle(ChatFormatting.GOLD));
                for (String id : records) {
                    ResourceLocation key = ResourceLocation.tryParse(id);
                    String name = key == null ? id : Component.translatable("entity." + key.getNamespace() + "." + key.getPath()).getString();
                    tooltip.add(Component.literal(" • " + name).withStyle(ChatFormatting.GREEN));
                }
            }
        } else {
            tooltip.add(Component.translatable("tooltip.machinery_legend.bestiary_shift").withStyle(ChatFormatting.GRAY));
        }
    }
}
