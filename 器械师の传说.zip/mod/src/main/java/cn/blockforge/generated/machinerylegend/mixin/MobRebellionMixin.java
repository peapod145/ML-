package cn.blockforge.generated.machinerylegend.mixin;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 反逆效果会把受反逆生物的目标切到同阵营生物上。
 *
 * <p>普通怪物如何选中被反逆的怪物由 {@code NearestAttackableTargetGoalMixin} 负责，
 * 这里不再做任何强制搜猎。</p>
 */
@Mixin(Mob.class)
public abstract class MobRebellionMixin {
    @Unique
    private static final double machineryLegend$SEARCH_RANGE = 16.0;
    @Unique
    private boolean machineryLegend$wasRebel;

    @Unique
    private void machineryLegend$rebellionTick() {
        Mob self = (Mob) (Object) this;
        if (self.level().isClientSide || self.isNoAi() || !self.isEffectiveAi()) return;
        boolean rebel = RebellionLogic.isRebel(self);
        if (!rebel && machineryLegend$wasRebel) {
            LivingEntity target = self.getTarget();
            if (target != null && RebellionLogic.sameFaction(self, target)) self.setTarget(null);
        }
        machineryLegend$wasRebel = rebel;
        if (!rebel || self.tickCount % 4 != 0) return;
        LivingEntity current = self.getTarget();
        // 玩家中途切到创造/旁观模式时，已经锁定的同阵营目标也要立刻放下。
        if (current != null && RebellionLogic.isUntargetablePlayer(current)) {
            self.setTarget(null);
            current = null;
        }
        // 反逆者互为队友：已锁定的反逆目标也要立刻放下，再去挑新的同阵营目标。
        if (current != null && current.isAlive() && !RebellionLogic.isRebel(current)
                && RebellionLogic.sameFaction(self, current) && self.hasLineOfSight(current)) return;
        LivingEntity replacement = nearestAlly(self);
        if (replacement != null) self.setTarget(replacement);
        else if (current != null && (RebellionLogic.isRebel(current) || RebellionLogic.sameFaction(self, current))) {
            self.setTarget(null);
        }
    }

    @Unique
    private LivingEntity nearestAlly(Mob self) {
        LivingEntity nearest = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity candidate : self.level().getEntitiesOfClass(LivingEntity.class,
                self.getBoundingBox().inflate(machineryLegend$SEARCH_RANGE),
                entity -> entity != self && entity.isAlive() && entity.canBeSeenByAnyone()
                        && !RebellionLogic.isUntargetablePlayer(entity)
                        && !RebellionLogic.isRebel(entity)
                        && RebellionLogic.sameFaction(self, entity) && self.hasLineOfSight(entity))) {
            double distance = self.distanceToSqr(candidate);
            if (distance < best) {
                best = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void machineryLegend$onTick(CallbackInfo ci) {
        machineryLegend$rebellionTick();
    }
}
