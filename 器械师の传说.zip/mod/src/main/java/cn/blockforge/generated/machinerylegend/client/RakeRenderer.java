package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.RakeEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** 用原版铁锄物品模型表现钉耙的横放和触发后竖起状态。 */
public final class RakeRenderer extends EntityRenderer<RakeEntity> {
    private static final ResourceLocation BLOCK_ATLAS = ResourceLocation.withDefaultNamespace("textures/atlas/blocks.png");
    private final ItemRenderer itemRenderer;
    private final ItemStack hoeStack = new ItemStack(Items.IRON_HOE);

    public RakeRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
        this.shadowRadius = 0.15f;
    }

    @Override
    public void render(RakeEntity entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        poseStack.translate(0.0, 0.02, 0.0);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f - entity.getYRot()));
        if (entity.isActivated()) {
            poseStack.mulPose(Axis.ZP.rotationDegrees(90.0f));
        } else {
            poseStack.mulPose(Axis.XP.rotationDegrees(90.0f));
        }
        poseStack.scale(1.5f, 1.5f, 1.5f);
        itemRenderer.renderStatic(hoeStack, ItemDisplayContext.GROUND, light, 0,
                poseStack, buffer, entity.level(), entity.getId());
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, light);
    }

    @Override
    public ResourceLocation getTextureLocation(RakeEntity entity) {
        return BLOCK_ATLAS;
    }
}
