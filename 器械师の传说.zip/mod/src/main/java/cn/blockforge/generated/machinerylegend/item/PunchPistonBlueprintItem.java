package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.PunchPistonEntity;
import net.minecraft.world.entity.EntityType;

/** 冲击活塞蓝图：与其他器械蓝图完全一致，悬停仅显示消耗机械能/红石量，不再附加玩法说明。 */
public class PunchPistonBlueprintItem extends BlueprintItem {
    public PunchPistonBlueprintItem(Properties properties, EntityType<? extends PunchPistonEntity> entityType,
                                    int redstoneCost, int energyCost, int cooldownTicks) {
        // 放置音效为模组自注册的 punch_piston_place，播放时才从 DeferredHolder 取值。
        super(properties, entityType, redstoneCost, energyCost, cooldownTicks,
                GeneratedMod.PUNCH_PISTON_PLACE);
    }
}
