package cn.blockforge.generated.machinerylegend.effect;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.MachineryEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;

/** 反逆效果的阵营和器械索敌规则。 */
public final class RebellionLogic {
    private RebellionLogic() {}

    /**
     * 创造模式与旁观模式的玩家永远不作为索敌目标。
     *
     * <p>旁观模式本来就被 {@code canBeSeenByAnyone()} 挡掉，但创造模式玩家仍然可见；
     * 反逆会让“同阵营”关系覆盖原版的目标筛选，所以必须在反逆索敌规则里显式排除。</p>
     */
    public static boolean isUntargetablePlayer(LivingEntity entity) {
        return entity instanceof Player player && (player.isCreative() || player.isSpectator());
    }

    public enum Faction {
        MACHINE,
        MONSTER,
        FRIENDLY
    }

    public static boolean isRebel(LivingEntity entity) {
        return entity.hasEffect(GeneratedMod.REBELLION);
    }

    /**
     * 客户端渲染用的反逆判据。
     *
     * <p>与服务端的 {@link #isRebel} 不同，这里额外认 {@link GeneratedMod#REBELLION_FLAG}
     * 这个可同步附件：1.21 起非玩家实体的药水效果不会同步给其他客户端，客户端
     * {@code getActiveEffects()} 里根本没有别人身上的效果，只查效果会让品红发光层永远不亮。
     * 效果判定保留，覆盖“玩家自己”这条本地即时可见的路径。</p>
     */
    public static boolean isRebelVisual(LivingEntity entity) {
        return entity.getData(GeneratedMod.REBELLION_FLAG) || entity.hasEffect(GeneratedMod.REBELLION);
    }

    public static Faction faction(LivingEntity entity) {
        if (entity instanceof MachineryEntity) return Faction.MACHINE;
        if (entity instanceof Enemy) return Faction.MONSTER;
        return Faction.FRIENDLY;
    }

    public static boolean sameFaction(LivingEntity first, LivingEntity second) {
        return faction(first) == faction(second);
    }

    /** 器械主体的当前目标规则。 */
    public static boolean canMachineAttack(Entity machine, LivingEntity target) {
        if (target == machine || !target.isAlive()) return false;
        // 创造/旁观玩家不作为任何器械（含反逆器械）的目标。
        if (isUntargetablePlayer(target)) return false;
        if (machine instanceof LivingEntity living && isRebel(living)) {
            return !(target instanceof Enemy) && !isRebel(target);
        }
        // 正常器械：原有的“打怪物 + 打反逆者”规则里，只把“反逆怪物”摘出去。
        // 反逆怪物已被对立阵营当成队友，正常器械不再攻击它；反逆器械/反逆玩家等非怪物目标照旧是敌人。
        return isRebel(target) != (target instanceof Enemy);
    }

    /** 器械弹药的当前命中规则，owner 为空时保留旧的敌对生物过滤。 */
    public static boolean canMachineProjectileHit(Entity owner, Entity target) {
        if (!(target instanceof LivingEntity living) || !living.isAlive() || target == owner) return false;
        if (!(owner instanceof LivingEntity)) return target instanceof Enemy && !isRebel(living);
        return canMachineAttack(owner, living);
    }

    /** 传染发射器的反逆版机器寄染会攻击其他器械和友善生物（创造/旁观玩家除外）。 */
    public static boolean canRebelParasiteTarget(LivingEntity carrier, LivingEntity target) {
        if (target == null || !target.isAlive() || target == carrier) return false;
        if (isUntargetablePlayer(target)) return false;
        return target instanceof MachineryEntity || !(target instanceof Enemy);
    }

    public static boolean canRebelParasiteTarget(Entity carrier, LivingEntity target) {
        return canRebelParasiteTarget(carrier instanceof LivingEntity living ? living : null, target);
    }
}
