package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.entity.PoweredCartEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.server.level.ServerLevel;

import java.util.List;

/** 一次性动力推车：只能放置在铁轨上，放置后转化为动力推车实体。 */
public final class PoweredCartItem extends Item {
    public PoweredCartItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.powered_cart_hint").withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.translatable("tooltip.machinery_legend.powered_cart"));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.FAIL;

        BlockPos clickedPos = context.getClickedPos();
        BlockState clickedState = level.getBlockState(clickedPos);
        BlockPos spawnPos = clickedPos.relative(context.getClickedFace());
        double spawnX = spawnPos.getX() + 0.5;
        double spawnY = spawnPos.getY();
        double spawnZ = spawnPos.getZ() + 0.5;

        // 铁轨上沿用矿车高度；其他方块则按点击面放置，避免实体出生在方块内部。
        if (BaseRailBlock.isRail(clickedState)) {
            spawnPos = clickedPos;
            spawnX = clickedPos.getX() + 0.5;
            spawnY = clickedPos.getY() + 0.0625;
            spawnZ = clickedPos.getZ() + 0.5;
            if (clickedState.getBlock() instanceof BaseRailBlock rail) {
                RailShape shape = rail.getRailDirection(clickedState, level, clickedPos, null);
                if (shape.isAscending()) spawnY += 0.5;
            }
        } else if (context.getClickedFace() != Direction.UP) {
            return InteractionResult.FAIL;
        }

        if (!BaseRailBlock.isRail(clickedState) && !level.getBlockState(spawnPos).isAir()) return InteractionResult.FAIL;
        if (!BaseRailBlock.isRail(clickedState)) {
            AABB spawnBox = new AABB(spawnX - 0.75, spawnY, spawnZ - 0.75,
                    spawnX + 0.75, spawnY + 1.0, spawnZ + 0.75);
            if (!level.noCollision(null, spawnBox)) return InteractionResult.FAIL;
        }

        if (!level.isClientSide && level instanceof ServerLevel serverLevel) {
            PoweredCartEntity cart = new PoweredCartEntity(
                    cn.blockforge.generated.machinerylegend.GeneratedMod.POWERED_CART_ENTITY.get(), serverLevel);
            cart.moveTo(spawnX, spawnY, spawnZ, player.getYRot(), 0.0f);
            cart.setYRot(player.getYRot());
            cart.setOnGround(BaseRailBlock.isRail(clickedState));
            if (!serverLevel.addFreshEntity(cart)) return InteractionResult.FAIL;
            if (!player.isCreative()) context.getItemInHand().shrink(1);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
