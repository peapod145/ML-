package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.ThrowingKnifeEntity;
import net.minecraft.client.renderer.entity.ArrowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/** 飞行中的飞刀：沿用箭矢的飞行姿态渲染，贴图换成飞刀。 */
public class ThrowingKnifeRenderer extends ArrowRenderer<ThrowingKnifeEntity> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/projectile/throwing_knife.png");

    public ThrowingKnifeRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(ThrowingKnifeEntity entity) {
        return TEXTURE;
    }
}
