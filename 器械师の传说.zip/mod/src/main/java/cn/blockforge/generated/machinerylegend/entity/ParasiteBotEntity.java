package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * 传染发射器射出的寄生机器人：命中敌对生物时造成 2 点伤害并附加 30 秒“机器寄染”。
 * 只与敌对生物结算命中，玩家与中立/友好生物直接穿过；射出 10 秒后自毁。
 *
 * <p>命中伤害完全无视目标无敌帧，做法与炽炎弹完全一致：使用带
 * {@code minecraft:bypasses_cooldown} 标签的专用伤害类型，让原版
 * {@code LivingEntity.hurt} 里“受伤后 10 刻内、这一刀不超过上一刀就整刀吞掉”的
 * 冷却判定被短路；命中瞬间再把 {@code invulnerableTime} 清零一次作为兜底。
 * 因此携带“机器寄染”的怪群互相开火时，哪怕目标正处在着火/灼烧刷新的无敌帧里，
 * 每一枚寄生机器人的 2 点伤害也照常全额结算。</p>
 *
 * <p>该伤害类型除多一个 bypasses_cooldown 标签外与原版 {@code thrown} 逐字一致
 * （exhaustion 0.1、message_id thrown、同样在 {@code is_projectile} 标签内），
 * 所以护甲、保护附魔、死亡消息等结算表现一律保持原样；它刻意不带 {@code is_fire}
 * 标签，以免烈焰人等防火生物反而对整个寄生机器人免疫。</p>
 *
 * <p>不带弹道下坠：关闭重力后沿发射方向直线飞行，出膛速度 0.72 保持不变。</p>
 */
public class ParasiteBotEntity extends Snowball {
    private static final float DAMAGE = 2.0f;
    private static final int PARASITE_DURATION_TICKS = 20 * 30;
    private static final int MAX_LIFETIME_TICKS = 10 * 20;
    private static final EntityDataAccessor<Boolean> DATA_REBEL_ORIGIN =
            SynchedEntityData.defineId(ParasiteBotEntity.class, EntityDataSerializers.BOOLEAN);
    /**
     * 寄生机器人专用伤害类型：定义见
     * {@code data/machinery_legend/damage_type/parasite_bot.json}，标签见
     * {@code data/minecraft/tags/damage_type/bypasses_cooldown.json} 与
     * {@code is_projectile.json}（均为 replace:false，只追加不覆盖原版成员）。
     */
    public static final ResourceKey<DamageType> PARASITE_BOT_DAMAGE =
            ResourceKey.create(Registries.DAMAGE_TYPE,
                    ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "parasite_bot"));

    public ParasiteBotEntity(EntityType<ParasiteBotEntity> type, Level level) {
        super(type, level);
        // 关闭重力：器械射出的弹药按直线弹道飞行，不随距离下坠（速度不变）。
        setNoGravity(true);
    }

    public ParasiteBotEntity(EntityType<ParasiteBotEntity> type, Entity owner, Level level) {
        this(type, level);
        setOwner(owner);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_REBEL_ORIGIN, false);
    }

    public void setRebelOrigin(boolean rebel) {
        entityData.set(DATA_REBEL_ORIGIN, rebel);
    }

    public boolean isRebelOrigin() {
        return entityData.get(DATA_REBEL_ORIGIN);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || isRemoved()) return;
        if (tickCount >= MAX_LIFETIME_TICKS) discard();
    }

    /**
     * 被弹开的回调（盾牌格挡、旋风投射等任何 deflect 路径）：出膛时关闭的重力在反弹后立刻恢复，
     * 寄生机器人不再直线飞行，改回正常下坠。
     */
    @Override
    protected void onDeflection(Entity cause, boolean playSound) {
        super.onDeflection(cause, playSound);
        setNoGravity(false);
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return canAffect(entity) && super.canHitEntity(entity);
    }

    /**
     * 本枚弹体的合法命中目标：反逆来源用器械的反逆规则；正常来源仍只打敌对生物，
     * 但把受了反逆效果的怪物当成队友放过（正常器械不攻击反逆怪物）。
     */
    private boolean canAffect(Entity entity) {
        if (!(entity instanceof LivingEntity living) || entity == getOwner()) return false;
        if (isRebelOrigin()) {
            return RebellionLogic.canRebelParasiteTarget(getOwner(), living);
        }
        return living instanceof Enemy && !RebellionLogic.isRebel(living);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        if (result.getEntity() instanceof LivingEntity target && canAffect(target)) {
            // 无视无敌帧双保险：专用伤害类型带 bypasses_cooldown 标签（主机制），
            // 命中瞬间再清零一次 invulnerableTime（兜底）。
            MachineryEntity.clearInvulnerabilityForMachineryAttack(target);
            target.hurt(parasiteBotDamageSource(), DAMAGE);
            target.addEffect(new MobEffectInstance(GeneratedMod.MACHINE_PARASITE, PARASITE_DURATION_TICKS,
                    isRebelOrigin() ? 1 : 0, false, true));
        }
        discard();
    }

    /**
     * 寄生机器人伤害源：优先使用带 bypasses_cooldown 标签的专用伤害类型（除标签外与原版
     * {@code thrown} 完全等价）；万一数据包条目缺失，也退回原版 {@code thrown}，
     * 宁可退化成只靠 invulnerableTime 清零，也不能在命中瞬间抛异常打断服务端 tick。
     */
    private DamageSource parasiteBotDamageSource() {
        Holder<DamageType> type = level().registryAccess().lookupOrThrow(Registries.DAMAGE_TYPE)
                .get(PARASITE_BOT_DAMAGE).orElse(null);
        return type != null ? new DamageSource(type, this, getOwner())
                : level().damageSources().thrown(this, getOwner());
    }

    @Override
    protected void onHit(HitResult result) {
        // 与普通雪球一致：保留父类的命中分派，否则实体命中不会进入 onHitEntity。
        super.onHit(result);
        if (!isRemoved()) discard();
    }
}
