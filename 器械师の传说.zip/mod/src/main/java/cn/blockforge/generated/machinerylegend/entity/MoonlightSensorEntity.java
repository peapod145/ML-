package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.player.EnergyData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.sounds.SoundSource;

/** 月光传感器：夜间产出机械能，经过 120 秒后展开四角感应片并加快产能。 */
public class MoonlightSensorEntity extends MachineryEntity {
    private static final EntityDataAccessor<Boolean> DATA_UPGRADED =
            SynchedEntityData.defineId(MoonlightSensorEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_AWAKENED =
            SynchedEntityData.defineId(MoonlightSensorEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_DAY_SLEEPING =
            SynchedEntityData.defineId(MoonlightSensorEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_EMPOWERED =
            SynchedEntityData.defineId(MoonlightSensorEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_UPGRADE_ANIMATION_TICKS =
            SynchedEntityData.defineId(MoonlightSensorEntity.class, EntityDataSerializers.INT);
    private static final int UPGRADE_TICKS = 120 * 20;
    private static final int UPGRADE_ANIMATION_TICKS = 20;
    private static final int NORMAL_ENERGY_PERIOD = 32;
    private static final int UPGRADED_ENERGY_PERIOD = 20;
    private static final int EMPOWERED_ENERGY_PERIOD = 10;
    private int upgradeTicks;
    private int energyTicks;

    public MoonlightSensorEntity(EntityType<? extends MoonlightSensorEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_UPGRADED, false);
        builder.define(DATA_AWAKENED, false);
        builder.define(DATA_DAY_SLEEPING, false);
        builder.define(DATA_EMPOWERED, false);
        builder.define(DATA_UPGRADE_ANIMATION_TICKS, 0);
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.DAYLIGHT_DETECTOR.defaultBlockState();
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;

        if (isEmpowered()) spawnEmpoweredStarParticles();

        // 睡觉（白天休眠）不计入升级计时：只有清醒工作的时间才累积升级进度。
        boolean daySleeping = isDaySleeping();
        if (entityData.get(DATA_DAY_SLEEPING) != daySleeping) {
            entityData.set(DATA_DAY_SLEEPING, daySleeping);
        }

        if (!isUpgraded()) {
            if (!daySleeping) upgradeTicks++;
            if (upgradeTicks >= UPGRADE_TICKS) {
                entityData.set(DATA_UPGRADED, true);
                entityData.set(DATA_UPGRADE_ANIMATION_TICKS, UPGRADE_ANIMATION_TICKS);
                level().playSound(null, blockPosition(), GeneratedMod.MOONLIGHT_SENSOR_UPGRADE.get(),
                        SoundSource.BLOCKS, 1.0f, 1.0f);
            }
        } else if (getUpgradeAnimationTicks() > 0) {
            entityData.set(DATA_UPGRADE_ANIMATION_TICKS, getUpgradeAnimationTicks() - 1);
        }

        if (daySleeping) return;

        int period = isEmpowered() ? EMPOWERED_ENERGY_PERIOD
                : (isUpgraded() ? UPGRADED_ENERGY_PERIOD : NORMAL_ENERGY_PERIOD);
        if (++energyTicks < period) return;
        energyTicks = 0;
        if (!(level() instanceof ServerLevel serverLevel)) return;

        long chunkKey = chunkPosition().toLong();
        for (Player player : serverLevel.getPlayers(candidate -> candidate.chunkPosition().toLong() == chunkKey)) {
            EnergyData.add(player, 1);
        }
    }

    public boolean isUpgraded() {
        return entityData.get(DATA_UPGRADED);
    }

    public int getUpgradeAnimationTicks() {
        return entityData.get(DATA_UPGRADE_ANIMATION_TICKS);
    }

    public float getUpgradeAnimationProgress(float partialTick) {
        if (!isUpgraded()) return 0.0f;
        float remaining = getUpgradeAnimationTicks() - partialTick;
        return Math.max(0.0f, Math.min(1.0f, 1.0f - remaining / (float) UPGRADE_ANIMATION_TICKS));
    }

    public boolean isDaySleeping() {
        // 激发潜能后持续工作；否则升级状态白天休眠，升级前仍可由荧石粉唤醒。
        return !isEmpowered() && level().isDay() && (isUpgraded() || !isPermanentlyAwake());
    }

    public boolean isEmpowered() {
        return entityData.get(DATA_EMPOWERED);
    }

    public boolean shouldRenderSleepingIndicator() {
        return entityData.get(DATA_DAY_SLEEPING);
    }

    /** 与小型发射器一致：荧石粉右键后白天也可工作。 */
    public boolean isPermanentlyAwake() {
        return entityData.get(DATA_AWAKENED);
    }

    public void wake() {
        if (!level().isClientSide) {
            entityData.set(DATA_AWAKENED, true);
            entityData.set(DATA_DAY_SLEEPING, false);
        }
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide) return;
        entityData.set(DATA_UPGRADED, true);
        entityData.set(DATA_UPGRADE_ANIMATION_TICKS, UPGRADE_ANIMATION_TICKS);
        entityData.set(DATA_EMPOWERED, true);
        upgradeTicks = UPGRADE_TICKS;
        startEvocationEffect();
        level().playSound(null, blockPosition(), GeneratedMod.MOONLIGHT_SENSOR_UPGRADE.get(),
                SoundSource.BLOCKS, 1.0f, 1.0f);
    }

    /** 激发潜能后，传感器周围持续飘落少量小星星特效。 */
    private void spawnEmpoweredStarParticles() {
        if (tickCount % 8 != 0 || !(level() instanceof ServerLevel serverLevel)) return;
        serverLevel.sendParticles(ParticleTypes.END_ROD,
                getX(), getY() + 0.62 + random.nextDouble() * 0.28, getZ(),
                1, 0.34, 0.18, 0.34, 0.012);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Awake", isPermanentlyAwake());
        tag.putBoolean("Upgraded", isUpgraded());
        tag.putBoolean("Empowered", isEmpowered());
        tag.putInt("UpgradeTicks", upgradeTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        upgradeTicks = tag.getInt("UpgradeTicks");
        if (tag.getBoolean("Upgraded") || upgradeTicks >= UPGRADE_TICKS) entityData.set(DATA_UPGRADED, true);
        if (tag.getBoolean("Empowered")) entityData.set(DATA_EMPOWERED, true);
        if (tag.getBoolean("Awake")) entityData.set(DATA_AWAKENED, true);
    }
}
