package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ServerLevelAccessor;

/** 统一处理入侵旗帜载体和固定护卫。 */
public final class InvasionMobLogic {
    public static final String CARRIER_KEY = "machinery_legend_invasion_carrier";
    public static final String PENDING_CARRIER_KEY = "machinery_legend_invasion_pending_carrier";
    private static final String GUARDS_SPAWNED_KEY = "machinery_legend_invasion_guards_spawned";
    private static final String GUARD_KEY = "machinery_legend_invasion_guard";

    private InvasionMobLogic() {}

    public static boolean shouldRollForCarrier(MobSpawnType spawnType) {
        return spawnType != MobSpawnType.CONVERSION;
    }

    public static boolean isCarrier(LivingEntity entity) {
        return entity.getPersistentData().getBoolean(CARRIER_KEY)
                || entity.getItemBySlot(EquipmentSlot.MAINHAND).is(GeneratedMod.INVASION_FLAG.get())
                || entity.getItemBySlot(EquipmentSlot.OFFHAND).is(GeneratedMod.INVASION_FLAG.get());
    }

    public static boolean isFlaggedZombieFamily(LivingEntity entity) {
        return entity instanceof InvasionZombieEntity
                || entity instanceof InvasionHuskEntity
                || entity instanceof InvasionDrownedEntity
                || entity.getType() == EntityType.ZOMBIE
                || entity.getType() == EntityType.HUSK
                || entity.getType() == EntityType.DROWNED;
    }

    public static boolean isGuard(LivingEntity entity) {
        return entity.getPersistentData().getBoolean(GUARD_KEY);
    }

    public static void initializeCarrier(Mob carrier, ServerLevelAccessor level) {
        carrier.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(GeneratedMod.INVASION_FLAG.get()));
        carrier.setGuaranteedDrop(EquipmentSlot.MAINHAND);
        carrier.setCanPickUpLoot(false);
        carrier.setPersistenceRequired();
        carrier.getPersistentData().putBoolean(CARRIER_KEY, true);

        if (carrier.getPersistentData().getBoolean(GUARDS_SPAWNED_KEY)) return;
        carrier.getPersistentData().putBoolean(GUARDS_SPAWNED_KEY, true);

        ServerLevel serverLevel = level.getLevel();
        spawnGuard(serverLevel, carrier, 1.25, 0.0, 0);
        spawnGuard(serverLevel, carrier, -1.25, 0.0, 1);
        spawnGuard(serverLevel, carrier, 0.0, 1.25, 2);
    }

    private static EntityType<? extends Zombie> guardTypeFor(Mob carrier) {
        if (carrier instanceof InvasionDrownedEntity || carrier.getType() == EntityType.DROWNED) {
            return EntityType.DROWNED;
        }
        if (carrier instanceof InvasionHuskEntity || carrier.getType() == EntityType.HUSK) {
            return EntityType.HUSK;
        }
        return EntityType.ZOMBIE;
    }

    private static void spawnGuard(ServerLevel level, Mob carrier, double offsetX, double offsetZ, int armorSet) {
        Zombie guard = guardTypeFor(carrier).create(level);
        if (guard == null) return;

        guard.moveTo(carrier.getX() + offsetX, carrier.getY(), carrier.getZ() + offsetZ, carrier.getYRot(), 0.0f);
        guard.getPersistentData().putBoolean(GUARD_KEY, true);
        guard.finalizeSpawn(level, level.getCurrentDifficultyAt(guard.blockPosition()), MobSpawnType.MOB_SUMMONED, null);
        guard.setBaby(false);
        guard.setPersistenceRequired();
        guard.setCanPickUpLoot(false);
        setNoArmorDrops(guard);

        if (armorSet == 0) {
            guard.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.LEATHER_HELMET));
            guard.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.LEATHER_CHESTPLATE));
            guard.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.LEATHER_LEGGINGS));
            guard.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.LEATHER_BOOTS));
        } else if (armorSet == 1) {
            guard.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
            guard.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
            guard.setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
            guard.setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
        } else {
            guard.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
            guard.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
            guard.setItemSlot(EquipmentSlot.LEGS, ItemStack.EMPTY);
            guard.setItemSlot(EquipmentSlot.FEET, ItemStack.EMPTY);
        }

        level.addFreshEntity(guard);
    }

    private static void setNoArmorDrops(Mob guard) {
        guard.setDropChance(EquipmentSlot.HEAD, 0.0f);
        guard.setDropChance(EquipmentSlot.CHEST, 0.0f);
        guard.setDropChance(EquipmentSlot.LEGS, 0.0f);
        guard.setDropChance(EquipmentSlot.FEET, 0.0f);
    }
}
