package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.GargoyleEntity;
import net.minecraft.client.model.AnimationUtils;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * 石像鬼模型：只采用僵尸模型（用户定案，几何与动画均与原版僵尸一致）。
 * <p>几何与 UV 采用原版僵尸的同一套标准人形布局（64×64 皮肤版式，
 * 头 0,0 / 身 16,16 / 臂 40,16 / 腿 0,16），因此石像鬼贴图逐像素吻合。</p>
 * <p>动画与原版 {@code AbstractZombieModel#setupAnim} 完全同构：先走
 * {@link HumanoidModel#setupAnim} 人形基础动画（摆腿/头部跟随等，这正是原版僵尸继承的部分），
 * 再调用 {@link AnimationUtils#animateZombieArms}——双臂前伸悬垂、锁定目标时挥臂，
 * 与僵尸表现一致。受击换贴图由渲染器按血量整张切换贴图完成，模型层无叠加。</p>
 */
public final class GargoyleModel extends HumanoidModel<GargoyleEntity> {

    public GargoyleModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(GargoyleEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // 与 AbstractZombieModel#setupAnim 相同结构：人形基础动画 + 僵尸手臂
        super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        // isAggressive 取实体锁敌态（Mob#isAggressive，客户端随目标同步可见），攻击时手臂挥动与僵尸一致
        AnimationUtils.animateZombieArms(this.leftArm, this.rightArm, entity.isAggressive(),
                this.attackTime, ageInTicks);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.ZERO);
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(16, 16)
                        .addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16)
                        .addBox(-2.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(40, 16).mirror()
                        .addBox(-2.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16)
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-2.0F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(0, 16).mirror()
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(2.0F, 12.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }
}
