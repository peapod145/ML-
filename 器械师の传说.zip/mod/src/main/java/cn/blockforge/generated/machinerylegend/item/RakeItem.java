package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.RakeEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** 器械钉耙本体；装备后为铁锄提供按键放置能力。 */
public final class RakeItem extends Item {
    private static final int HOE_DAMAGE = 175;
    private static final double MAX_REACH_SQR = 6.0 * 6.0;

    public RakeItem(Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.machinery_rake",
                Component.keybind("key.machinery_legend.place_rake")));
    }

    public static boolean isActive(Player player) {
        for (int slot = 0; slot < 9; slot++) {
            if (player.getInventory().getItem(slot).is(GeneratedMod.MACHINERY_RAKE.get())) return true;
        }
        return CuriosCompat.isEquipped(player, GeneratedMod.MACHINERY_RAKE.get());
    }

    public static void tryPlace(ServerPlayer player, BlockPos blockPos) {
        if (!(player.level() instanceof ServerLevel level) || !isActive(player)) return;
        if (!isHoldingIronHoe(player)) return;
        if (player.distanceToSqr(Vec3.atCenterOf(blockPos)) > MAX_REACH_SQR) return;

        BlockState state = level.getBlockState(blockPos);
        if (!state.isCollisionShapeFullBlock(level, blockPos)
                || !state.isFaceSturdy(level, blockPos, Direction.UP)) return;

        BlockPos placePos = blockPos.above();
        AABB entityBox = new AABB(placePos.getX() + 0.5 - 0.75, placePos.getY(),
                placePos.getZ() + 0.5 - 0.75, placePos.getX() + 0.5 + 0.75,
                placePos.getY() + 1.0, placePos.getZ() + 0.5 + 0.75);
        if (!level.noCollision(entityBox) || !level.getEntities((Entity) null, entityBox,
                entity -> entity.isAlive() && entity.getBoundingBox().intersects(entityBox)).isEmpty()) return;

        RakeEntity rake = GeneratedMod.RAKE.get().create(level);
        if (rake == null) return;
        rake.moveTo(placePos.getX() + 0.5, placePos.getY(), placePos.getZ() + 0.5, 0.0f, 0.0f);
        rake.setYRot(player.getYRot());
        if (!level.addFreshEntity(rake)) return;

        ItemStack hoe = player.getMainHandItem();
        if (!player.getAbilities().instabuild) {
            hoe.hurtAndBreak(HOE_DAMAGE, player, net.minecraft.world.entity.EquipmentSlot.MAINHAND);
        }
        level.playSound(null, placePos, state.getSoundType().getPlaceSound(),
                net.minecraft.sounds.SoundSource.BLOCKS,
                state.getSoundType().getVolume(), state.getSoundType().getPitch());
    }

    private static boolean isHoldingIronHoe(Player player) {
        return player.getMainHandItem().is(Items.IRON_HOE);
    }
}
