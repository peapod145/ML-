package cn.blockforge.generated.machinerylegend.mixin;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * 取出 {@link TargetGoal} 里的 {@code mob} 字段。
 *
 * <p>该字段声明在父类 {@code TargetGoal} 上，子类 {@code NearestAttackableTargetGoal}
 * 自身并没有这个字段，因此在子类的 mixin 里用 {@code @Shadow} 会在 APPLY 阶段
 * 直接抛 {@code InvalidMixinException} 导致游戏启动崩溃。这里改成对声明类做
 * accessor，取用方通过接口转换拿到值。</p>
 */
@Mixin(TargetGoal.class)
public interface TargetGoalAccessor {
    @Accessor("mob")
    Mob machineryLegendGetMob();
}
