package cn.blockforge.generated.machinerylegend.mixin;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 让普通敌对怪物把被反逆的怪物当成正常可锁定的目标。
 *
 * <p>这才是“怪物不攻击反逆怪物”的真正原因：原版
 * {@link NearestAttackableTargetGoal#findTarget()} 在以 {@code Player.class} 为目标的
 * 分支里只调用 {@code getNearestPlayer}，候选集合里清一色是玩家，反逆怪物压根不会
 * 被考虑；因此无论 {@code TargetingConditions} 怎么放行都锁不到目标。</p>
 *
 * <p>这里在目标已经选完之后补一次检索：只有在原版一个目标都没挑到时才会落入，
 * 所以不会顶掉正在追的玩家，也不是额外的强制搜猎；命中后由原版目标 Goal 正常
 * 启动并维持该目标。</p>
 */
@Mixin(NearestAttackableTargetGoal.class)
public abstract class NearestAttackableTargetGoalMixin {
    @Shadow
    protected LivingEntity target;
    @Shadow
    protected TargetingConditions targetConditions;

    @Inject(method = "findTarget", at = @At("TAIL"))
    private void machineryLegend$alsoFindRebel(CallbackInfo ci) {
        // 原版已经挑到目标（玩家等）时不插手，避免抢走仇恨。
        if (this.target != null) return;
        // mob 声明在父类 TargetGoal 上，不能在本 mixin 里 @Shadow，改走 accessor。
        Mob self = ((TargetGoalAccessor) (Object) this).machineryLegendGetMob();
        if (self.level().isClientSide || self.isNoAi() || !self.isEffectiveAi()) return;
        // 反逆者由自己的同阵营逻辑控制；这里只负责普通敌对怪物。
        if (!(self instanceof Enemy) || RebellionLogic.isRebel(self)) return;
        LivingEntity rebel = machineryLegend$nearestRebel(self);
        if (rebel != null) this.target = rebel;
    }

    @Unique
    private LivingEntity machineryLegend$nearestRebel(Mob self) {
        double range = self.getAttributeValue(Attributes.FOLLOW_RANGE);
        AABB area = self.getBoundingBox().inflate(range, 4.0, range);
        LivingEntity nearest = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity candidate : self.level().getEntitiesOfClass(LivingEntity.class, area,
                entity -> entity != self && entity.isAlive() && entity instanceof Enemy
                        && RebellionLogic.isRebel(entity))) {
            // 复用该 Goal 自己的索敌条件：距离、视线、选择器以及反逆阵营放行全都一致。
            if (!this.targetConditions.test(self, candidate)) continue;
            double distance = self.distanceToSqr(candidate);
            if (distance < best) {
                best = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }
}
