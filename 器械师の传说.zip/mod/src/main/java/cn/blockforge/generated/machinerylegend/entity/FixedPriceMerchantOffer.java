package cn.blockforge.generated.machinerylegend.entity;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.MerchantOffer;

import java.util.Optional;

/** 交易价格固定，不受需求、声望或英雄村民效果影响的交易报价。 */
final class FixedPriceMerchantOffer extends MerchantOffer {
    FixedPriceMerchantOffer(ItemCost costA, Optional<ItemCost> costB, ItemStack result,
                            int maxUses, int xp, float priceMultiplier, int uses) {
        super(costA, costB, result, maxUses, xp, priceMultiplier);
        for (int index = 0; index < uses; index++) {
            increaseUses();
        }
    }

    static FixedPriceMerchantOffer from(MerchantOffer offer) {
        FixedPriceMerchantOffer fixedOffer = new FixedPriceMerchantOffer(
                offer.getItemCostA(),
                offer.getItemCostB(),
                offer.getResult().copy(),
                offer.getMaxUses(),
                offer.getXp(),
                offer.getPriceMultiplier(),
                offer.getUses());
        if (offer.isOutOfStock()) {
            fixedOffer.setToOutOfStock();
        }
        return fixedOffer;
    }

    @Override
    public ItemStack getCostA() {
        return getBaseCostA().copy();
    }

    @Override
    public void updateDemand() {
        // 固定价格交易不随使用次数调整需求。
    }

    @Override
    public int getDemand() {
        return 0;
    }

    @Override
    public void addToSpecialPriceDiff(int amount) {
        // 固定价格交易不接受声望或效果带来的价格调整。
    }

    @Override
    public void resetSpecialPriceDiff() {
        // 固定价格交易始终保持基础价格。
    }

    @Override
    public void setSpecialPriceDiff(int specialPriceDiff) {
        // 固定价格交易始终保持基础价格。
    }

    @Override
    public int getSpecialPriceDiff() {
        return 0;
    }

    @Override
    public float getPriceMultiplier() {
        return 0.0f;
    }

    @Override
    public MerchantOffer copy() {
        return from(this);
    }
}
