package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.GhostEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** 按 64×32 玩家皮肤布局渲染幽灵，而不是按僵尸模型重新解释贴图。 */
public final class GhostRenderer extends HumanoidMobRenderer<GhostEntity, GhostModel> {
    public static final ModelLayerLocation MODEL_LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "ghost"), "main");
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/ghost.png");
    private static final ResourceLocation TRANSLUCENT_TEXTURE = ResourceLocation.fromNamespaceAndPath(
            GeneratedMod.MOD_ID, "textures/entity/ghost_translucent.png");

    public GhostRenderer(EntityRendererProvider.Context context) {
        super(context, new GhostModel(context.bakeLayer(MODEL_LAYER)), 0.5F);
        // 原版 HumanoidMobRenderer 不自带盔甲层：僵尸显示盔甲/头饰是 AbstractZombieRenderer
        // 显式追加 HumanoidArmorLayer 实现的。这里照原版补上同样的层，幽灵生成时戴的头饰
        // 才会在客户端实际渲染出来（贴图仍走 machinery_legend:ghost_helmet 的材质定义）。
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.ZOMBIE_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(GhostEntity entity) {
        return entity.isGhostTransparent() ? TRANSLUCENT_TEXTURE : TEXTURE;
    }

    @Override
    protected RenderType getRenderType(GhostEntity entity, boolean bodyVisible,
                                       boolean translucent, boolean glowing) {
        if (entity.isGhostTransparent()) {
            return RenderType.entityTranslucent(TRANSLUCENT_TEXTURE);
        }
        return super.getRenderType(entity, bodyVisible, translucent, glowing);
    }
}
