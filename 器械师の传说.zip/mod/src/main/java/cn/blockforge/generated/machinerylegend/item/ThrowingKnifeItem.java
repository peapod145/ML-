package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.ThrowingKnifeEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

/**
 * 飞刀：与原版三叉戟一致的蓄力投掷武器。
 * 长按右键蓄力（按住不足 0.5 秒不掷出，同三叉戟 THROW_THRESHOLD_TIME），
 * 蓄力越久掷得越远，蓄力上限 1.5 秒（30 tick）且蓄力不增加伤害；
 * 手持形式沿用普通物品（与箭矢相同），不提供三叉戟那样的拉回模型。
 */
public class ThrowingKnifeItem extends Item {
    /** 最低蓄力：与三叉戟相同，10 tick（0.5 秒）才掷出。 */
    private static final int THROW_THRESHOLD_TICKS = 10;
    /** 蓄力满程：1.5 秒 = 30 tick，用于计算投掷初速。 */
    private static final int MAX_CHARGE_TICKS = 30;

    public ThrowingKnifeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.SPEAR;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        // 与三叉戟相同：不自动结束使用，只在松手时结算。
        return 72000;
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!(entity instanceof Player player)) {
            return;
        }
        int usedTicks = this.getUseDuration(stack, entity) - timeLeft;
        if (usedTicks < THROW_THRESHOLD_TICKS) {
            return;
        }
        player.awardStat(Stats.ITEM_USED.get(this));
        if (level.isClientSide) {
            return;
        }
        // 蓄力比例 1/3（刚过阈值）到 1（满蓄力），初速 1.9~2.8：蓄力越久投得越远。
        float ratio = Math.min(usedTicks, MAX_CHARGE_TICKS) / (float) MAX_CHARGE_TICKS;
        ThrowingKnifeEntity knife = new ThrowingKnifeEntity(GeneratedMod.THROWING_KNIFE_PROJECTILE.get(), level);
        knife.setPos(player.getX(), player.getEyeY() - 0.1D, player.getZ());
        knife.setOwner(player);
        knife.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.5F + 1.3F * ratio, 0.0F);
        if (player.hasInfiniteMaterials()) {
            knife.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
        }
        level.addFreshEntity(knife);
        level.playSound(null, knife, SoundEvents.TRIDENT_THROW.value(), SoundSource.PLAYERS, 1.0F, 1.25F);
        if (!player.hasInfiniteMaterials()) {
            stack.shrink(1);
        }
    }
}
