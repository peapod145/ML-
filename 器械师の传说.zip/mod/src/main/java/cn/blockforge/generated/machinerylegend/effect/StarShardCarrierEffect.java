package cn.blockforge.generated.machinerylegend.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * 星之碎片携带标识：没有任何数值效果，只给携带者叠一层绿色药水光效，
 * 让玩家能一眼看出哪只怪物掉星之碎片。仅服务端赋给怪物，玩家不会获得。
 */
public class StarShardCarrierEffect extends MobEffect {
    /** 状态颜色：星之碎片的翠绿色。 */
    public static final int COLOR = 0x3FE04A;

    public StarShardCarrierEffect() {
        super(MobEffectCategory.NEUTRAL, COLOR);
    }
}
