package cn.blockforge.generated.machinerylegend;

import cn.blockforge.generated.machinerylegend.entity.EmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.MachineryEntity;
import cn.blockforge.generated.machinerylegend.entity.MineTntEntity;
import cn.blockforge.generated.machinerylegend.entity.SmallEmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.MoonlightSensorEntity;
import cn.blockforge.generated.machinerylegend.entity.InvasionDrownedEntity;
import cn.blockforge.generated.machinerylegend.entity.InvasionHuskEntity;
import cn.blockforge.generated.machinerylegend.entity.InvasionMobLogic;
import cn.blockforge.generated.machinerylegend.entity.InvasionZombieEntity;
import cn.blockforge.generated.machinerylegend.entity.StarShardCarrier;
import cn.blockforge.generated.machinerylegend.effect.StarShardCarrierEffect;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import cn.blockforge.generated.machinerylegend.item.MechanicalArmItem;
import cn.blockforge.generated.machinerylegend.item.StarShardItem;
import cn.blockforge.generated.machinerylegend.item.GhostHelmetItem;
import cn.blockforge.generated.machinerylegend.item.BestiaryItem;
import cn.blockforge.generated.machinerylegend.player.EnergyData;
import cn.blockforge.generated.machinerylegend.player.ShardData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.sounds.SoundSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.core.particles.DustParticleOptions;
import org.joml.Vector3f;
import net.neoforged.neoforge.event.entity.living.FinalizeSpawnEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;
import net.neoforged.neoforge.event.entity.living.LivingChangeTargetEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.entity.player.ItemEntityPickupEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;

public final class GameEvents {
    private static final String PENDING_HELMET_KEY = "machinery_legend_pending_helmet";
    private static final byte NO_HELMET = 0;
    private static final byte LEATHER_HELMET = 1;
    private static final byte IRON_HELMET = 2;
    private static final byte DIAMOND_HELMET = 3;
    private static final String SUNBURN_PROTECTION_KEY = "machinery_legend_sunburn_protection";

    private GameEvents() {}

    @SubscribeEvent
    public static void onFinalizeSpawn(FinalizeSpawnEvent event) {
        Mob mob = event.getEntity();
        if (!(mob instanceof Zombie zombie) || mob instanceof InvasionZombieEntity
                || mob instanceof InvasionHuskEntity || mob instanceof InvasionDrownedEntity) return;
        EntityType<?> type = zombie.getType();
        if (type != EntityType.ZOMBIE && type != EntityType.HUSK && type != EntityType.DROWNED) return;
        if (InvasionMobLogic.isGuard(zombie)) return;

        if (InvasionMobLogic.shouldRollForCarrier(event.getSpawnType())
                && zombie.level().random.nextFloat() < 0.08f) {
            zombie.getPersistentData().putBoolean(InvasionMobLogic.PENDING_CARRIER_KEY, true);
        }
        if (InvasionMobLogic.shouldRollForCarrier(event.getSpawnType())) {
            zombie.getPersistentData().putByte(PENDING_HELMET_KEY, rollSpawnHelmet(zombie));
        }
    }

    private static byte rollSpawnHelmet(Zombie zombie) {
        float roll = zombie.level().random.nextFloat();
        if (roll < 0.05f) return DIAMOND_HELMET;
        if (roll < 0.20f) return IRON_HELMET;
        if (roll < 0.47f) return LEATHER_HELMET;
        return NO_HELMET;
    }

    /** 生成时 5% 概率让符合条件的怪物携带星之碎片（先打标记，入世界后再上绿色效果）。 */
    @SubscribeEvent
    public static void onStarShardFinalizeSpawn(FinalizeSpawnEvent event) {
        Mob mob = event.getEntity();
        if (mob.level().isClientSide()) return;
        if (!StarShardCarrier.canCarry(mob)) return;
        if (InvasionMobLogic.isGuard(mob)) return;
        if (!InvasionMobLogic.shouldRollForCarrier(event.getSpawnType())) return;
        if (mob.getRandom().nextFloat() < StarShardCarrier.CARRY_CHANCE) {
            StarShardCarrier.markPending(mob);
        }
    }

    private static void applyPendingHelmet(Zombie zombie) {
        if (!zombie.getPersistentData().contains(PENDING_HELMET_KEY)) return;
        byte helmetType = zombie.getPersistentData().getByte(PENDING_HELMET_KEY);
        zombie.getPersistentData().remove(PENDING_HELMET_KEY);

        ItemStack helmet = switch (helmetType) {
            case DIAMOND_HELMET -> new ItemStack(Items.DIAMOND_HELMET);
            case IRON_HELMET -> new ItemStack(Items.IRON_HELMET);
            case LEATHER_HELMET -> new ItemStack(Items.LEATHER_HELMET);
            default -> ItemStack.EMPTY;
        };
        zombie.setItemSlot(EquipmentSlot.HEAD, helmet);
        if (!helmet.isEmpty()) zombie.setDropChance(EquipmentSlot.HEAD, 0.0f);
    }

    @SubscribeEvent
    public static void onEntityJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide() || event.loadedFromDisk()) return;
        if (!(event.getLevel() instanceof ServerLevel serverLevel) || !(event.getEntity() instanceof Zombie zombie)) return;
        EntityType<?> type = zombie.getType();
        if (type != EntityType.ZOMBIE && type != EntityType.HUSK && type != EntityType.DROWNED) return;
        if (InvasionMobLogic.isGuard(zombie)) return;
        applyPendingHelmet(zombie);
        if (zombie.getPersistentData().getBoolean(InvasionMobLogic.PENDING_CARRIER_KEY)) {
            zombie.getPersistentData().remove(InvasionMobLogic.PENDING_CARRIER_KEY);
            InvasionMobLogic.initializeCarrier(zombie, serverLevel);
        } else if (InvasionMobLogic.isCarrier(zombie)) {
            InvasionMobLogic.initializeCarrier(zombie, serverLevel);
        }
    }

    /** 实体真正进入世界时把“待携带”标记落地成绿光效果，并给老存档里的携带者补同步标记。 */
    @SubscribeEvent
    public static void onStarShardJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof Mob mob)) return;
        if (!event.loadedFromDisk() && mob.getPersistentData().getBoolean(StarShardCarrier.PENDING_KEY)) {
            StarShardCarrier.applyCarrier(mob);
            return;
        }
        // 老存档里已经是携带者的怪：补一次同步标记，客户端才看得到绿光，而不只是新生成的怪才有。
        // 同时把老存档里带粒子的效果换成隐藏版本，取消绿色药水粒子。
        if (StarShardCarrier.isCarrier(mob)) {
            StarShardCarrier.hideCarrierParticles(mob);
            StarShardCarrier.syncCarrierFlag(mob);
        }
    }

    /**
     * 绿色效果落到怪物身上时顺手把“携带者”同步标记置上：
     * 覆盖刷怪、指令给效果、老存档读档等所有路径，客户端都能据此画出绿光。
     */
    @SubscribeEvent
    public static void onCarrierEffectAdded(net.neoforged.neoforge.event.entity.living.MobEffectEvent.Added event) {
        if (event.getEntity().level().isClientSide()) return;
        if (!(event.getEntity() instanceof Mob mob)) return;
        if (event.getEffectInstance().getEffect().value() instanceof StarShardCarrierEffect) {
            StarShardCarrier.syncCarrierFlag(mob);
        }
    }

    /**
     * 反逆发光标识同步：1.21 起非玩家实体的药水效果不会同步给其他客户端，
     * 客户端拿不到别人身上的 REBELLION 效果，品红发光层因此永远不亮。
     * 这里每刻把服务端权威的“是否处于反逆”写进可同步附件，只在值变化时写一次，客户端据此画品红光；
     * 同时覆盖加效果、效果到期、净化、读档重进等所有路径。
     */
    @SubscribeEvent
    public static void onRebellionGlowSync(EntityTickEvent.Post event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getEntity() instanceof LivingEntity living)) return;
        boolean rebel = living.hasEffect(GeneratedMod.REBELLION);
        if (living.getData(GeneratedMod.REBELLION_FLAG) != rebel) {
            living.setData(GeneratedMod.REBELLION_FLAG, rebel);
        }
    }

    /** 统一拦截直接 setTarget（反击、自定义 AI 等），保证反逆阵营规则覆盖非目标选择器路径。 */
    @SubscribeEvent
    public static void onLivingChangeTarget(LivingChangeTargetEvent event) {
        LivingEntity attacker = event.getEntity();
        LivingEntity target = event.getNewAboutToBeSetTarget();
        if (target == null || attacker == target || !(attacker instanceof Mob) || attacker instanceof MachineryEntity) return;
        if (target instanceof MachineryEntity) return;
        // 只有“反逆者自己”受反逆阵营规则约束：反逆者之间互为队友，且只打同阵营的非反逆目标。
        // 普通怪物不在这里拦截——它们必须能正常锁定被反逆的怪物和玩家。
        // 注意：NeoForge 在 Mob.setTarget 内部触发本事件，一旦取消就不会写入 target，
        // 所有索敌 Goal 的锁定都会在这一步被丢掉，所以这里不能再拦普通怪物的反逆目标。
        if (!RebellionLogic.isRebel(attacker)) return;
        boolean allowed = !RebellionLogic.isRebel(target) && RebellionLogic.sameFaction(attacker, target);
        if (!allowed) event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;
        if (InvasionMobLogic.isGuard(entity)) {
            event.getDrops().removeIf(drop -> drop.getItem().getItem() instanceof net.minecraft.world.item.ArmorItem);
            return;
        }
        if (!InvasionMobLogic.isFlaggedZombieFamily(entity) || !InvasionMobLogic.isCarrier(entity)) return;
        event.getDrops().removeIf(drop -> drop.getItem().is(GeneratedMod.INVASION_FLAG.get()));
        ItemEntity flag = new ItemEntity(entity.level(), entity.getX(), entity.getY() + 0.25, entity.getZ(),
                new ItemStack(GeneratedMod.INVASION_FLAG.get()));
        event.getDrops().add(flag);
    }

    /**
     * 携带星之碎片的怪物死亡时额外掉 1 个星之碎片：
     * 掉落物持续发光，并在 {@link StarShardCarrier#DROP_LIFETIME_TICKS} 刻（15 秒）后消失。
     */
    @SubscribeEvent
    public static void onStarShardDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;
        if (!StarShardCarrier.isCarrier(entity)) return;
        ItemEntity shard = new ItemEntity(entity.level(), entity.getX(),
                entity.getY() + entity.getBbHeight() * 0.5, entity.getZ(),
                new ItemStack(GeneratedMod.STAR_SHARD.get()));
        shard.setDefaultPickUpDelay();
        shard.setGlowingTag(true);
        shard.getPersistentData().putBoolean(StarShardCarrier.DROP_KEY, true);
        // 碎片落地瞬间来一声经验升级音效，提示这只怪掉了星之碎片。
        entity.level().playSound(null, entity.blockPosition(), SoundEvents.PLAYER_LEVELUP,
                SoundSource.PLAYERS, 0.7f, 1.0f);
        event.getDrops().add(shard);
    }

    /**
     * 星之碎片一落地就标记为“永不拾取”（{@link ItemEntity#setNeverPickUp()}）。
     *
     * <p>原版生物捡拾掉落物之前都会先看 {@code ItemEntity#hasPickUpDelay()}：
     * {@code Mob#aiStep} 里那条通用拾取循环，以及狐狸、熊猫、海豚用 {@code ALLOWED_ITEMS}
     * 挑选目标的逻辑都包含这一步，所以狐狸之类的生物从“锁定目标”到“叼走”整条链路
     * 都会跳过星之碎片；掠夺者找旗帜、猪灵捡金子走的也同样是带这个前置判定的循环。</p>
     *
     * <p>玩家拾取不受影响：{@code ItemEntity#playerTouch} 会在拾取延迟判定之前触发
     * {@code ItemEntityPickupEvent.Pre}，{@link #onStarShardPickup} 已经在那里把碎片
     * 手动填进碎片槽，进而不依赖延迟、也不依赖原版进背包的流程。</p>
     */
    @SubscribeEvent
    public static void onStarShardItemJoinLevel(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof ItemEntity item)) return;
        if (item.getItem().is(GeneratedMod.STAR_SHARD.get())) {
            item.setNeverPickUp();
        }
    }

    @SubscribeEvent
    public static void onPlayerTickPre(PlayerTickEvent.Pre event) {
        GhostHelmetItem.beginTick(event.getEntity());
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        EnergyData.tick(event.getEntity());
        ShardData.tick(event.getEntity());
        cn.blockforge.generated.machinerylegend.item.BestiaryItem.tick(event.getEntity());
        GhostHelmetItem.tick(event.getEntity());
    }

    /**
     * 戴着幽灵天冠且饥饿值已满时，原版会拒绝开始进食（canEat 里 needsFood 为 false）。
     * 这里在右键食物时直接接管“开始吃”的动作：两侧都手动 startUsingItem 并以 SUCCESS
     * 取消事件，行为与原版 Item#use 的成功分支一致，客户端动画与服务器判定保持同步。
     * 吃完只按原版效果补充饱和度，不再额外恢复生命值。
     */
    @SubscribeEvent
    public static void onCrownedEatStart(PlayerInteractEvent.RightClickItem event) {
        Player player = event.getEntity();
        if (player.isSpectator() || player.getAbilities().invulnerable || player.isUsingItem()) return;
        if (!GhostHelmetItem.isWorn(player)) return;
        FoodProperties food = event.getItemStack().getFoodProperties(player);
        if (food == null || food.canAlwaysEat()) return;
        if (player.getFoodData().getFoodLevel() < 20) return; // 未满饥饿时仍走原版流程
        player.startUsingItem(event.getHand());
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        EnergyData.sync(event.getEntity(), 0);
        ShardData.sync(event.getEntity());
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        event.getEntity().getPersistentData().putInt("machinery_legend_energy", EnergyData.get(event.getOriginal()));
        ShardData.copy(event.getOriginal(), event.getEntity());
    }

    @SubscribeEvent
    public static void onPickupPre(ItemEntityPickupEvent.Pre event) {
        if (event.getPlayer().level().isClientSide) return;
        ItemEntity item = event.getItemEntity();
        ItemStack stack = item.getItem();
        if (stack.is(Items.REDSTONE)
                && item.getPersistentData().getBoolean("machinery_legend_furnace_redstone")) {
            int amount = Math.min(stack.getCount(), (EnergyData.MAX_ENERGY - EnergyData.get(event.getPlayer())) / 25);
            if (amount <= 0) return;
            EnergyData.add(event.getPlayer(), amount * 25);
            event.getPlayer().level().playSound(null, event.getPlayer().blockPosition(), GeneratedMod.FURNACE_REDSTONE_PICKUP.get(),
                    SoundSource.PLAYERS, 0.7f, 1.0f);
            stack.shrink(amount);
            if (stack.isEmpty()) item.discard();
            event.setCanPickup(net.neoforged.neoforge.common.util.TriState.FALSE);
        }
    }

    /**
     * 星之碎片不进物品栏：拾取时按剩余槽位填入碎片槽，多出来的部分留在原地。
     * 无论有没有塞进去，都要取消原版拾取，否则碎片会照常进背包。
     */
    @SubscribeEvent
    public static void onStarShardPickup(ItemEntityPickupEvent.Pre event) {
        if (event.getPlayer().level().isClientSide) return;
        ItemEntity item = event.getItemEntity();
        ItemStack stack = item.getItem();
        if (!stack.is(GeneratedMod.STAR_SHARD.get())) return;

        Player player = event.getPlayer();
        int stored = ShardData.store(player, stack.getCount());
        if (stored > 0) {
            stack.shrink(stored);
            // 单个经验球被拾取的音效。
            player.level().playSound(null, player.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP,
                    SoundSource.PLAYERS, 0.3f, 1.0f);
            if (stack.isEmpty()) item.discard();
        }
        event.setCanPickup(net.neoforged.neoforge.common.util.TriState.FALSE);
    }

    @SubscribeEvent
    public static void onPickup(ItemEntityPickupEvent.Post event) {
        if (event.getPlayer().level().isClientSide) return;
        ItemStack stack = event.getOriginalStack();
        if (MechanicalArmItem.isEquipped(event.getPlayer()) && stack.is(Items.REDSTONE)
                && !event.getItemEntity().getPersistentData().getBoolean("machinery_legend_furnace_redstone")) {
            int amount = stack.getCount();
            if (EnergyData.MAX_ENERGY - EnergyData.get(event.getPlayer()) >= amount * 25) {
                EnergyData.add(event.getPlayer(), amount * 25);
            }
        }
    }

    @SubscribeEvent
    public static void onEntityTickPre(EntityTickEvent.Pre event) {
        Entity entity = event.getEntity();
        if (entity.level().isClientSide || !(entity instanceof Zombie zombie)
                || !(entity.level() instanceof ServerLevel serverLevel)) return;
        if ((zombie.getType() == EntityType.ZOMBIE || zombie.getType() == EntityType.DROWNED)
                && !zombie.isOnFire() && !zombie.isInWaterRainOrBubble()
                && serverLevel.isDay() && zombie.getLightLevelDependentMagicValue() > 0.5f
                && serverLevel.canSeeSky(zombie.blockPosition())) {
            zombie.getPersistentData().putBoolean(SUNBURN_PROTECTION_KEY, true);
        }
    }

    @SubscribeEvent
    public static void onEntityTick(EntityTickEvent.Post event) {
        Entity entity = event.getEntity();
        if (entity.level().isClientSide) return;
        if (entity instanceof Zombie zombie && entity.level() instanceof ServerLevel serverLevel) {
            applyPendingHelmet(zombie);
            if (zombie.getPersistentData().getBoolean(InvasionMobLogic.PENDING_CARRIER_KEY)) {
                zombie.getPersistentData().remove(InvasionMobLogic.PENDING_CARRIER_KEY);
                InvasionMobLogic.initializeCarrier(zombie, serverLevel);
                return;
            }
            if (zombie.getPersistentData().getBoolean(SUNBURN_PROTECTION_KEY)) {
                zombie.getPersistentData().remove(SUNBURN_PROTECTION_KEY);
                zombie.clearFire();
            }
        }
        if (!(entity instanceof ItemEntity item)) return;
        // 怪物掉落的星之碎片：15 秒后无论有没人捡都消失。
        if (item.getPersistentData().getBoolean(StarShardCarrier.DROP_KEY)
                && item.getAge() >= StarShardCarrier.DROP_LIFETIME_TICKS) {
            item.discard();
            return;
        }
        if (!item.getPersistentData().getBoolean("machinery_legend_mine_tnt_drop")) return;
        if (!item.onGround()) return;
        if (!item.getItem().is(Items.TNT)) return;
        MineTntEntity mine = GeneratedMod.MINE_TNT.get().create((net.minecraft.server.level.ServerLevel) item.level());
        if (mine == null) return;
        var pos = item.blockPosition();
        if (!item.level().getBlockState(pos.below()).isSolid()) return;
        mine.moveTo(item.getX(), pos.getY(), item.getZ(), 0.0f, 0.0f);
        mine.setPersistenceRequired();
        mine.setEmerged(true);
        item.discard();
        item.level().addFreshEntity(mine);
    }

    private static void spawnWakeParticles(ServerLevel level, LivingEntity emitter) {
        DustParticleOptions gold = new DustParticleOptions(new Vector3f(1.0f, 0.72f, 0.08f), 1.35f);
        double centerY = emitter.getY() + emitter.getBbHeight() * 0.52;
        level.sendParticles(gold, emitter.getX(), centerY, emitter.getZ(),
                64, emitter.getBbWidth() * 0.85, emitter.getBbHeight() * 0.62, emitter.getBbWidth() * 0.85, 0.18);
    }

    /** 荧石粉唤醒器械后共用的表现：金色粒子、消耗一份荧石粉、播放唤醒音效。 */
    private static void consumeGlowstoneDust(ServerLevel level, LivingEntity target, Player player, ItemStack stack) {
        spawnWakeParticles(level, target);
        if (!player.isCreative()) stack.shrink(1);
        level.playSound(null, target.blockPosition(), GeneratedMod.SMALL_EMITTER_WAKEUP.get(),
                SoundSource.PLAYERS, 1.5f, 1.35f);
    }

    /** 客户端读同步过来的碎片数，服务端读玩家持久化数据，保证两侧交互判定一致。 */
    private static boolean hasShard(Player player) {
        return player.level().isClientSide()
                ? cn.blockforge.generated.machinerylegend.client.ClientShards.getCount() > 0
                : ShardData.getCount(player) > 0;
    }

    @SubscribeEvent
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        Entity target = event.getTarget();
        Player player = event.getEntity();
        if (event.getHand() == InteractionHand.MAIN_HAND && event.getItemStack().is(Items.GLOWSTONE_DUST)
                && (target instanceof SmallEmitterEntity || target instanceof MoonlightSensorEntity)) {
            if (target instanceof MoonlightSensorEntity sensor) {
                if (!target.level().isClientSide && sensor.isDaySleeping() && !sensor.isUpgraded()) {
                    sensor.wake();
                    consumeGlowstoneDust((ServerLevel) target.level(), sensor, player, event.getItemStack());
                }
                event.setCancellationResult(InteractionResult.SUCCESS);
                event.setCanceled(true);
                return;
            }
            SmallEmitterEntity emitter = (SmallEmitterEntity) target;
            if (!target.level().isClientSide && emitter.isDaySleeping()) {
                emitter.wake();
                consumeGlowstoneDust((ServerLevel) target.level(), emitter, player, event.getItemStack());
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
            return;
        }
        // 手持物品形式的星之碎片右键生物：先把它转进碎片槽，等同于对空气/方块右键的效果。
        if (event.getItemStack().is(GeneratedMod.STAR_SHARD.get())) {
            if (!target.level().isClientSide && StarShardItem.storeIntoSlot(player, event.getItemStack()) <= 0) {
                StarShardItem.notifyFull(player);
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
            return;
        }
        // 星之碎片：空手右键器械生物，消耗槽内 1 个碎片使其激发潜能（与下界之星效果相同，且无冷却）。
        if (event.getHand() == InteractionHand.MAIN_HAND && event.getItemStack().isEmpty()
                && target instanceof MachineryEntity machinery && hasShard(player)) {
            if (target instanceof SmallEmitterEntity emitter && emitter.isDaySleeping()) {
                event.setCancellationResult(InteractionResult.FAIL);
                event.setCanceled(true);
                return;
            }
            if (!target.level().isClientSide) {
                if (!player.isCreative()) ShardData.consume(player);
                if (target instanceof EmitterEntity emitter) emitter.triggerEmpowered();
                else machinery.triggerEmpowered();
                target.level().playSound(null, target.blockPosition(), GeneratedMod.EVOCATION.get(),
                        SoundSource.PLAYERS, 0.9f, 1.0f);
            }
            event.setCancellationResult(InteractionResult.SUCCESS);
            event.setCanceled(true);
            return;
        }
        if (event.getHand() != InteractionHand.MAIN_HAND || !event.getItemStack().is(Items.NETHER_STAR)) return;
        if (!(target instanceof MachineryEntity machinery)) return;
        if (target instanceof SmallEmitterEntity emitter && emitter.isDaySleeping()) {
            event.setCancellationResult(InteractionResult.FAIL);
            event.setCanceled(true);
            return;
        }

        if (!player.isCreative() && player.getCooldowns().isOnCooldown(Items.NETHER_STAR)) {
            event.setCancellationResult(InteractionResult.FAIL);
            event.setCanceled(true);
            return;
        }

        if (!target.level().isClientSide) {
            if (target instanceof EmitterEntity emitter) emitter.triggerEmpowered();
            else machinery.triggerEmpowered();
            target.level().playSound(null, target.blockPosition(), GeneratedMod.EVOCATION.get(),
                    SoundSource.PLAYERS, 0.9f, 1.0f);
            if (!player.isCreative()) player.getCooldowns().addCooldown(Items.NETHER_STAR, 600);
        }
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }
}
