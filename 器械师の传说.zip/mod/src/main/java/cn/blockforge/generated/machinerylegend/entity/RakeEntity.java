package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** 放置在完整方块顶面的钉耙；首次接触敌对生物后翻起并造成一次魔法伤害。 */
public final class RakeEntity extends Entity {
    private static final EntityDataAccessor<Boolean> DATA_ACTIVATED =
            SynchedEntityData.defineId(RakeEntity.class, EntityDataSerializers.BOOLEAN);
    private static final float DAMAGE = 60.0f;
    private static final String ACTIVATED_TAG = "Activated";

    public RakeEntity(EntityType<? extends RakeEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_ACTIVATED, false);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return EntityDimensions.fixed(1.5f, 1.0f);
    }

    @Override
    public boolean isPickable() {
        return true;
    }

    @Override
    public boolean canBeCollidedWith() {
        // 保留边界箱用于接触检测，但不参与实体物理碰撞，生物可以正常穿过。
        return false;
    }

    @Override
    public InteractionResult interactAt(Player player, Vec3 location, InteractionHand hand) {
        if (!player.getItemInHand(hand).isEmpty()) return InteractionResult.PASS;
        if (!level().isClientSide) discard();
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void tick() {
        baseTick();
        setDeltaMovement(0.0, 0.0, 0.0);
        if (level().isClientSide) return;
        if (isActivated()) {
            discard();
            return;
        }

        // 给查询范围留出极小容差，确保站在钉耙顶面上的生物也能被判定为接触。
        AABB contactBox = getBoundingBox().inflate(0.08);
        LivingEntity target = level().getEntitiesOfClass(LivingEntity.class, contactBox,
                        entity -> entity.isAlive() && RebellionLogic.canMachineAttack(this, entity))
                .stream()
                .min((first, second) -> Double.compare(distanceToSqr(first), distanceToSqr(second)))
                .orElse(null);
        if (target == null) return;

        entityData.set(DATA_ACTIVATED, true);
        MachineryEntity.clearInvulnerabilityForMachineryAttack(target);
        target.hurt(level().damageSources().magic(), DAMAGE);
    }

    public boolean isActivated() {
        return entityData.get(DATA_ACTIVATED);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putBoolean(ACTIVATED_TAG, isActivated());
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(DATA_ACTIVATED, tag.getBoolean(ACTIVATED_TAG));
    }
}
