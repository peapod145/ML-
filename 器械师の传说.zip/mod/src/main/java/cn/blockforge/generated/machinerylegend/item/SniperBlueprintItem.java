package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.EmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.SniperEmitterEntity;
import cn.blockforge.generated.machinerylegend.player.EnergyData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import java.util.List;

/** 将普通发射器升级为狙击发射器的蓝图。 */
public class SniperBlueprintItem extends Item {
    private static final int ENERGY_COST = 150;
    private static final int REDSTONE_COST = 6;
    private static final int COOLDOWN_TICKS = 150;

    public SniperBlueprintItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<net.minecraft.network.chat.Component> tooltip,
                                TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.sniper_emitter_blueprint")
                .withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.translatable("tooltip.machinery_legend.blueprint_cost", ENERGY_COST, REDSTONE_COST)
                .withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.literal("它没有被遗忘").withStyle(ChatFormatting.WHITE));
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        // 只升级普通发射器；飞刀发射器虽继承发射器逻辑，但它是独立器械，不参与升级。
        if (hand != InteractionHand.MAIN_HAND || !(target instanceof EmitterEntity)
                || target instanceof cn.blockforge.generated.machinerylegend.entity.KnifeEmitterEntity) {
            return InteractionResult.PASS;
        }
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResult.FAIL;

        if (!player.level().isClientSide) {
            if (!player.isCreative() && !EnergyData.consumeEnergyOrRedstone(player, REDSTONE_COST, ENERGY_COST)) {
                EnergyData.flashInsufficient(player, "message.machinery_legend.insufficient_energy");
                return InteractionResult.FAIL;
            }

            SniperEmitterEntity sniper = GeneratedMod.SNIPER_EMITTER.get().create(player.level());
            if (sniper == null) return InteractionResult.FAIL;
            sniper.moveTo(target.getX(), target.getY(), target.getZ(), target.getYRot(), target.getXRot());
            sniper.setPersistenceRequired();
            target.level().addFreshEntity(sniper);
            target.level().playSound(null, target.blockPosition(), SoundEvents.STONE_PLACE,
                    SoundSource.BLOCKS, 1.0f, 1.0f);
            target.level().broadcastEntityEvent(sniper, (byte) 60);
            target.discard();

            if (!player.isCreative()) {
                stack.shrink(1);
                player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            }
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
