package cn.blockforge.generated.machinerylegend.block;

/** 熔炉器械本体所处的隐形光照方块，向周围提供 10 级光照。 */
public class FurnaceLightBlock extends MachineryLightBlock {
    public FurnaceLightBlock(Properties properties) {
        super(properties);
    }
}
