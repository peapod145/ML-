package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 传染发射器：血量 20，碰撞箱、视野与攻击逻辑全部沿用小型发射器（含白天睡觉、
 * 荧石粉唤醒、下界之星激发潜能），每 1.5 秒射出寄生机器人，命中后附加 30 秒“机器寄染”。
 * 寄生机器人的命中伤害无视目标无敌帧，机制见 {@link ParasiteBotEntity}。
 *
 * <p>激发潜能时不再发射滚动雪球，而是清除自身半径 20 格内所有敌人身上的“机器寄染”，
 * 播放用户提供的采样作为预警，并在 1 秒后于每个被清除的敌人位置引发不破坏地形的
 * 单格爆炸，造成 35 点虚空伤害。</p>
 */
public class InfectenserEntity extends SmallEmitterEntity {
    /** 常规射击间隔：1.5 秒 = 30 刻（与携带“机器寄染”的怪物开火节奏保持一致）。 */
    private static final int FIRE_INTERVAL_TICKS = 30;
    /** 激发潜能时清除“机器寄染”的半径（格）。 */
    private static final double PARASITE_CLEAR_RADIUS = 20.0;
    /** 清除状态到单格爆炸之间的延迟，等于 1 秒。 */
    private static final int DETONATION_DELAY_TICKS = 20;
    /** 单格爆炸造成的虚空伤害。 */
    private static final float DETONATION_DAMAGE = 35.0f;
    /** 单格爆炸的影响范围：以敌人为中心的 1×1×1 方块。 */
    private static final double DETONATION_RADIUS = 0.5;

    /** 已清掉“机器寄染”、等待 1 秒后引爆的敌人。 */
    private final List<PendingDetonation> pendingDetonations = new ArrayList<>();

    public InfectenserEntity(EntityType<? extends InfectenserEntity> type, Level level) {
        super(type, level);
        // 射击间隔固定 1.5 秒（父类默认同为 30 刻，这里显式声明，避免后续改动父类默认值时漂移）。
        normalCooldown = FIRE_INTERVAL_TICKS;
    }

    @Override
    protected void fireProjectile(LivingEntity target) {
        Vec3 direction = horizontalForward();
        Vec3 start = muzzlePosition(direction);
        ParasiteBotEntity bot = new ParasiteBotEntity(GeneratedMod.PARASITE_BOT.get(), this, level());
        bot.setRebelOrigin(RebellionLogic.isRebel(this));
        bot.setPos(start);
        bot.shoot(direction.x, direction.y, direction.z, 0.72f, 0.0f);
        level().addFreshEntity(bot);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || pendingDetonations.isEmpty()) return;
        Iterator<PendingDetonation> iterator = pendingDetonations.iterator();
        while (iterator.hasNext()) {
            PendingDetonation detonation = iterator.next();
            detonation.follow(level());
            if (--detonation.ticksLeft > 0) continue;
            iterator.remove();
            detonate(detonation);
        }
    }

    /**
     * 激发潜能：清除自身半径 20 格内所有携带“机器寄染”的敌人身上的状态，
     * 播放用户提供的音效预警，并在 1 秒后于其位置引发不破坏地形的单格虚空爆炸。
     */
    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || isDaySleeping()) return;
        startEvocationEffect();
        if (!(level() instanceof ServerLevel serverLevel)) return;

        List<LivingEntity> marked = serverLevel.getEntitiesOfClass(LivingEntity.class,
                getBoundingBox().inflate(PARASITE_CLEAR_RADIUS),
                candidate -> candidate != this && candidate.isAlive()
                        && RebellionLogic.canMachineAttack(this, candidate)
                        && candidate.hasEffect(GeneratedMod.MACHINE_PARASITE)
                        && distanceToSqr(candidate) <= PARASITE_CLEAR_RADIUS * PARASITE_CLEAR_RADIUS);
        for (LivingEntity enemy : marked) {
            enemy.removeEffect(GeneratedMod.MACHINE_PARASITE);
            pendingDetonations.add(new PendingDetonation(enemy, DETONATION_DELAY_TICKS));
            // 爆炸前播放用户提供的采样，给敌人一个 1 秒的倒计时预警。
            serverLevel.playSound(null, enemy.getX(), enemy.getY() + enemy.getBbHeight() * 0.5, enemy.getZ(),
                    GeneratedMod.PARABOT_TICK.get(), SoundSource.HOSTILE, 2.0f, 0.55f);
        }
    }

    /** 单格爆炸：只有视听表现与 35 点虚空伤害，不破坏任何方块。 */
    private void detonate(PendingDetonation detonation) {
        if (!(level() instanceof ServerLevel serverLevel)) return;
        double x = detonation.x;
        double y = detonation.y;
        double z = detonation.z;
        serverLevel.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
        serverLevel.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y, z, 1, 0.0, 0.0, 0.0, 0.0);
        serverLevel.playSound(null, x, y, z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2.0f, 1.0f);

        AABB area = new AABB(x - DETONATION_RADIUS, y - DETONATION_RADIUS, z - DETONATION_RADIUS,
                x + DETONATION_RADIUS, y + DETONATION_RADIUS, z + DETONATION_RADIUS);
        for (LivingEntity victim : serverLevel.getEntitiesOfClass(LivingEntity.class, area,
                candidate -> candidate != this && candidate.isAlive())) {
            // 器械爆炸不受目标无敌帧影响，确保 35 点伤害必然结算。
            victim.invulnerableTime = 0;
            victim.hurt(serverLevel.damageSources().fellOutOfWorld(), DETONATION_DAMAGE);
        }
    }

    /** 待引爆目标：记录敌人自身，1 秒内跟随其移动，爆炸落在它当下的位置。 */
    private static final class PendingDetonation {
        private final int entityId;
        private double x;
        private double y;
        private double z;
        private int ticksLeft;

        private PendingDetonation(LivingEntity enemy, int ticksLeft) {
            this.entityId = enemy.getId();
            this.ticksLeft = ticksLeft;
            this.x = enemy.getX();
            this.y = enemy.getY() + enemy.getBbHeight() * 0.5;
            this.z = enemy.getZ();
        }

        private void follow(Level level) {
            Entity entity = level.getEntity(entityId);
            if (entity instanceof LivingEntity living && living.isAlive()) {
                this.x = living.getX();
                this.y = living.getY() + living.getBbHeight() * 0.5;
                this.z = living.getZ();
            }
        }
    }
}
