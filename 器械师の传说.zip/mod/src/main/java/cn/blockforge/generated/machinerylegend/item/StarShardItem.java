package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.player.ShardData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** 星之碎片：拾取后自动填入碎片槽，空手右键器械生物可消耗它激发潜能。 */
public final class StarShardItem extends Item {
    public StarShardItem(Properties properties) {
        super(properties);
    }

    /**
     * 把玩家手里这一叠碎片的数量尽量塞进碎片槽，返回实际存入的数量。
     * 只有服务端能调用：{@link ShardData#store} 会向客户端发包同步。
     */
    public static int storeIntoSlot(Player player, ItemStack stack) {
        if (player.level().isClientSide()) return 0;
        int stored = ShardData.store(player, stack.getCount());
        if (stored > 0 && !player.isCreative()) {
            stack.shrink(stored);
        }
        return stored;
    }

    /** 提示玩家“碎片槽已满”这条白字。 */
    public static void notifyFull(Player player) {
        player.displayClientMessage(Component.translatable("message.machinery_legend.shard_slot_full"), true);
    }

    /**
     * 手持物品形式的星之碎片右键：把碎片转进碎片槽。
     * 玩家即便通过其他途径在物品栏拿到了碎片，也能在这里手动存进槽位。
     */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            return InteractionResultHolder.success(stack);
        }
        if (storeIntoSlot(player, stack) <= 0) {
            notifyFull(player);
            return InteractionResultHolder.fail(stack);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.5f, 1.4f);
        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.star_shard_1").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.machinery_legend.star_shard_2").withStyle(ChatFormatting.GRAY));
    }
}
