package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.InfectenserEntity;
import cn.blockforge.generated.machinerylegend.entity.SmallEmitterEntity;
import cn.blockforge.generated.machinerylegend.player.EnergyData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** 将小型发射器改造成传染发射器的蓝图，使用后固定 30 秒冷却。 */
public class InfectenserBlueprintItem extends Item {
    /** 使用冷却 30 秒（600 tick）。 */
    private static final int COOLDOWN_TICKS = 20 * 30;
    /** 改造消耗：75 机械能或 3 红石。 */
    private static final int ENERGY_COST = 75;
    private static final int REDSTONE_COST = 3;

    public InfectenserBlueprintItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.infectenser_blueprint")
                .withStyle(ChatFormatting.YELLOW));
        tooltip.add(Component.translatable("tooltip.machinery_legend.blueprint_cost", ENERGY_COST, REDSTONE_COST)
                .withStyle(ChatFormatting.YELLOW));
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        // 只能改造小型发射器；传染发射器本身与其它器械都不接受改造。
        if (hand != InteractionHand.MAIN_HAND || !(target instanceof SmallEmitterEntity)
                || target instanceof InfectenserEntity) {
            return InteractionResult.PASS;
        }
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResult.FAIL;

        if (!player.level().isClientSide) {
            InfectenserEntity infectenser = GeneratedMod.INFECTENSER.get().create(player.level());
            if (infectenser == null) return InteractionResult.FAIL;
            // 改造消耗 75 机械能或 3 红石；创造模式不消耗。
            if (!player.isCreative()
                    && !EnergyData.consumeEnergyOrRedstone(player, REDSTONE_COST, ENERGY_COST)) {
                EnergyData.flashInsufficient(player, "message.machinery_legend.insufficient_energy");
                return InteractionResult.FAIL;
            }
            infectenser.moveTo(target.getX(), target.getY(), target.getZ(), target.getYRot(), target.getXRot());
            infectenser.setPersistenceRequired();
            // 原小型发射器若已被荧石粉永久唤醒，改造后保留清醒状态。
            if (((SmallEmitterEntity) target).isPermanentlyAwake()) infectenser.wake();
            target.level().addFreshEntity(infectenser);
            target.level().playSound(null, target.blockPosition(), SoundEvents.STONE_PLACE,
                    SoundSource.BLOCKS, 1.0f, 1.0f);
            target.discard();

            if (!player.isCreative()) {
                stack.shrink(1);
                player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
            }
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }
}
