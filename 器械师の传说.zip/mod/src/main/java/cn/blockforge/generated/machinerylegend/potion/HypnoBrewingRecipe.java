package cn.blockforge.generated.machinerylegend.potion;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.crafting.Ingredient;
import net.neoforged.neoforge.common.brewing.BrewingRecipe;
import net.neoforged.neoforge.common.brewing.IBrewingRecipe;
import net.neoforged.neoforge.common.crafting.DataComponentIngredient;

import java.util.List;
import java.util.Optional;

/**
 * 催眠药水的酿造台配方。
 *
 * <p>底部水瓶槽放粗制的药水（{@link Potions#AWKWARD}），顶部原材料槽放金苹果，酿出饮用型催眠药水，
 * 初始时长 30 秒；对任一催眠药水加红石可延长到 90 秒；加火药变成喷溅型，再加龙息变成滞留型，
 * 后两步都会保留当前时长。</p>
 *
 * <p>NeoForge 的 {@link IBrewingRecipe} 允许输出任意物品堆，因此这里可以继续输出本模组自己的
 * 药水物品（而不是原版 {@code minecraft:potion}），自定义贴图不受影响。</p>
 */
public final class HypnoBrewingRecipe implements IBrewingRecipe {
    /** 初始时长：30 秒 = 600 刻。 */
    private static final int BASE_DURATION = 20 * 30;
    /** 红石延长后的时长：90 秒 = 1800 刻。 */
    private static final int LONG_DURATION = 20 * 90;

    @Override
    public boolean isInput(ItemStack input) {
        return isAwkwardPotion(input)
                || input.is(GeneratedMod.HYPNO_POTION.get())
                || input.is(GeneratedMod.SPLASH_HYPNO_POTION.get())
                || input.is(GeneratedMod.LINGERING_HYPNO_POTION.get());
    }

    @Override
    public boolean isIngredient(ItemStack ingredient) {
        return ingredient.is(Items.GOLDEN_APPLE) || ingredient.is(Items.REDSTONE)
                || ingredient.is(Items.GUNPOWDER) || ingredient.is(Items.DRAGON_BREATH);
    }

    @Override
    public ItemStack getOutput(ItemStack input, ItemStack ingredient) {
        // 粗制的药水 + 金苹果 -> 饮用型催眠药水（30 秒）
        if (isAwkwardPotion(input) && ingredient.is(Items.GOLDEN_APPLE)) {
            return create(GeneratedMod.HYPNO_POTION.get(), BASE_DURATION);
        }
        if (input.is(GeneratedMod.HYPNO_POTION.get())) {
            // 红石延长到 90 秒
            if (ingredient.is(Items.REDSTONE)) {
                return create(GeneratedMod.HYPNO_POTION.get(), LONG_DURATION);
            }
            // 火药变成喷溅型，保留当前时长
            if (ingredient.is(Items.GUNPOWDER)) {
                return create(GeneratedMod.SPLASH_HYPNO_POTION.get(), durationOf(input));
            }
        }
        // 喷溅型 + 龙息 -> 滞留型，保留当前时长
        if (input.is(GeneratedMod.SPLASH_HYPNO_POTION.get()) && ingredient.is(Items.DRAGON_BREATH)) {
            return create(GeneratedMod.LINGERING_HYPNO_POTION.get(), durationOf(input));
        }
        return ItemStack.EMPTY;
    }

    private static boolean isAwkwardPotion(ItemStack stack) {
        if (!stack.is(Items.POTION)) return false;
        PotionContents contents = stack.getOrDefault(DataComponents.POTION_CONTENTS, PotionContents.EMPTY);
        return contents.is(Potions.AWKWARD);
    }

    /** 粗制的药水的样品堆，供 JEI 展示与组件精确匹配用。 */
    private static ItemStack awkwardPotionStack() {
        ItemStack stack = new ItemStack(Items.POTION);
        stack.set(DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD));
        return stack;
    }

    /** 读取现有催眠药水上的反逆时长；读不到时退回 30 秒。 */
    private static int durationOf(ItemStack stack) {
        PotionContents contents = stack.getOrDefault(DataComponents.POTION_CONTENTS, PotionContents.EMPTY);
        for (MobEffectInstance effect : contents.customEffects()) {
            if (effect.is(GeneratedMod.REBELLION)) return effect.getDuration();
        }
        return BASE_DURATION;
    }

    private static ItemStack create(Item item, int duration) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.POTION_CONTENTS, contents(duration));
        return stack;
    }

    private static PotionContents contents(int duration) {
        // visible=false：喝下/命中后不生成反逆效果的药水粒子（图标仍显示）。
        return new PotionContents(Optional.empty(), Optional.empty(),
                List.of(new MobEffectInstance(GeneratedMod.REBELLION, duration, 0, false, false, true)));
    }

    /**
     * 注册到酿造台：NeoForge 会在数据包/服务端启动时重新构建酿造表并触发本事件。
     *
     * <p>第一份是真正负责行为的动态配方（{@link IBrewingRecipe}），火药与龙息两步能保留药水
     * 当前时长，所以必须排在前面、优先命中。后面几份是给 JEI 看的等价配方：JEI 的酿造分类只给
     * {@link BrewingRecipe} 注册了展示扩展，自定义 {@code IBrewingRecipe} 会被它以
     * “Can't handle brewing recipe class” 直接跳过，导致它的酿造表里看不到这瓶药水。</p>
     */
    public static void register(net.neoforged.neoforge.event.brewing.RegisterBrewingRecipesEvent event) {
        var builder = event.getBuilder();
        builder.addRecipe(new HypnoBrewingRecipe());
        // 粗制的药水必须按组件精确匹配：普通 Ingredient 只比物品，会把任意药水都当成输入。
        builder.addRecipe(new BrewingRecipe(
                DataComponentIngredient.of(false, DataComponents.POTION_CONTENTS, new PotionContents(Potions.AWKWARD), Items.POTION),
                Ingredient.of(Items.GOLDEN_APPLE),
                create(GeneratedMod.HYPNO_POTION.get(), BASE_DURATION)));
        builder.addRecipe(new BrewingRecipe(
                Ingredient.of(create(GeneratedMod.HYPNO_POTION.get(), BASE_DURATION)),
                Ingredient.of(Items.REDSTONE),
                create(GeneratedMod.HYPNO_POTION.get(), LONG_DURATION)));
        builder.addRecipe(new BrewingRecipe(
                Ingredient.of(create(GeneratedMod.HYPNO_POTION.get(), BASE_DURATION)),
                Ingredient.of(Items.GUNPOWDER),
                create(GeneratedMod.SPLASH_HYPNO_POTION.get(), BASE_DURATION)));
        builder.addRecipe(new BrewingRecipe(
                Ingredient.of(create(GeneratedMod.SPLASH_HYPNO_POTION.get(), BASE_DURATION)),
                Ingredient.of(Items.DRAGON_BREATH),
                create(GeneratedMod.LINGERING_HYPNO_POTION.get(), BASE_DURATION)));
    }
}
