package cn.blockforge.generated.machinerylegend.item;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import java.util.function.Supplier;

/**
 * 石像鬼刷怪蛋：严格使用用户上传的 16×16 贴图（textures/item/gargoyle_spawn_egg.png）。
 * <p>原版刷怪蛋模型是双层模板并按 {@link #getColor(int)} 返回的两种颜色着色；
 * 本类改用自带贴图模型，并把着色固定为白色（0xFFFFFFFF），
 * 使贴图乘色后与原始文件逐像素一致、不做任何修改；生成行为仍是原版刷怪蛋逻辑。</p>
 */
public final class GargoyleSpawnEggItem extends DeferredSpawnEggItem {
    public GargoyleSpawnEggItem(Supplier<? extends EntityType<? extends Mob>> type, Properties props) {
        super(type, 0x8A8A8A, 0x565656, props);
    }

    /** 白色乘色 = 恒等变换，保证贴图原样显示。 */
    @Override
    public int getColor(int tint) {
        return 0xFFFFFFFF;
    }
}
