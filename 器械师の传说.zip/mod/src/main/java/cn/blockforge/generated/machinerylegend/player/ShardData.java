package cn.blockforge.generated.machinerylegend.player;

import cn.blockforge.generated.machinerylegend.network.ShardSyncPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * 碎片槽数据：每个玩家一份，存在玩家持久化数据里。
 * 槽位数量 1~5，每个槽位最多放 1 个星之碎片；碎片不进物品栏，
 * 拾取时由 {@code GameEvents} 调用 {@link #store} 填进这里。
 */
public final class ShardData {
    public static final int MIN_SLOTS = 1;
    public static final int MAX_SLOTS = 5;
    private static final String SLOTS_KEY = "machinery_legend_shard_slots";
    private static final String COUNT_KEY = "machinery_legend_shard_count";

    private ShardData() {}

    /** 当前碎片槽位数（1~5）。 */
    public static int getSlots(Player player) {
        return clampSlots(player.getPersistentData().getInt(SLOTS_KEY));
    }

    /** 当前存有的碎片数量，永远不会超过槽位数。 */
    public static int getCount(Player player) {
        int count = player.getPersistentData().getInt(COUNT_KEY);
        return Math.max(0, Math.min(count, getSlots(player)));
    }

    public static void setSlots(Player player, int slots) {
        player.getPersistentData().putInt(SLOTS_KEY, clampSlots(slots));
        // 扩容只会变大，但读档时仍按当前槽位夹一次，避免脏数据。
        player.getPersistentData().putInt(COUNT_KEY, getCount(player));
        sync(player);
    }

    /** 扩容一格；已满 5 格返回 false。 */
    public static boolean upgrade(Player player) {
        int slots = getSlots(player);
        if (slots >= MAX_SLOTS) return false;
        setSlots(player, slots + 1);
        return true;
    }

    /** 尽量把 {@code available} 个碎片塞进碎片槽，返回实际收下的数量。 */
    public static int store(Player player, int available) {
        int room = getSlots(player) - getCount(player);
        int stored = Math.max(0, Math.min(available, room));
        if (stored <= 0) return 0;
        player.getPersistentData().putInt(COUNT_KEY, getCount(player) + stored);
        sync(player);
        return stored;
    }

    /** 消耗一个碎片；槽内为空返回 false。 */
    public static boolean consume(Player player) {
        int count = getCount(player);
        if (count <= 0) return false;
        player.getPersistentData().putInt(COUNT_KEY, count - 1);
        sync(player);
        return true;
    }

    /** 玩家重生/换维度时把碎片槽数据带过去。 */
    public static void copy(Player from, Player to) {
        to.getPersistentData().putInt(SLOTS_KEY, getSlots(from));
        to.getPersistentData().putInt(COUNT_KEY, getCount(from));
        sync(to);
    }

    public static void sync(Player player) {
        if (player instanceof ServerPlayer serverPlayer) {
            PacketDistributor.sendToPlayer(serverPlayer, new ShardSyncPayload(getCount(player), getSlots(player)));
        }
    }

    /** 周期性同步，兜底覆盖登录之外的切换维度/重生等场景。 */
    public static void tick(Player player) {
        if (player instanceof ServerPlayer serverPlayer && player.tickCount % 20 == 0) {
            sync(serverPlayer);
        }
    }

    private static int clampSlots(int slots) {
        if (slots < MIN_SLOTS) return MIN_SLOTS;
        if (slots > MAX_SLOTS) return MAX_SLOTS;
        return slots;
    }
}
