package cn.blockforge.generated.machinerylegend.block;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

import cn.blockforge.generated.machinerylegend.entity.FurnaceEntity;
import cn.blockforge.generated.machinerylegend.entity.GlowstoneEntity;
import cn.blockforge.generated.machinerylegend.entity.SoulforgeEntity;
import cn.blockforge.generated.machinerylegend.entity.SoulforgeFireballEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.level.ChunkEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * 隐形光照方块（器械本体灯 + 炽炎弹拖尾灯）的<b>残留清理器</b>。
 *
 * <p>器械与炽炎弹平时都会即时撤灯，但"退出游戏"这一刻实体先于区块被卸载，撤灯动作
 * 会因"区块已不在加载表"而被护栏跳过，于是灯和区块一起存进了存档。旧版本代码放下的灯
 * 甚至从没注册过任何复查计划刻。这个类就是这些无主残留的最后一道兜底。</p>
 *
 * <h2>为什么不用"补注册计划刻"</h2>
 * 上一版尝试在区块载入时给残留灯补注册一个延迟方块计划刻，由方块自己到点后清理。
 * 这条路有两个不可靠点：计划刻只对<b>正在 ticking 的区块</b>才会被 {@code LevelTicks}
 * 收集执行（渲染距离内、模拟距离外的区块不跑计划刻），而且载入事件发生在工作线程、
 * 延迟到下一 tick 时用 {@code hasChunkAt} 复核会把还没并入世界的区块整批丢掉且不再重试。
 * 只要命中一次，残留灯就永远留在存档里。
 *
 * <p>所以本类不再"托付计划刻"，而是在服务端主线程上<b>直接判定并当场移除</b>：
 * 已知主人还在就不动，主人不在就 {@code removeBlock}。判定和移除都发生在区块确实已并入
 * 世界之后，不依赖任何后续调度。</p>
 *
 * <h2>三条通道</h2>
 * <ol>
 *   <li><b>区块载入队列</b>：{@code ChunkEvent.Load}（可能在加载线程）只把区块坐标入队，
 *       服务端 tick 时若该区块已可用就整块扫描清理；暂时不可用则下一 tick 重试，
 *       超过重试上限才丢弃，避免像上一版那样"一次丢件、永不复查"。</li>
 *   <li><b>玩家周围定时兜底</b>：每隔 {@value #SWEEP_INTERVAL_TICKS} 刻，对每名玩家
 *       {@value #SWEEP_RADIUS_CHUNKS} 个区块半径内的<b>已加载</b>区块扫一遍。这条通道不依赖
 *       任何载入事件，玩家一进世界，视野里的旧残留最多一秒多就会消失。</li>
 *   <li><b>关停前清场</b>：{@code ServerStoppingEvent} 在 {@code saveAllChunks} 之前触发，
 *       此时所有区块仍在加载表里。把所有飞行炽炎弹拖着的灯就地撤掉，
 *       从源头保证写进存档的区块里没有会立刻失效的弹体灯。</li>
 * </ol>
 *
 * <p>所有者判定：器械本体灯要求"同一格站着对应器械实体"，炽炎弹灯要求"同一格有仍在飞的
 * 炽炎弹"。器械实体随区块一起存盘，区块载入时先于本扫描恢复，所以正常器械的灯不会被误删；
 * 即使偶发误删，器械下一 tick 也会立刻把灯补回来。</p>
 */
public final class SoulforgeLightResidualSweep {
    /** 载入队列里一个区块最多跨多少 tick 重试；区块迟迟不并入世界才放弃。 */
    private static final int MAX_RETRIES = 200;
    /** 玩家周围兜底扫描的间隔（刻）。 */
    private static final int SWEEP_INTERVAL_TICKS = 20;
    /** 玩家周围兜底扫描的区块半径：6 区块 = 96 格。 */
    private static final int SWEEP_RADIUS_CHUNKS = 6;
    /** 每刻最多移除多少格残留：旧存档可能积了很多，分摊到多刻避免一次性光照重算卡顿。 */
    private static final int MAX_REMOVALS_PER_TICK = 256;

    /** 待清理的已载入区块：只存坐标 + 重试次数，真正扫描推迟到主线程。 */
    private record Pending(ServerLevel level, long packedChunkPos, int retries) {}

    /** 跨线程通道：区块加载线程入队，主线程在服务 tick 里消费。 */
    private static final Queue<Pending> PENDING = new ConcurrentLinkedQueue<>();

    /** 兜底扫描节拍。 */
    private static int tickCounter;
    /** 本刻剩余的可移除格数。 */
    private static int removalBudget;

    private SoulforgeLightResidualSweep() {}

    @SubscribeEvent
    public static void onChunkLoad(ChunkEvent.Load event) {
        // 加载线程上只做零风险的事：取区块坐标入队。读段、读调色板、碰世界接口都留到主线程。
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        PENDING.offer(new Pending(level, event.getChunk().getPos().toLong(), 0));
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        removalBudget = MAX_REMOVALS_PER_TICK;
        drainPending();
        if (++tickCounter % SWEEP_INTERVAL_TICKS != 0) return;
        for (ServerLevel level : event.getServer().getAllLevels()) {
            for (ServerPlayer player : level.players()) {
                sweepAroundPlayer(level, player);
            }
        }
    }

    /** 消费载入队列：区块已可用就整块清理，否则重试；超限才丢弃。 */
    private static void drainPending() {
        // 只处理"本次进入时已在队列里"的条目。未就绪而重新入队的条目要等下一 tick，
        // 否则 while(poll) 会把刚 offer 回去的条目立刻再取出来，在同一 tick 里空转 MAX_RETRIES 轮。
        int batch = PENDING.size();
        for (int i = 0; i < batch; ++i) {
            Pending pending = PENDING.poll();
            if (pending == null) return;
            LevelChunk chunk = loadedChunk(pending.level(), pending.packedChunkPos());
            if (chunk != null) {
                cleanChunk(pending.level(), chunk);
            } else if (pending.retries() < MAX_RETRIES) {
                PENDING.offer(new Pending(pending.level(), pending.packedChunkPos(), pending.retries() + 1));
            }
        }
    }

    /** 玩家周围已加载区块的兜底普查。用 {@code getChunkNow}，绝不触发新区块加载。 */
    private static void sweepAroundPlayer(ServerLevel level, ServerPlayer player) {
        BlockPos origin = player.blockPosition();
        int centerX = origin.getX() >> 4;
        int centerZ = origin.getZ() >> 4;
        for (int dx = -SWEEP_RADIUS_CHUNKS; dx <= SWEEP_RADIUS_CHUNKS; ++dx) {
            for (int dz = -SWEEP_RADIUS_CHUNKS; dz <= SWEEP_RADIUS_CHUNKS; ++dz) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(centerX + dx, centerZ + dz);
                if (chunk != null) cleanChunk(level, chunk);
            }
        }
    }

    /**
     * 关停前清场：撤掉所有飞行炽炎弹拖着的灯，让随后写盘的区块里不留弹体灯。
     * <p>整个清场包在 try/catch 里：这一步发生在 {@code stopServer()} 写盘之前，
     * 万一有任何意外异常都不允许它冒出去打断收尾流程（那正是"存档不显示"的老病根），
     * 清理失败顶多留一盏残留灯，交由下次进世界的载入普查补掉。</p>
     */
    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        PENDING.clear();
        tickCounter = 0;
        try {
            for (ServerLevel level : event.getServer().getAllLevels()) {
                for (Entity entity : level.getAllEntities()) {
                    if (entity instanceof SoulforgeFireballEntity fireball) {
                        fireball.clearTrailingLight();
                    }
                }
            }
        } catch (RuntimeException ignored) {
            // 关停清场是"尽力而为"的优化，失败不应影响存档正常落盘。
        }
    }

    private static LevelChunk loadedChunk(ServerLevel level, long packedChunkPos) {
        int x = ChunkPos.getX(packedChunkPos);
        int z = ChunkPos.getZ(packedChunkPos);
        return level.getChunkSource().getChunkNow(x, z);
    }

    /** 扫描一个已加载区块里的隐形光源格，移除所有无主残留。 */
    private static void cleanChunk(ServerLevel level, LevelChunk chunk) {
        LevelChunkSection[] sections = chunk.getSections();
        ChunkPos chunkPos = chunk.getPos();
        int baseX = chunkPos.getMinBlockX();
        int baseZ = chunkPos.getMinBlockZ();
        for (int i = 0; i < sections.length; ++i) {
            LevelChunkSection section = sections[i];
            if (section == null) continue;
            // 调色板级预筛：该段没有任何本类光照方块时跳过整段 4096 格。
            if (!section.maybeHas(SoulforgeLightResidualSweep::isManagedLight)) continue;
            int baseY = chunk.getSectionYFromSectionIndex(i) << 4;
            for (int y = 0; y < 16; ++y) {
                for (int z = 0; z < 16; ++z) {
                    for (int x = 0; x < 16; ++x) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (!isManagedLight(state)) continue;
                        BlockPos pos = new BlockPos(baseX + x, baseY + y, baseZ + z);
                        if (!hasLivingOwner(level, pos, state)) {
                            if (removalBudget <= 0) return;
                            --removalBudget;
                            level.removeBlock(pos, false);
                        }
                    }
                }
            }
        }
    }

    /** 是任何一种"实体拖着的隐形光源方块"。 */
    private static boolean isManagedLight(BlockState state) {
        Block block = state.getBlock();
        return block instanceof SoulforgeLightBlock
                || block instanceof GlowstoneLightBlock
                || block instanceof FurnaceLightBlock;
    }

    /** 这一格是否仍由存活的主人维持；未知类型一律当作"有主"而保留。 */
    private static boolean hasLivingOwner(ServerLevel level, BlockPos pos, BlockState state) {
        Block block = state.getBlock();
        AABB box = new AABB(pos);
        if (block instanceof SoulforgeFireballLightBlock) {
            return !level.getEntitiesOfClass(SoulforgeFireballEntity.class, box).isEmpty();
        }
        if (block instanceof SoulforgeLightBlock) {
            return hasMachineAt(level, pos, box, SoulforgeEntity.class);
        }
        if (block instanceof GlowstoneLightBlock) {
            return hasMachineAt(level, pos, box, GlowstoneEntity.class);
        }
        if (block instanceof FurnaceLightBlock) {
            return hasMachineAt(level, pos, box, FurnaceEntity.class);
        }
        return true;
    }

    /** 同一格里是否站着对应的器械实体（器械灯永远放在器械自身的方块坐标上）。 */
    private static <T extends Entity> boolean hasMachineAt(ServerLevel level, BlockPos pos, AABB box, Class<T> type) {
        return !level.getEntitiesOfClass(type, box,
                entity -> !entity.isRemoved() && entity.blockPosition().equals(pos)).isEmpty();
    }
}
