package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.entity.DrownedRenderer;
import net.minecraft.client.renderer.entity.HuskRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

@EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class ClientEvents {
    private static final ResourceLocation HUD_LAYER = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "machinery_energy");
    // 碎片槽 HUD：与左下角机械能 UI 左右对称，挂在屏幕右下角。
    private static final ResourceLocation SHARD_HUD_LAYER = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "shard_slots");
    private static final ResourceLocation GEAR = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/item/energy_gear.png");
    private static final ResourceLocation STAR_SHARD_ICON = ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/item/star_shard.png");
    private static int cachedEnergy = Integer.MIN_VALUE;
    private static String cachedEnergyText = "0";
    private static int cachedShardCount = Integer.MIN_VALUE;
    private static int cachedShardSlots = Integer.MIN_VALUE;
    private static String cachedShardText = "0/1";

    private ClientEvents() {}

    @SubscribeEvent
    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(GeneratedMod.CONVERTER_MENU.get(), ConverterScreen::new);
        event.register(GeneratedMod.MINE_FIELD_MENU.get(), MineFieldScreen::new);
    }

    @SubscribeEvent
    public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(GhostRenderer.MODEL_LAYER, GhostModel::createBodyLayer);
        event.registerLayerDefinition(GargoyleRenderer.MODEL_LAYER, GargoyleModel::createBodyLayer);
        // 狼人狼形态：网格直接复用原版 WolfModel（愤怒姿态在 WerewolfWolfModel 内锁定）
        event.registerLayerDefinition(WerewolfRenderer.WOLF_LAYER, WerewolfWolfModel::createBodyLayer);
        // 狼人人形态：按上传 bbmodel 复刻的玩家骨架 + 狼吻部/鼻/耳
        event.registerLayerDefinition(WerewolfRenderer.HUMANOID_LAYER, WerewolfHumanoidModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(GeneratedMod.EMITTER.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SNIPER_EMITTER.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.KNIFE_EMITTER.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.FURNACE.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.OBSIDIAN.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.PUNCH_PISTON.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.MINE_TNT.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SMALL_EMITTER.get(), MachineryRenderer::new);
        // 传染发射器沿用器械渲染器（外观与小型发射器一致，含睡眠标识）
        event.registerEntityRenderer(GeneratedMod.INFECTENSER.get(), MachineryRenderer::new);
        // 炽炎熔炉沿用器械渲染器（南瓜灯本体、睡眠 Zzz 与激发星芒都在 MachineryRenderer 内分派）
        event.registerEntityRenderer(GeneratedMod.SOULFORGE.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SOULFORGE_FIREBALL.get(), SoulforgeFireballRenderer::new);
        event.registerEntityRenderer(GeneratedMod.PARASITE_BOT.get(), ParasiteBotRenderer::new);
        event.registerEntityRenderer(GeneratedMod.MOONLIGHT_SENSOR.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.SMALL_EMITTER_SNOWBALL.get(), SmallEmitterSnowballRenderer::new);
        event.registerEntityRenderer(GeneratedMod.ROLLING_SNOWBALL.get(), RollingSnowballRenderer::new);
        event.registerEntityRenderer(GeneratedMod.THROWING_KNIFE_PROJECTILE.get(), ThrowingKnifeRenderer::new);
        event.registerEntityRenderer(GeneratedMod.INVASION_ZOMBIE.get(), ZombieRenderer::new);
        event.registerEntityRenderer(GeneratedMod.INVASION_HUSK.get(), HuskRenderer::new);
        event.registerEntityRenderer(GeneratedMod.INVASION_DROWNED.get(), DrownedRenderer::new);
        event.registerEntityRenderer(GeneratedMod.CHEATING_VILLAGER.get(), CheatingVillagerRenderer::new);
        event.registerEntityRenderer(GeneratedMod.GHOST.get(), GhostRenderer::new);
        event.registerEntityRenderer(GeneratedMod.GARGOYLE.get(), GargoyleRenderer::new);
        event.registerEntityRenderer(GeneratedMod.GLOWSTONE.get(), MachineryRenderer::new);
        event.registerEntityRenderer(GeneratedMod.POWERED_CART_ENTITY.get(), PoweredCartRenderer::new);
        event.registerEntityRenderer(GeneratedMod.RAKE.get(), RakeRenderer::new);
        // 狼人：曾因漏注册渲染器导致 EntityRenderDispatcher#shouldRender 空指针崩溃，务必保持注册
        event.registerEntityRenderer(GeneratedMod.WEREWOLF.get(), WerewolfRenderer::new);
    }

    /**
     * 给所有活体渲染器挂上星之碎片绿光层：携带碎片的怪物会整体罩一层自发光绿色。
     * 渲染器按实体类型逐一创建，这里遍历一遍全部加上；非携带者不绘制，开销可忽略。
     */
    @SubscribeEvent
    public static void addStarShardGlowLayer(EntityRenderersEvent.AddLayers event) {
        for (EntityType<?> type : event.getEntityTypes()) {
            // 单个渲染器出问题不影响整轮挂载。
            try {
                StarShardGlowLayer.decorate(event.getRenderer(type));
            } catch (RuntimeException ignored) {
                // 忽略：绿光挂不上最多不好看，不该影响游戏。
            }
        }
    }

    @SubscribeEvent
    public static void registerGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAboveAll(HUD_LAYER, ClientEvents::renderEnergyHud);
        event.registerAboveAll(SHARD_HUD_LAYER, ClientEvents::renderShardHud);
    }

    /** 幽灵腿部的白色火星粒子（复用原版烟花火箭 spark_0~7 贴图）：注册渲染端工厂（见 particles/ghost_spark.json）。 */
    @SubscribeEvent
    public static void registerParticles(net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(GeneratedMod.GHOST_SPARK.get(),
                sprites -> (type, level, x, y, z, xd, yd, zd) -> GhostSparkParticle.create(sprites, level, x, y, z, xd, yd, zd));
    }

    private static void renderEnergyHud(GuiGraphics graphics, net.minecraft.client.DeltaTracker delta) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.options.hideGui) return;
        int x = 8;
        int y = graphics.guiHeight() - 30;
        graphics.blit(GEAR, x, y, 0, 0, 20, 20, 20, 20);
        int energy = ClientEnergy.get();
        if (energy != cachedEnergy) {
            cachedEnergy = energy;
            cachedEnergyText = Integer.toString(energy);
        }
        int color = ClientEnergy.isFlashing() ? 0xFFFF3030 : 0xFFC0C0C0;
        graphics.drawString(minecraft.font, cachedEnergyText, x + 24, y + 6, color, true);
    }

    /**
     * 右下角碎片槽：图标用星之碎片贴图，左边显示“已有/槽位”。
     * 坐标系与左下角机械能 UI 关于屏幕中线对称（机械能图标 x=8，这里 x=width-28）。
     * 数字按“已有/槽位”比例分三档着色：
     * 大于 1/2 为绿（数量充足，含满槽——满槽提示不变，仍是绿）；
     * 大于 1/3 且小于等于 1/2 为土黄（开始偏少，提醒注意）；
     * 小于等于 1/3 为红（快用光了）。
     */
    private static void renderShardHud(GuiGraphics graphics, net.minecraft.client.DeltaTracker delta) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.options.hideGui) return;
        int iconX = graphics.guiWidth() - 28;
        int y = graphics.guiHeight() - 30;
        graphics.blit(STAR_SHARD_ICON, iconX, y, 0, 0, 20, 20, 20, 20);
        int count = ClientShards.getCount();
        int slots = ClientShards.getSlots();
        if (count != cachedShardCount || slots != cachedShardSlots) {
            cachedShardCount = count;
            cachedShardSlots = slots;
            cachedShardText = count + "/" + slots;
        }
        int textX = iconX - 6 - minecraft.font.width(cachedShardText);
        // 按比例分三档（整数比较免浮点误差）：≤1/2 且 >1/3 土黄，≤1/3 红，其余绿。
        // 阈值按槽位数折算，1~5 格槽位语义一致；未同步数据（slots≤0）时保持绿。
        int color;
        if (slots > 0 && count * 3 <= slots) {
            color = 0xFFFF5555;                 // ≤1/3：红
        } else if (slots > 0 && count * 2 <= slots) {
            color = 0xFFCC9900;                 // >1/3 且 ≤1/2：土黄
        } else {
            color = 0xFF55FF55;                 // >1/2（含满槽）：绿
        }
        graphics.drawString(minecraft.font, cachedShardText, textX, y + 6, color, true);
    }
}
