package cn.blockforge.generated.machinerylegend.item;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;

import java.lang.reflect.Method;
import java.util.Optional;

/** 通过反射读取 Curios，未安装 Curios 时不会影响模组加载。 */
public final class CuriosCompat {
    private static final String CURIOS_API = "top.theillusivec4.curios.api.CuriosApi";

    private CuriosCompat() {}

    public static boolean isEquipped(Player player) {
        return isEquipped(player, cn.blockforge.generated.machinerylegend.GeneratedMod.MECHANICAL_ARM.get());
    }

    public static boolean isEquipped(Player player, Item item) {
        return !findEquipped(player, item).isEmpty();
    }

    public static ItemStack findEquipped(Player player, Item item) {
        if (!ModList.get().isLoaded("curios")) return ItemStack.EMPTY;
        try {
            Class<?> api = Class.forName(CURIOS_API);
            Method getInventory = api.getMethod("getCuriosInventory", net.minecraft.world.entity.LivingEntity.class);
            Object result = getInventory.invoke(null, player);
            if (!(result instanceof Optional<?> optional) || optional.isEmpty()) return ItemStack.EMPTY;
            Object handler = optional.get();
            Method findFirstCurio = handler.getClass().getMethod("findFirstCurio", Item.class);
            Object curioResult = findFirstCurio.invoke(handler, item);
            if (!(curioResult instanceof Optional<?> curio) || curio.isEmpty()) return ItemStack.EMPTY;
            Object slotResult = curio.get();
            if (slotResult instanceof ItemStack stack) return stack;
            Method stackMethod = slotResult.getClass().getMethod("stack");
            Object stack = stackMethod.invoke(slotResult);
            return stack instanceof ItemStack itemStack ? itemStack : ItemStack.EMPTY;
        } catch (ReflectiveOperationException | LinkageError ignored) {
            return ItemStack.EMPTY;
        }
    }
}
