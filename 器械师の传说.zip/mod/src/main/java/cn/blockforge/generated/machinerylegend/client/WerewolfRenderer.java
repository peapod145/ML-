package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.WerewolfEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * 狼人渲染器：双模型按狼形态标记热切换（LivingEntityRenderer#model 非 final）。
 * <ul>
 *   <li>人形态：WerewolfHumanoidModel —— 按用户上传的 models/werewolf_humanoid.bbmodel
 *       复刻的玩家骨架 + 狼吻部/鼻/双耳模型，贴图为该 bbmodel 内嵌贴图重排成
 *       Java 十字 UV 后的 werewolf_humanoid.png（tools/make_werewolf_humanoid_tex.py）；
 *       动画继承 HumanoidModel，与玩家一致（行走摆臂、攻击抬手）；</li>
 *   <li>狼形态：WerewolfWolfModel（逐部件复刻原版狼模型，锁定愤怒姿态）+ 原版狼贴图，
 *       外貌与原版愤怒的狼一致。</li>
 * </ul>
 * 狼形态贴图取 1.21.1 的 {@code minecraft:textures/entity/wolf/wolf_angry.png}
 * （pale 狼变体的 angry_texture，即经典"愤怒的狼"）。
 */
public final class WerewolfRenderer extends MobRenderer<WerewolfEntity, EntityModel<WerewolfEntity>> {
    public static final ModelLayerLocation WOLF_LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "werewolf_wolf"), "main");
    public static final ModelLayerLocation HUMANOID_LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "werewolf_humanoid"), "main");
    private static final ResourceLocation WOLF_TEXTURE =
            ResourceLocation.withDefaultNamespace("textures/entity/wolf/wolf_angry.png");
    /** 人形态贴图：用户上传 bbmodel 内嵌贴图重排为 Java 十字 UV 布局（64×64）。 */
    private static final ResourceLocation HUMANOID_TEXTURE =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/werewolf_humanoid.png");

    private final WerewolfHumanoidModel humanoidModel;
    private final WerewolfWolfModel wolfModel;

    public WerewolfRenderer(EntityRendererProvider.Context context) {
        this(context, new WerewolfHumanoidModel(context.bakeLayer(HUMANOID_LAYER)),
                new WerewolfWolfModel(context.bakeLayer(WOLF_LAYER)));
    }

    private WerewolfRenderer(EntityRendererProvider.Context context,
                             WerewolfHumanoidModel humanoidModel, WerewolfWolfModel wolfModel) {
        super(context, humanoidModel, 0.5F);
        this.humanoidModel = humanoidModel;
        this.wolfModel = wolfModel;
    }

    @Override
    public void render(WerewolfEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource bufferSource, int packedLight) {
        this.model = entity.isWolfForm() ? this.wolfModel : this.humanoidModel;
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(WerewolfEntity entity) {
        // 人形态用玩家皮肤布局的狼外貌贴图；狼形态用原版愤怒狼贴图（两者 UV 布局不同，不能共用）
        return entity.isWolfForm() ? WOLF_TEXTURE : HUMANOID_TEXTURE;
    }
}
