package cn.blockforge.generated.machinerylegend.mixin;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 反逆期间的索敌覆盖：
 * <ul>
 *   <li>反逆者只攻击同阵营的非反逆目标，反逆者之间互不攻击；</li>
 *   <li>普通怪物把反逆者视为普通人：被反逆的怪物和玩家都能被正常锁定、反击与追猎。</li>
 * </ul>
 *
 * <p>这里只做“反逆者自己”的减项。普通（未反逆）生物的索敌完全交回原版
 * {@link TargetingConditions#test}，这样创造/旁观玩家的免疫、和平难度、视线与距离等
 * 原版判定一条都不会被绕过；被反逆的目标对它们来说只是普通目标而已。</p>
 */
@Mixin(TargetingConditions.class)
public abstract class TargetingConditionsMixin {
    @Shadow private boolean isCombat;

    @Inject(method = "test(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/LivingEntity;)Z",
            at = @At("HEAD"), cancellable = true)
    private void machineryLegend$rebellionTargeting(LivingEntity attacker, LivingEntity target,
                                                    CallbackInfoReturnable<Boolean> cir) {
        if (!this.isCombat || attacker == null || target == null || attacker == target) return;
        // 普通（未反逆）生物不在这里插手：反逆效果不改变它们看目标的眼光，
        // 剩下的判定全部交回原版，避免绕过创造/旁观免疫等原版保护。
        if (!RebellionLogic.isRebel(attacker)) return;
        // 反逆者同属一条阵线：受到反逆的怪物之间互不攻击。
        if (RebellionLogic.isRebel(target)) {
            cir.setReturnValue(false);
            return;
        }
        // 创造/旁观玩家永远不该被索敌（反逆者想打玩家时同样如此）。
        if (RebellionLogic.isUntargetablePlayer(target)) {
            cir.setReturnValue(false);
            return;
        }
        // 反逆者只打同阵营的非反逆目标；不同阵营的交回原版判定（原版也会把它们判为非法）。
        if (!RebellionLogic.sameFaction(attacker, target)) {
            cir.setReturnValue(false);
        }
    }
}
