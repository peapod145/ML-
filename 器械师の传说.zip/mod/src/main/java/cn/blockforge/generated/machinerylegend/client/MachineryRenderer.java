package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import cn.blockforge.generated.machinerylegend.entity.EmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.FurnaceEntity;
import cn.blockforge.generated.machinerylegend.entity.InfectenserEntity;
import cn.blockforge.generated.machinerylegend.entity.MachineryEntity;
import cn.blockforge.generated.machinerylegend.entity.ObsidianEntity;
import cn.blockforge.generated.machinerylegend.entity.MineTntEntity;
import cn.blockforge.generated.machinerylegend.entity.SmallEmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.SoulforgeEntity;
import cn.blockforge.generated.machinerylegend.entity.SniperEmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.KnifeEmitterEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import cn.blockforge.generated.machinerylegend.entity.MoonlightSensorEntity;
import cn.blockforge.generated.machinerylegend.entity.GlowstoneEntity;
import cn.blockforge.generated.machinerylegend.entity.PunchPistonEntity;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MachineryRenderer extends EntityRenderer<MachineryEntity> {
    private static final ResourceLocation BLOCK_ATLAS = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/atlas/blocks.png");
    private static final ResourceLocation SNIPER_TOP_BOTTOM = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/sniper_emitter_top_bottom.png");
    private static final ResourceLocation SNIPER_SIDES = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/sniper_emitter_sides.png");
    private static final ResourceLocation SNIPER_FRONT = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/sniper_emitter_front.png");
    private static final ResourceLocation SNIPER_BACK = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/sniper_emitter_back.png");
    private static final ResourceLocation SNIPER_FENCE = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/sniper_emitter_fence.png");
    private static final ResourceLocation KNIFE_FRONT = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/knife_emitter_front.png");
    private static final ResourceLocation KNIFE_BACK = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/knife_emitter_back.png");
    private static final ResourceLocation KNIFE_SIDES = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/knife_emitter_sides.png");
    private static final ResourceLocation KNIFE_TOP = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/knife_emitter_top.png");
    private static final ResourceLocation KNIFE_BOTTOM = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/knife_emitter_bottom.png");
    private static final ResourceLocation KNIFE_FENCE = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/knife_emitter_fence.png");
    /** 传染发射器：整体是一只发射器，六面分别是用户提供的正面/后面/左侧/右侧/顶面/底面贴图。 */
    private static final ResourceLocation INFECTENSER_FRONT = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/infectenser_front.png");
    private static final ResourceLocation INFECTENSER_BACK = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/infectenser_back.png");
    private static final ResourceLocation INFECTENSER_LEFT = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/infectenser_left.png");
    private static final ResourceLocation INFECTENSER_RIGHT = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/infectenser_right.png");
    private static final ResourceLocation INFECTENSER_TOP = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/infectenser_top.png");
    private static final ResourceLocation INFECTENSER_BOTTOM = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/infectenser_bottom.png");
    /** 飞刀圈用飞行中的飞刀条带贴图（16×16 的第 0–4 行），刀尖在 u=1 一侧。 */
    private static final ResourceLocation KNIFE_STRIP = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/projectile/throwing_knife.png");
    private static final RenderType KNIFE_STRIP_RENDER_TYPE = RenderType.entityCutoutNoCull(KNIFE_STRIP);
    /** 本体损毁叠加图：>90 且 <180 用第一张破坏贴图，<=90 用第二张，六个面同时叠加。 */
    private static final ResourceLocation DAMAGE_MEDIUM = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/obsidian_damage_1.png");
    private static final ResourceLocation DAMAGE_HEAVY = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/obsidian_damage_2.png");
    /** 合金甲四侧观察窗贴图：按剩余护甲值分完好 / 受损 / 残破三档，观察窗镂空处能看到内层黑曜石。 */
    private static final RenderType ARMOR_SIDE_INTACT = RenderType.entityCutoutNoCull(ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/obsidian_armor_1.png"));
    private static final RenderType ARMOR_SIDE_DAMAGED = RenderType.entityCutoutNoCull(ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/obsidian_armor_2.png"));
    private static final RenderType ARMOR_SIDE_BROKEN = RenderType.entityCutoutNoCull(ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/obsidian_armor_3.png"));
    /** 合金甲的顶面与底面仍是合金块。 */
    private static final RenderType ARMOR_CAP = RenderType.entityCutoutNoCull(ResourceLocation.withDefaultNamespace("textures/block/netherite_block.png"));
    private static final ResourceLocation EVOCATION_STAR = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/evocation_star.png");
    private static final ResourceLocation SLEEPING_ZZZ = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/zzz.png");
    private static final ResourceLocation TARGET_MARKER = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/target.png");
     private static final ResourceLocation MOONLIGHT_SENSOR_TOP = ResourceLocation.fromNamespaceAndPath("machinery_legend", "textures/entity/moonlight_sensor_top.png");
    private static final BlockState OAK_FENCE = Blocks.OAK_FENCE.defaultBlockState();
    private static final BlockState DISPENSER = Blocks.DISPENSER.defaultBlockState();
    private static final BlockState LIT_FURNACE = Blocks.FURNACE.defaultBlockState()
            .setValue(BlockStateProperties.LIT, true);
    private static final BlockState GLOWSTONE = Blocks.GLOWSTONE.defaultBlockState();
    /** 炽炎熔炉：清醒时是发光的南瓜灯，白天睡觉时换成不发光的雕刻南瓜。 */
    private static final BlockState JACK_O_LANTERN = Blocks.JACK_O_LANTERN.defaultBlockState();
    private static final BlockState CARVED_PUMPKIN = Blocks.CARVED_PUMPKIN.defaultBlockState();
    private static final BlockState TNT = Blocks.TNT.defaultBlockState();
    private static final BlockState STONE_PRESSURE_PLATE = Blocks.STONE_PRESSURE_PLATE.defaultBlockState();
     private static final BlockState DAYLIGHT_DETECTOR_INVERTED = Blocks.DAYLIGHT_DETECTOR.defaultBlockState()
             .setValue(net.minecraft.world.level.block.DaylightDetectorBlock.INVERTED, true);
    /** 冲击活塞直接用方块图集里的原版活塞贴图，按面逐块手画立方体，以便让“活塞头”与底座分开呈现。 */
    private static final RenderType PISTON_ATLAS_RENDER_TYPE = RenderType.entityCutoutNoCull(BLOCK_ATLAS);
    private static final BlockState DIRT = Blocks.DIRT.defaultBlockState();
    private static final BlockState OBSIDIAN = Blocks.OBSIDIAN.defaultBlockState();
     private static final RenderType MOONLIGHT_SENSOR_TOP_RENDER_TYPE = RenderType.entityCutoutNoCull(MOONLIGHT_SENSOR_TOP);
    private static final RenderType EVOCATION_STAR_RENDER_TYPE = emissiveRenderType("machinery_legend_evocation_star", EVOCATION_STAR);
    private static final RenderType SLEEPING_ZZZ_RENDER_TYPE = emissiveRenderType("machinery_legend_sleeping_zzz", SLEEPING_ZZZ);
    private static final RenderType TARGET_MARKER_RENDER_TYPE = emissiveRenderType("machinery_legend_target_marker", TARGET_MARKER);
    /**
     * 反逆品红发光：器械生物的渲染器是 {@link EntityRenderer}，不是 {@code LivingEntityRenderer}，
     * 挂不上普通怪物用的 StarShardGlowLayer（那是一个 RenderLayer），所以这里把器械自身的几何
     * 再画一遍当发光层。
     *
     * <p>用原版 {@code RenderType.eyes}：着色器只做「贴图 × 顶点色」，加法混合、只写颜色不写深度，
     * 不依赖光照方向，所以叠加出来的颜色与环境亮度无关。遮罩是那张全白的 16×16
     * {@code star_shard_glow.png}，任何 UV 都取到纯白，于是几何形状被原样保留、颜色完全由顶点色决定。
     * 顶点色统一强制成跟活体发光层同一档柔和品红。</p>
     */
    private static final ResourceLocation REBELLION_GLOW_MASK = ResourceLocation.fromNamespaceAndPath(
            "machinery_legend", "textures/entity/star_shard_glow.png");
    private static final RenderType REBELLION_GLOW_RENDER_TYPE = RenderType.eyes(REBELLION_GLOW_MASK);
    /** 品红发光顶点色（ARGB）：与 StarShardGlowLayer 的反逆档一致，加法混合下即叠加的品红强度。 */
    private static final int REBELLION_GLOW_COLOR = 0x80800080;
    private final EntityRendererProvider.Context context;

    /** 自发光半透明渲染层：不写深度、不剔面，用于悬浮的贴图特效。 */
    private static RenderType emissiveRenderType(String name, ResourceLocation texture) {
        return RenderType.create(
                name,
                DefaultVertexFormat.NEW_ENTITY,
                VertexFormat.Mode.QUADS,
                256,
                true,
                true,
                RenderType.CompositeState.builder()
                        .setShaderState(RenderStateShard.RENDERTYPE_ENTITY_TRANSLUCENT_EMISSIVE_SHADER)
                        .setTextureState(new RenderStateShard.TextureStateShard(texture, false, false))
                        .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                        .setDepthTestState(RenderStateShard.NO_DEPTH_TEST)
                        .setCullState(RenderStateShard.NO_CULL)
                        .setLightmapState(RenderStateShard.NO_LIGHTMAP)
                        .setOverlayState(RenderStateShard.NO_OVERLAY)
                        .setWriteMaskState(RenderStateShard.COLOR_WRITE)
                        .createCompositeState(false));
    }

    public MachineryRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.context = context;
        this.shadowRadius = 0.2f;
    }

    @Override
    public void render(MachineryEntity entity, float yaw, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light) {
        boolean rebellionGlow = RebellionLogic.isRebelVisual(entity) && !entity.isInvisible();

        poseStack.pushPose();
        applyBodyTransform(entity, poseStack);
        if (rebellionGlow) {
            // 本体要立刻画掉，发光层才叠得上去（原因见 flushBodyBatches 的说明）。
            TypeRecordingBufferSource recorder = new TypeRecordingBufferSource(buffer);
            renderBody(entity, partialTick, poseStack, recorder, light);
            flushBodyBatches(buffer, recorder.usedTypes());
        } else {
            renderBody(entity, partialTick, poseStack, buffer, light);
        }
        poseStack.popPose();

        // 反逆品红发光层：器械挂不上普通怪物的发光 RenderLayer，所以同一套几何再画一遍。
        // 发光类型不写深度、加法混合，画在本体之后正好叠成一层品红辉光，不会遮住模型本身。
        if (rebellionGlow) {
            poseStack.pushPose();
            applyBodyTransform(entity, poseStack);
            renderBody(entity, partialTick, poseStack, rebellionGlowBuffer(buffer), light);
            poseStack.popPose();
        }

        super.render(entity, yaw, partialTick, poseStack, buffer, light);
        // 最后绘制且不参与深度测试，确保特效不会被器械、方块或阴影遮住。
        renderEvocationStar(entity, partialTick, poseStack, buffer);
        if (entity instanceof MoonlightSensorEntity sensor && sensor.isEmpowered()) {
            renderBlueLightPool(sensor, partialTick, poseStack, buffer);
        }
        if (entity instanceof SmallEmitterEntity emitter && emitter.shouldRenderSleepingIndicator()) {
            renderSleepingZzz(entity, poseStack, buffer);
        }
        if (entity instanceof MoonlightSensorEntity sensor && sensor.shouldRenderSleepingIndicator()) {
            renderSleepingZzz(entity, poseStack, buffer);
        }
        if (entity instanceof SniperEmitterEntity sniper && sniper.getLockTicks() > 0) {
            renderTargetMarker(sniper, partialTick, poseStack, buffer);
        }
        if (entity instanceof KnifeEmitterEntity knife && !knife.getRingState().isEmpty()) {
            renderKnifeRings(knife, poseStack, buffer);
        }
    }

    /** 器械本体统一的摆位：先居中到脚底格中央，再按实体朝向绕 Y 旋转。 */
    private static void applyBodyTransform(MachineryEntity entity, PoseStack poseStack) {
        poseStack.translate(-0.5, 0.0, -0.5);
        poseStack.translate(0.5, 0.5, 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f - entity.getYRot()));
        poseStack.translate(-0.5, -0.5, -0.5);
    }

    /**
     * 按器械类型画本体几何。本体渲染与反逆发光渲染共用这一个入口：
     * 差别只在传进来的 {@link MultiBufferSource}，发光那遍会把所有顶点色改成品红。
     */
    private void renderBody(MachineryEntity entity, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light) {
        if (entity instanceof ObsidianEntity obsidian) {
            renderObsidian(obsidian, poseStack, buffer, light);
        } else if (entity instanceof PunchPistonEntity piston) {
            renderPunchPiston(piston, partialTick, poseStack, buffer, light);
        } else if (entity instanceof MineTntEntity mine) {
            renderMineTnt(mine, partialTick, poseStack, buffer, light);
        } else if (entity instanceof MoonlightSensorEntity moonlightSensor) {
            renderMoonlightSensor(moonlightSensor, partialTick, poseStack, buffer, light);
        } else if (entity instanceof SoulforgeEntity soulforge) {
            renderSoulforge(soulforge, poseStack, buffer, light);
        } else {
            poseStack.scale(0.72f, 0.72f, 0.72f);
            if (entity instanceof KnifeEmitterEntity) {
                renderKnifeEmitter(poseStack, buffer, light);
            } else if (entity instanceof SniperEmitterEntity sniper) {
                renderSniper(sniper, poseStack, buffer, light);
            } else if (entity instanceof EmitterEntity) {
                context.getBlockRenderDispatcher().renderSingleBlock(OAK_FENCE, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
                poseStack.translate(0.0, 1.0, 0.0);
                context.getBlockRenderDispatcher().renderSingleBlock(DISPENSER, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
            } else if (entity instanceof InfectenserEntity) {
                renderInfectenser(poseStack, buffer, light);
            } else if (entity instanceof cn.blockforge.generated.machinerylegend.entity.SmallEmitterEntity) {
                context.getBlockRenderDispatcher().renderSingleBlock(DISPENSER, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
            } else if (entity instanceof FurnaceEntity) {
                context.getBlockRenderDispatcher().renderSingleBlock(LIT_FURNACE, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
            } else if (entity instanceof GlowstoneEntity) {
                context.getBlockRenderDispatcher().renderSingleBlock(GLOWSTONE, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
            }
        }
    }

    /**
     * 把本体渲染用到的所有 {@code getBuffer} 请求都重定向到同一条品红发光缓冲：
     * 不关心原来要哪种渲染类型（方块图集、自定义实体贴图、活塞贴图……），
     * 几何与 UV 原样写入，颜色交给 {@link RebellionGlowVertexConsumer} 强制改写。
     */
    private static MultiBufferSource rebellionGlowBuffer(MultiBufferSource delegate) {
        return type -> new RebellionGlowVertexConsumer(delegate.getBuffer(REBELLION_GLOW_RENDER_TYPE));
    }

    /**
     * 把器械本体刚刚提交的那几个批次立刻上传到显卡。
     *
     * <p><strong>这一步就是“器械不发光”的根因。</strong>器械本体是用方块几何画的，
     * 走 {@code RenderType.solid / cutout / cutoutMipped / translucent}（以及 {@code Sheets} 里的那几种），
     * 它们全都是 {@code RenderBuffers} 注册过的“固定缓冲”，要到实体批处理结束之后
     * （{@code LevelRenderer} 里 {@code endBatch(RenderType.solid())} 那一串）才会上传；
     * 而发光层用的 {@code RenderType.eyes} 不在固定缓冲名单里，走共享缓冲，会在实体循环末尾的
     * {@code endLastBatch()} 就先画出去。两者一前一后，发光层反而比本体早画，
     * 紧接着画上的不透明本体把整层品红盖得一点不剩——客户端明明拿到了反逆标记，也照常
     * 跑完了发光那遍几何，画面上却什么都看不到。</p>
     *
     * <p>这里在本体提交完后按“本体用过哪些渲染类型”把它们就地刷出去，本体先落地，
     * 稍后再画出去的发光层自然叠在它上面。普通怪物没有这个毛病：它们的本体与发光层
     * 都在共享缓冲里，靠先来后到的顺序本来就正确。</p>
     */
    private static void flushBodyBatches(MultiBufferSource buffer, List<RenderType> usedTypes) {
        if (!(buffer instanceof MultiBufferSource.BufferSource source)) return;
        for (RenderType type : usedTypes) {
            source.endBatch(type);
        }
    }

    /** 记录本体渲染请求过哪些渲染类型，其余行为原样交给被包装的缓冲。 */
    private static final class TypeRecordingBufferSource implements MultiBufferSource {
        private final MultiBufferSource delegate;
        private final Set<RenderType> usedTypes = new LinkedHashSet<>();

        private TypeRecordingBufferSource(MultiBufferSource delegate) {
            this.delegate = delegate;
        }

        @Override
        public VertexConsumer getBuffer(RenderType type) {
            this.usedTypes.add(type);
            return this.delegate.getBuffer(type);
        }

        private List<RenderType> usedTypes() {
            return new ArrayList<>(this.usedTypes);
        }
    }

    /**
     * 品红发光顶点消费者：转发几何、UV、法线与覆盖层，但把顶点色统一写成
     * {@link #REBELLION_GLOW_COLOR}、光照拉满，于是本体几何被原样复刻成一层发光。
     *
     * <p>方块模型走的是 {@code VertexConsumer.putBulkData}，它内部依次调用
     * {@code addVertex}/{@code setColor(int)}/{@code setUv}/{@code setOverlay}/{@code setLight}/{@code setNormal}，
     * 这些默认方法最终都会落到这里重写的抽象方法上，所以方块几何同样能被染成品红。</p>
     */
    private static final class RebellionGlowVertexConsumer implements VertexConsumer {
        private final VertexConsumer delegate;

        private RebellionGlowVertexConsumer(VertexConsumer delegate) {
            this.delegate = delegate;
        }

        @Override
        public VertexConsumer addVertex(float x, float y, float z) {
            delegate.addVertex(x, y, z);
            return this;
        }

        @Override
        public VertexConsumer setColor(int red, int green, int blue, int alpha) {
            delegate.setColor(REBELLION_GLOW_COLOR);
            return this;
        }

        @Override
        public VertexConsumer setUv(float u, float v) {
            delegate.setUv(u, v);
            return this;
        }

        @Override
        public VertexConsumer setUv1(int u, int v) {
            delegate.setUv1(u, v);
            return this;
        }

        @Override
        public VertexConsumer setUv2(int u, int v) {
            // 光照锁定满亮：发光与环境明暗无关。
            delegate.setUv2(0xF0, 0xF0);
            return this;
        }

        @Override
        public VertexConsumer setNormal(float x, float y, float z) {
            delegate.setNormal(x, y, z);
            return this;
        }
    }

    /**
     * 炽炎熔炉：0.9 格南瓜灯立方体（与黑曜石器械同大小同缩法），
     * 白天睡觉时换成雕刻南瓜（不发光、无火焰粒子，粒子在实体侧控制）。
     */
    private void renderSoulforge(SoulforgeEntity entity, PoseStack poseStack, MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        poseStack.scale(0.9f, 0.9f, 0.9f);
        // 白天睡觉（同步标识为真）时是雕刻南瓜，否则是点亮的南瓜灯。
        BlockState pumpkin = entity.shouldRenderSleepingIndicator() ? CARVED_PUMPKIN : JACK_O_LANTERN;
        context.getBlockRenderDispatcher().renderSingleBlock(pumpkin, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
    }

    private void renderMoonlightSensor(MoonlightSensorEntity entity, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        // 原版阳光传感器为 1 格，这里缩放到 0.8 格并保持底面贴地。
        poseStack.translate(0.1f, 0.0f, 0.1f);
        poseStack.scale(0.8f, 0.8f, 0.8f);
        context.getBlockRenderDispatcher().renderSingleBlock(DAYLIGHT_DETECTOR_INVERTED, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
        if (!entity.isUpgraded()) {
            renderMoonlightSensorTop(poseStack, buffer, light);
        }
        float progress = smoothstep(entity.getUpgradeAnimationProgress(partialTick));
        // 升级前四块翻盖保持闭合；升级动画期间逐渐翻开，完成后保持打开。
        renderCornerSensor(poseStack, buffer, light, 0.10f, 0.10f, progress, true);
        renderCornerSensor(poseStack, buffer, light, 0.65f, 0.10f, progress, true);
        renderCornerSensor(poseStack, buffer, light, 0.10f, 0.65f, progress, false);
        renderCornerSensor(poseStack, buffer, light, 0.65f, 0.65f, progress, false);
        poseStack.popPose();
    }

    private void renderMoonlightSensorTop(PoseStack poseStack, MultiBufferSource buffer, int light) {
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        VertexConsumer consumer = buffer.getBuffer(MOONLIGHT_SENSOR_TOP_RENDER_TYPE);
        // 参考图覆盖升级前主体顶面；升级后仍作为中央感应面保留。
        texturedQuad(consumer, matrix, pose, light,
                0.0f, 0.376f, 0.0f, 1.0f, 0.376f, 0.0f,
                1.0f, 0.376f, 1.0f, 0.0f, 0.376f, 1.0f,
                0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f);
    }

    private void renderCornerSensor(PoseStack poseStack, MultiBufferSource buffer, int light,
                                    float x, float z, float progress, boolean north) {
        poseStack.pushPose();
        float width = 0.25f;
        // 北侧盖板绕南侧铰链向北翻起，南侧盖板绕北侧铰链向南翻起。
        float hinge = north ? z + width : z;
        poseStack.translate(x, 0.19f, hinge);
        poseStack.mulPose(com.mojang.math.Axis.XP.rotationDegrees((north ? 72.0f : -72.0f) * progress));
        poseStack.translate(0.0f, 0.0f, north ? -width : 0.0f);
        poseStack.scale(width, width, width);
        context.getBlockRenderDispatcher().renderSingleBlock(STONE_PRESSURE_PLATE, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
    }

    private void renderSniper(SniperEmitterEntity entity, PoseStack poseStack, MultiBufferSource buffer, int light) {
        RenderType topBottom = RenderType.entityCutoutNoCull(SNIPER_TOP_BOTTOM);
        RenderType sides = RenderType.entityCutoutNoCull(SNIPER_SIDES);
        RenderType front = RenderType.entityCutoutNoCull(SNIPER_FRONT);
        RenderType back = RenderType.entityCutoutNoCull(SNIPER_BACK);
        RenderType fence = RenderType.entityCutoutNoCull(SNIPER_FENCE);

        // 普通发射器由无连接栅栏柱和上方完整发射器方块组成；狙击版只替换五组面贴图。
        renderTexturedCube(poseStack, buffer, light,
                6.0f / 16.0f, 0.0f, 6.0f / 16.0f,
                10.0f / 16.0f, 1.0f, 10.0f / 16.0f,
                fence, fence, fence, fence, fence, fence);
        renderTexturedCube(poseStack, buffer, light,
                0.0f, 1.0f, 0.0f,
                1.0f, 2.0f, 1.0f,
                front, back, sides, sides, topBottom, topBottom);
    }

    /**
     * 传染发射器：整体只有一只发射器方块，六面替换为用户提供的贴图。
     * 模型 -Z 面朝向实体视野方向（正面），+X 面为实体右侧、-X 面为实体左侧。
     */
    private void renderInfectenser(PoseStack poseStack, MultiBufferSource buffer, int light) {
        renderTexturedCube(poseStack, buffer, light,
                0.0f, 0.0f, 0.0f,
                1.0f, 1.0f, 1.0f,
                RenderType.entityCutoutNoCull(INFECTENSER_FRONT),
                RenderType.entityCutoutNoCull(INFECTENSER_BACK),
                RenderType.entityCutoutNoCull(INFECTENSER_RIGHT),
                RenderType.entityCutoutNoCull(INFECTENSER_LEFT),
                RenderType.entityCutoutNoCull(INFECTENSER_TOP),
                RenderType.entityCutoutNoCull(INFECTENSER_BOTTOM));
    }

    /** 飞刀发射器：与狙击发射器同样的"栅栏柱 + 发射器方块"几何，六面换成用户提供的贴图。 */
    private void renderKnifeEmitter(PoseStack poseStack, MultiBufferSource buffer, int light) {
        RenderType fence = RenderType.entityCutoutNoCull(KNIFE_FENCE);
        renderTexturedCube(poseStack, buffer, light,
                6.0f / 16.0f, 0.0f, 6.0f / 16.0f,
                10.0f / 16.0f, 1.0f, 10.0f / 16.0f,
                fence, fence, fence, fence, fence, fence);
        renderTexturedCube(poseStack, buffer, light,
                0.0f, 1.0f, 0.0f,
                1.0f, 2.0f, 1.0f,
                RenderType.entityCutoutNoCull(KNIFE_FRONT),
                RenderType.entityCutoutNoCull(KNIFE_BACK),
                RenderType.entityCutoutNoCull(KNIFE_SIDES),
                RenderType.entityCutoutNoCull(KNIFE_SIDES),
                RenderType.entityCutoutNoCull(KNIFE_TOP),
                RenderType.entityCutoutNoCull(KNIFE_BOTTOM));
    }

    /**
     * 潜能激发后凝聚的悬浮飞刀圈：按服务端同步的 "targetId,radius,count;…" 在目标碰撞箱中心
     * 周围画出等距的飞刀，刀尖指向圆心；3 秒后服务端从同样的位置把飞刀射入。
     */
    private void renderKnifeRings(KnifeEmitterEntity knife, PoseStack poseStack, MultiBufferSource buffer) {
        net.minecraft.client.Camera camera = entityRenderDispatcher.camera;
        org.joml.Vector3f lookVector = camera.getLookVector();
        Vec3 look = new Vec3(lookVector.x(), lookVector.y(), lookVector.z());
        Vec3 right = look.cross(new Vec3(0.0, 1.0, 0.0)).normalize();
        Vec3 up = right.cross(look).normalize();
        VertexConsumer consumer = buffer.getBuffer(KNIFE_STRIP_RENDER_TYPE);
        for (String entry : knife.getRingState().split(";")) {
            String[] parts = entry.split(",");
            if (parts.length != 3) continue;
            int targetId;
            double radius;
            int knives;
            try {
                targetId = Integer.parseInt(parts[0]);
                radius = Double.parseDouble(parts[1]);
                knives = Integer.parseInt(parts[2]);
            } catch (NumberFormatException ignored) {
                continue;
            }
            if (!(knife.level().getEntity(targetId) instanceof LivingEntity target) || !target.isAlive()) continue;
            double centerX = target.getX() - knife.getX();
            double centerY = target.getY() - knife.getY() + target.getBbHeight() * 0.5;
            double centerZ = target.getZ() - knife.getZ();
            for (int i = 0; i < knives; i++) {
                double angle = i * 2.0 * Math.PI / knives;
                double px = centerX + radius * Math.cos(angle);
                double pz = centerZ + radius * Math.sin(angle);
                // 世界空间里由圈上位置指向圆心，投影到屏幕后决定刀身在画面内的旋转角。
                Vec3 toCenter = new Vec3(-radius * Math.cos(angle), 0.0, -radius * Math.sin(angle));
                float screenAngle = (float) Math.atan2(toCenter.dot(up), toCenter.dot(right));
                poseStack.pushPose();
                poseStack.translate(px, centerY, pz);
                poseStack.mulPose(entityRenderDispatcher.cameraOrientation());
                poseStack.mulPose(Axis.ZP.rotation(screenAngle));
                PoseStack.Pose pose = poseStack.last();
                // 条带区（贴图第 0–4 行）：u 沿刀身、v 取 0..5/16，u=1（刀尖）朝向圆心。
                quad(consumer, pose.pose(), pose, LightTexture.FULL_BRIGHT,
                        -0.225f, -0.08f, 0.0f, 0.225f, -0.08f, 0.0f,
                        0.225f, 0.08f, 0.0f, -0.225f, 0.08f, 0.0f,
                        0.0f, 0.0f, 1.0f, 5.0f / 16.0f, 0.0f, 0.0f, 1.0f);
                poseStack.popPose();
            }
        }
    }

    private static void renderTexturedCube(PoseStack poseStack, MultiBufferSource buffer, int light,
                                           float minX, float minY, float minZ, float maxX, float maxY, float maxZ,
                                           RenderType north, RenderType south, RenderType east, RenderType west,
                                           RenderType up, RenderType down) {
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        texturedQuad(buffer.getBuffer(north), matrix, pose, light,
                minX, minY, minZ, maxX, minY, minZ, maxX, maxY, minZ, minX, maxY, minZ, 0, 0, 1, 1, 0, 0, -1);
        texturedQuad(buffer.getBuffer(south), matrix, pose, light,
                maxX, minY, maxZ, minX, minY, maxZ, minX, maxY, maxZ, maxX, maxY, maxZ, 0, 0, 1, 1, 0, 0, 1);
        texturedQuad(buffer.getBuffer(east), matrix, pose, light,
                maxX, minY, minZ, maxX, minY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, 0, 0, 1, 1, 1, 0, 0);
        texturedQuad(buffer.getBuffer(west), matrix, pose, light,
                minX, minY, maxZ, minX, minY, minZ, minX, maxY, minZ, minX, maxY, maxZ, 0, 0, 1, 1, -1, 0, 0);
        texturedQuad(buffer.getBuffer(up), matrix, pose, light,
                minX, maxY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, minX, maxY, maxZ, 0, 0, 1, 1, 0, 1, 0);
        texturedQuad(buffer.getBuffer(down), matrix, pose, light,
                minX, minY, maxZ, maxX, minY, maxZ, maxX, minY, minZ, minX, minY, minZ, 0, 0, 1, 1, 0, -1, 0);
    }

    private static void texturedQuad(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose, int light,
                                     float x1, float y1, float z1, float x2, float y2, float z2,
                                     float x3, float y3, float z3, float x4, float y4, float z4,
                                     float u1, float v1, float u2, float v2, float nx, float ny, float nz) {
        vertex(consumer, matrix, pose, light, x1, y1, z1, u1, v1, nx, ny, nz);
        vertex(consumer, matrix, pose, light, x2, y2, z2, u2, v1, nx, ny, nz);
        vertex(consumer, matrix, pose, light, x3, y3, z3, u2, v2, nx, ny, nz);
        vertex(consumer, matrix, pose, light, x4, y4, z4, u1, v2, nx, ny, nz);
    }

    /** 面向镜头的光晕四边形顶点；目标标记、休眠 Zzz 与激活星形三处特效共用。 */
    private static void billboardVertex(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose,
                                        float x, float y, float z, float u, float v, int alpha) {
        consumer.addVertex(matrix, x, y, z)
                .setColor(255, 255, 255, alpha)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0.0f, 0.0f, 1.0f);
    }


    private void renderTargetMarker(SniperEmitterEntity sniper, float partialTick, PoseStack poseStack, MultiBufferSource buffer) {
        net.minecraft.world.entity.LivingEntity target = sniper.getLockTarget();
        if (target == null || !target.isAlive()) return;

        float targetX = (float) (target.getX() - sniper.getX());
        float targetY = (float) (target.getY() - sniper.getY() + target.getBbHeight() * 0.5);
        float targetZ = (float) (target.getZ() - sniper.getZ());
        poseStack.pushPose();
        poseStack.translate(targetX, targetY, targetZ);
        poseStack.mulPose(entityRenderDispatcher.cameraOrientation());
        poseStack.scale(0.72f, 0.72f, 0.72f);

        VertexConsumer consumer = buffer.getBuffer(TARGET_MARKER_RENDER_TYPE);
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        billboardVertex(consumer, matrix, pose, -0.5f, 0.5f, 0.0f, 0.0f, 0.0f, 255);
        billboardVertex(consumer, matrix, pose, 0.5f, 0.5f, 0.0f, 1.0f, 0.0f, 255);
        billboardVertex(consumer, matrix, pose, 0.5f, -0.5f, 0.0f, 1.0f, 1.0f, 255);
        billboardVertex(consumer, matrix, pose, -0.5f, -0.5f, 0.0f, 0.0f, 1.0f, 255);
        poseStack.popPose();
    }

    private void renderSleepingZzz(MachineryEntity entity, PoseStack poseStack, MultiBufferSource buffer) {
        poseStack.pushPose();
        poseStack.translate(0.0, 0.92, 0.0);
        poseStack.mulPose(entityRenderDispatcher.cameraOrientation());
        poseStack.scale(0.72f, 0.72f, 0.72f);

        VertexConsumer consumer = buffer.getBuffer(SLEEPING_ZZZ_RENDER_TYPE);
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        // 贴图保留了参考图的原始像素比例，方形画布也按正方形绘制，避免横向变形。
        float halfWidth = 0.38f;
        float height = 0.76f;
        billboardVertex(consumer, matrix, pose, -halfWidth, height, 0.0f, 0.0f, 0.0f, 255);
        billboardVertex(consumer, matrix, pose, halfWidth, height, 0.0f, 1.0f, 0.0f, 255);
        billboardVertex(consumer, matrix, pose, halfWidth, 0.0f, 0.0f, 1.0f, 1.0f, 255);
        billboardVertex(consumer, matrix, pose, -halfWidth, 0.0f, 0.0f, 0.0f, 1.0f, 255);
        poseStack.popPose();
    }

    private void renderMineTnt(MineTntEntity entity, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        float progress = entity.getEmergeProgress(partialTick);
        float eased = progress * progress * (3.0f - 2.0f * progress);
        if (progress <= 0.0f) {
            renderBuriedDirt(poseStack, buffer, light, 1.0f);
        } else {
            // TNT rises out of the soil instead of snapping from the buried shell to its final pose.
            renderBuriedDirt(poseStack, buffer, light, 1.0f - eased);

            poseStack.pushPose();
            poseStack.translate(0.04, -0.52f + 0.24f * eased, 0.04);
            poseStack.scale(0.92f, 0.45f + 0.27f * eased, 0.92f);
            context.getBlockRenderDispatcher().renderSingleBlock(TNT, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
            poseStack.popPose();

            // The pressure plate follows the TNT and settles onto its top near the end of the animation.
            float plateProgress = Math.max(0.0f, Math.min(1.0f, (progress - 0.45f) / 0.55f));
            float plateEased = plateProgress * plateProgress * (3.0f - 2.0f * plateProgress);
            poseStack.pushPose();
            poseStack.translate(0.5, -0.08f + 0.52f * plateEased, 0.5);
            poseStack.scale(1.02f, 0.5f + 0.5f * plateEased, 1.02f);
            poseStack.translate(-0.5, 0.0, -0.5);
            context.getBlockRenderDispatcher().renderSingleBlock(STONE_PRESSURE_PLATE, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
            poseStack.popPose();

            renderEmergedDirtRing(poseStack, buffer, light, 0.35f + 0.65f * eased);
        }
        poseStack.popPose();
    }

    private void renderBuriedDirt(PoseStack poseStack, MultiBufferSource buffer, int light, float heightScale) {
        poseStack.pushPose();
        poseStack.scale(1.0f, heightScale, 1.0f);
        renderDirtClod(poseStack, buffer, light, 0.20f, 0.00f, 0.30f, 0.30f, 0.24f);
        renderDirtClod(poseStack, buffer, light, 0.52f, 0.00f, 0.48f, 0.24f, 0.20f);
        renderDirtClod(poseStack, buffer, light, 0.76f, 0.00f, 0.28f, 0.26f, 0.22f);
        renderDirtClod(poseStack, buffer, light, 0.40f, 0.00f, 0.72f, 0.22f, 0.18f);
        poseStack.popPose();
    }

    private void renderEmergedDirtRing(PoseStack poseStack, MultiBufferSource buffer, int light, float heightScale) {
        poseStack.pushPose();
        poseStack.scale(1.0f, heightScale, 1.0f);
        // Low, irregular clods hug all four sides of the TNT footprint and start at ground level.
        // The TNT spans roughly x/z=0.04..0.96, so the ring remains outside that footprint.
        renderDirtClod(poseStack, buffer, light, 0.04f, 0.00f, -0.12f, 0.22f, 0.10f, 0.12f);
        renderDirtClod(poseStack, buffer, light, 0.36f, 0.00f, -0.12f, 0.24f, 0.14f, 0.12f);
        renderDirtClod(poseStack, buffer, light, 0.68f, 0.00f, -0.12f, 0.22f, 0.09f, 0.12f);
        renderDirtClod(poseStack, buffer, light, 0.04f, 0.00f, 1.00f, 0.24f, 0.13f, 0.12f);
        renderDirtClod(poseStack, buffer, light, 0.40f, 0.00f, 1.00f, 0.22f, 0.09f, 0.12f);
        renderDirtClod(poseStack, buffer, light, 0.70f, 0.00f, 1.00f, 0.20f, 0.15f, 0.12f);
        renderDirtClod(poseStack, buffer, light, -0.12f, 0.00f, 0.12f, 0.12f, 0.12f, 0.22f);
        renderDirtClod(poseStack, buffer, light, -0.12f, 0.00f, 0.42f, 0.12f, 0.08f, 0.20f);
        renderDirtClod(poseStack, buffer, light, -0.12f, 0.00f, 0.70f, 0.12f, 0.13f, 0.18f);
        renderDirtClod(poseStack, buffer, light, 1.00f, 0.00f, 0.10f, 0.12f, 0.15f, 0.22f);
        renderDirtClod(poseStack, buffer, light, 1.00f, 0.00f, 0.40f, 0.12f, 0.09f, 0.22f);
        renderDirtClod(poseStack, buffer, light, 1.00f, 0.00f, 0.70f, 0.12f, 0.12f, 0.18f);

        // 出土后再补一圈大小不一的外侧土渣，让 TNT 更像刚从地里露出来。
        renderDirtClod(poseStack, buffer, light, -0.24f, 0.00f, -0.18f, 0.20f, 0.18f, 0.18f);
        renderDirtClod(poseStack, buffer, light, 0.20f, 0.00f, -0.18f, 0.16f, 0.11f, 0.16f);
        renderDirtClod(poseStack, buffer, light, 0.82f, 0.00f, -0.18f, 0.22f, 0.17f, 0.16f);
        renderDirtClod(poseStack, buffer, light, 1.08f, 0.00f, -0.14f, 0.18f, 0.12f, 0.18f);
        renderDirtClod(poseStack, buffer, light, -0.22f, 0.00f, 0.88f, 0.18f, 0.14f, 0.20f);
        renderDirtClod(poseStack, buffer, light, 0.18f, 0.00f, 1.08f, 0.22f, 0.19f, 0.17f);
        renderDirtClod(poseStack, buffer, light, 0.78f, 0.00f, 1.08f, 0.17f, 0.12f, 0.18f);
        renderDirtClod(poseStack, buffer, light, 1.08f, 0.00f, 0.82f, 0.19f, 0.18f, 0.20f);
        renderDirtClod(poseStack, buffer, light, -0.20f, 0.00f, 0.28f, 0.14f, 0.10f, 0.15f);
        renderDirtClod(poseStack, buffer, light, -0.20f, 0.00f, 0.66f, 0.16f, 0.16f, 0.14f);
        renderDirtClod(poseStack, buffer, light, 1.08f, 0.00f, 0.28f, 0.16f, 0.11f, 0.15f);
        renderDirtClod(poseStack, buffer, light, 1.08f, 0.00f, 0.64f, 0.14f, 0.16f, 0.16f);
        poseStack.popPose();
    }

    private void renderDirtClod(PoseStack poseStack, MultiBufferSource buffer, int light,
                                float x, float y, float z, float width, float height) {
        renderDirtClod(poseStack, buffer, light, x, y, z, width, height, width);
    }

    private void renderDirtClod(PoseStack poseStack, MultiBufferSource buffer, int light,
                                float x, float y, float z, float width, float height, float depth) {
        poseStack.pushPose();
        poseStack.translate(x, y, z);
        poseStack.scale(width, height, depth);
        context.getBlockRenderDispatcher().renderSingleBlock(DIRT, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);
        poseStack.popPose();
    }

    /** 机身与活塞头拼成一个 0.9³ 的立方体：机身占后段，活塞头是前段 0.25 厚的板。 */
    private static final float PISTON_MIN = 0.05f;
    private static final float PISTON_MAX = 0.95f;
    private static final float PISTON_HEAD_BACK = 0.30f;
    private static final float PISTON_BODY_BACK = 0.95f;
    /** 活塞头板厚度、活塞臂截面半宽（原版为 4/16 宽 → 半宽 0.125）与攻击时活塞头弹出行程。 */
    private static final float PISTON_HEAD_THICK = 0.25f;
    private static final float PISTON_ARM_HALF = 0.125f;
    /** 活塞臂沿长度方向每 0.25 格重复一次木纹带 UV，避免长杆被拉伸成一根模糊木棍。 */
    private static final float PISTON_ARM_SEGMENT = 0.25f;
    private static final float PISTON_STRIKE_TRAVEL = 0.28f;
    /** piston_side 顶部 4 行是木纹带（只允许出现在活塞头板边缘与活塞臂四壁）。 */
    private static final float PISTON_SIDE_WOOD_VMAX = 0.25f;
    /** piston_side 底部 12 行是石质带：机身四侧只采样这一段，杜绝"身体上出现头部贴图"。 */
    private static final float PISTON_SIDE_STONE_VMIN = 0.25f;
    /** piston_inner 中央黑孔的半宽（贴图约 5..11px），活塞头再生从此宽度起步。 */
    private static final float PISTON_HOLE_HALF = 0.17f;

    /**
     * 冲击活塞：整体是一只**侧放的活塞**——石头机身在后，活塞头（piston_top 木板）朝模型 -Z，
     * 即实体的视野朝向。机身四侧只采样 piston_side 底部的石质带（木纹带属于头部，绝不允许出现在
     * 身体上），机背用 piston_bottom，头缺失时正面露出带黑孔的活塞孔板（piston_inner，与用户
     * 参考图完全一致）。
     * 普通攻击：活塞头被一小截细臂顶出再掉落；之后的 20 秒里，新活塞头从黑孔中由内向外生长。
     * 激发潜能：从活塞孔里伸出一根原版规格（4/16 宽）的细长**活塞臂**，沿长度每 0.25 格重复木纹带，
     * 最长 10 格——被延长的是连接活塞头与石头机身的臂，活塞头板大小始终不变。
     */
    private void renderPunchPiston(PunchPistonEntity entity, float partialTick, PoseStack poseStack, MultiBufferSource buffer, int light) {
        ensurePistonSprites();
        VertexConsumer consumer = buffer.getBuffer(PISTON_ATLAS_RENDER_TYPE);
        int thrust = entity.getThrustTicks();
        boolean headPresent = entity.isHeadPresent();
        boolean armActive = entity.getArmTicks() > 0;

        // 机身：侧面仅采样石质带（v 0.25→1.0），正面（-Z 端）始终是活塞孔板，
        // 活塞头贴合时会把它整个盖住。
        pistonBox(poseStack, consumer, light,
                PISTON_MIN, PISTON_MAX, PISTON_MIN, PISTON_MAX, PISTON_HEAD_BACK, PISTON_BODY_BACK,
                pistonHoleSprite, pistonBottomSprite, pistonSideSprite, true,
                PISTON_SIDE_STONE_VMIN, 1.0f);

        if (armActive) {
            // 活塞臂：推出 10 tick（缓出）→ 保持 → 收回 15 tick（缓入），沿模型 -Z 即面朝方向。
            int arm = entity.getArmTicks();
            float elapsed = PunchPistonEntity.ARM_TOTAL_TICKS - arm + (1.0f - partialTick);
            float extension;
            if (elapsed < PunchPistonEntity.ARM_EXTEND_TICKS) {
                extension = smoothstep(elapsed / PunchPistonEntity.ARM_EXTEND_TICKS);
            } else if (elapsed < PunchPistonEntity.ARM_HOLD_END_TICKS) {
                extension = 1.0f;
            } else {
                extension = 1.0f - smoothstep((elapsed - PunchPistonEntity.ARM_HOLD_END_TICKS)
                        / (PunchPistonEntity.ARM_TOTAL_TICKS - PunchPistonEntity.ARM_HOLD_END_TICKS));
            }
            float ext = (float) (PunchPistonEntity.ARM_LENGTH * extension);
            drawPistonHeadAndArm(poseStack, consumer, light, ext, headPresent);
        } else if (headPresent && thrust > 0) {
            // 攻击动画：活塞头整体沿视野方向弹出，服务端在本段动画结束时判头掉落。
            float rise = smoothstep(Math.min(1.0f, (PunchPistonEntity.THRUST_TOTAL_TICKS - thrust + 1.0f - partialTick) / 2.0f));
            drawPistonHeadAndArm(poseStack, consumer, light, PISTON_STRIKE_TRAVEL * rise, true);
        } else if (headPresent) {
            // 常态：活塞头贴合机身正面，与机身拼成完整立方体。
            pistonHeadPlate(poseStack, consumer, light,
                    PISTON_HEAD_BACK - PISTON_HEAD_THICK, PISTON_HEAD_BACK, false);
        } else {
            // 生长动画：新活塞头从 piston_inner 的黑孔里由内向外长出来——
            // 先在孔口探出一小块木芯，随后边向外推边加宽，最后一帧与常驻头部严丝合缝。
            float grow = Math.max(0.0f, Math.min(1.0f,
                    1.0f - (entity.getRechargeTicks() - partialTick) / PunchPistonEntity.RECHARGE_TICKS));
            float half = PISTON_HOLE_HALF + (0.45f - PISTON_HOLE_HALF) * smoothstep(Math.min(1.0f, grow / 0.75f));
            float depth = 0.05f + (PISTON_HEAD_THICK - 0.05f) * smoothstep(grow);
            pistonHeadPlate(poseStack, consumer, light,
                    0.5f - half, 0.5f + half, 0.5f - half, 0.5f + half,
                    PISTON_HEAD_BACK - depth, PISTON_HEAD_BACK, false);
        }
    }

    /**
     * 沿 -Z（面朝方向）伸出活塞臂并把活塞头顶到臂端：臂是**原版规格**的细方杆——截面 4/16 宽、
     * 恰好从 piston_inner 黑孔（约 6/16 宽）中穿出，四壁用 piston_side 顶部木纹带并沿长度每 0.25 格
     * 重复一段，因此不论伸出一格还是十格都保持同一粗细的实心木杆观感，不会被拉伸成一根模糊的
     * 长木棍、更不会看着像"拉长的活塞头"。活塞头板是被臂顶在杆端的整块面板（piston_top 贴图），
     * 尺寸始终与贴合时一致——被延长的只有臂。头缺失时只出杆、不带面板，并补一个杆端盖防止看穿内部。
     */
    private void drawPistonHeadAndArm(PoseStack poseStack, VertexConsumer consumer, int light,
                                      float extension, boolean headPresent) {
        if (extension > 0.02f) {
            float armMin = 0.5f - PISTON_ARM_HALF;
            float armMax = 0.5f + PISTON_ARM_HALF;
            float tipZ = PISTON_HEAD_BACK - extension;
            // 杆身后端与活塞孔板共面，逐段画四壁；每段重复木纹带 UV。
            for (float z0 = PISTON_HEAD_BACK; z0 > tipZ + 1.0e-4f; z0 -= PISTON_ARM_SEGMENT) {
                float z1 = Math.max(tipZ, z0 - PISTON_ARM_SEGMENT);
                pistonSides(poseStack, consumer, light,
                        armMin, armMax, armMin, armMax, z1, z0,
                        pistonSideSprite, 0.0f, PISTON_SIDE_WOOD_VMAX);
            }
            if (headPresent) {
                // 头贴在臂端：随臂一起向外推进，板大小不变。
                pistonHeadPlate(poseStack, consumer, light, tipZ - PISTON_HEAD_THICK, tipZ, true);
            } else {
                // 无头时补杆端盖（-Z 端），避免从正前方看穿杆内部。
                PoseStack.Pose pose = poseStack.last();
                spriteQuad(consumer, pose.pose(), pose, light,
                        armMin, armMin, tipZ, armMax, armMin, tipZ, armMax, armMax, tipZ, armMin, armMax, tipZ,
                        pistonSideSprite, 0.0f, 0.0f, -1.0f);
            }
        } else if (headPresent) {
            pistonHeadPlate(poseStack, consumer, light,
                    PISTON_HEAD_BACK - PISTON_HEAD_THICK, PISTON_HEAD_BACK, false);
        }
    }

    /** 活塞头面板：水平面铺满机身截面，只由 z 决定贴合位置（供常驻贴合与臂端两处复用）。 */
    private void pistonHeadPlate(PoseStack poseStack, VertexConsumer consumer, int light,
                                 float minZ, float maxZ, boolean drawBack) {
        pistonHeadPlate(poseStack, consumer, light,
                PISTON_MIN, PISTON_MAX, PISTON_MIN, PISTON_MAX, minZ, maxZ, drawBack);
    }

    /** 活塞头面板：尺寸可变，供再生动画从活塞孔里由小到大长出来。 */
    private void pistonHeadPlate(PoseStack poseStack, VertexConsumer consumer, int light,
                                 float minX, float maxX, float minY, float maxY,
                                 float minZ, float maxZ, boolean drawBack) {
        pistonBox(poseStack, consumer, light, minX, maxX, minY, maxY, minZ, maxZ,
                pistonTopSprite, pistonTopSprite, pistonSideSprite, drawBack,
                0.0f, PISTON_SIDE_WOOD_VMAX);
    }

    private TextureAtlasSprite pistonSideSprite;
    private TextureAtlasSprite pistonTopSprite;
    private TextureAtlasSprite pistonBottomSprite;
    private TextureAtlasSprite pistonHoleSprite;

    /** 惰性取原版活塞四张贴图：机身侧面 piston_side、活塞头 piston_top、机背 piston_bottom、活塞孔 piston_inner。 */
    private void ensurePistonSprites() {
        if (pistonSideSprite == null) {
            net.minecraft.client.renderer.block.BlockRenderDispatcher dispatcher = context.getBlockRenderDispatcher();
            pistonSideSprite = dispatcher.getBlockModelShaper().getParticleIcon(Blocks.PISTON.defaultBlockState());
            pistonTopSprite = dispatcher.getBlockModelShaper().getParticleIcon(Blocks.PISTON_HEAD.defaultBlockState());
            java.util.function.Function<ResourceLocation, TextureAtlasSprite> blockAtlas = net.minecraft.client.Minecraft.getInstance()
                    .getTextureAtlas(net.minecraft.client.renderer.texture.TextureAtlas.LOCATION_BLOCKS);
            pistonBottomSprite = blockAtlas.apply(ResourceLocation.withDefaultNamespace("block/piston_bottom"));
            pistonHoleSprite = blockAtlas.apply(ResourceLocation.withDefaultNamespace("block/piston_inner"));
        }
    }

    /**
     * 侧放活塞专用立方体：轴向沿 z（-Z 端为活塞头朝向），front/back 铺 z 两端，
     * 四个侧面统一用 side 贴图，并保证贴图 v 起始端落在 -Z 端——
     * 与原版活塞"木纹贴近活塞头、石底贴近机背"的朝向一致。drawBack=false 时跳过 +Z 端面；
     * sideVMin/sideVMax 限定侧面采样的贴图纵向范围（机身只取底部石质带，活塞臂/头板边缘只取顶部木纹带）。
     */
    private void pistonBox(PoseStack poseStack, VertexConsumer consumer, int light,
                           float minX, float maxX, float minY, float maxY, float minZ, float maxZ,
                           TextureAtlasSprite front, TextureAtlasSprite back, TextureAtlasSprite side,
                           boolean drawBack, float sideVMin, float sideVMax) {
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        // -Z 端面（正面）：u 沿 +x，v 沿 +y。
        spriteQuad(consumer, matrix, pose, light,
                minX, minY, minZ, maxX, minY, minZ, maxX, maxY, minZ, minX, maxY, minZ, front, 0, 0, -1);
        if (drawBack) {
            // +Z 端面（机背）：u 沿 -x 保持外向绕序。
            spriteQuad(consumer, matrix, pose, light,
                    maxX, minY, maxZ, minX, minY, maxZ, minX, maxY, maxZ, maxX, maxY, maxZ, back, 0, 0, 1);
        }
        pistonSides(poseStack, consumer, light, minX, maxX, minY, maxY, minZ, maxZ, side, sideVMin, sideVMax);
    }

    /** 只画立方体的四个侧面（z 两端留空）：活塞臂逐段重复木纹带时复用。 */
    private void pistonSides(PoseStack poseStack, VertexConsumer consumer, int light,
                             float minX, float maxX, float minY, float maxY, float minZ, float maxZ,
                             TextureAtlasSprite side, float vMin, float vMax) {
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        // 东侧：v=vMin 边贴 minZ，u 沿 +y。
        spriteQuadBand(consumer, matrix, pose, light,
                maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, side, vMin, vMax, 1, 0, 0);
        // 西侧：v=vMin 边贴 minZ，u 沿 -y。
        spriteQuadBand(consumer, matrix, pose, light,
                minX, minY, minZ, minX, maxY, minZ, minX, maxY, maxZ, minX, minY, maxZ, side, vMin, vMax, -1, 0, 0);
        // 顶面：v=vMin 边贴 minZ，u 沿 +x。
        spriteQuadBand(consumer, matrix, pose, light,
                minX, maxY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, minX, maxY, maxZ, side, vMin, vMax, 0, 1, 0);
        // 底面：v=vMin 边贴 minZ，u 沿 +x。
        spriteQuadBand(consumer, matrix, pose, light,
                minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, side, vMin, vMax, 0, -1, 0);
    }

    /** 与 spriteQuad 相同，但纵向只采样贴图的 [vMin, vMax] 段（机身取石质带、臂与头板边缘取木纹带）。 */
    private static void spriteQuadBand(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose, int light,
                                       float x1, float y1, float z1, float x2, float y2, float z2,
                                       float x3, float y3, float z3, float x4, float y4, float z4,
                                       TextureAtlasSprite sprite, float vMin, float vMax, float nx, float ny, float nz) {
        texturedQuad(consumer, matrix, pose, light, x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4,
                sprite.getU(0.0f), sprite.getV(vMin), sprite.getU(1.0f), sprite.getV(vMax), nx, ny, nz);
    }

    private static void spriteQuad(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose, int light,
                                   float x1, float y1, float z1, float x2, float y2, float z2,
                                   float x3, float y3, float z3, float x4, float y4, float z4,
                                   TextureAtlasSprite sprite, float nx, float ny, float nz) {
        texturedQuad(consumer, matrix, pose, light, x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4,
                sprite.getU(0.0f), sprite.getV(0.0f), sprite.getU(1.0f), sprite.getV(1.0f), nx, ny, nz);
    }

    private void renderObsidian(ObsidianEntity entity, PoseStack poseStack, MultiBufferSource buffer, int light) {
        poseStack.scale(0.9f, 0.9f, 0.9f);
        context.getBlockRenderDispatcher().renderSingleBlock(OBSIDIAN, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);

        if (entity.isEmpowered()) {
            poseStack.pushPose();
            poseStack.translate(0.5, 0.5, 0.5);
            poseStack.scale(1.06f, 1.06f, 1.06f);
            poseStack.translate(-0.5, -0.5, -0.5);
            renderAlloyArmor(entity.getArmorStage(), poseStack, buffer, light);
            poseStack.popPose();
        }

        int crackStage = entity.getCrackStage();
        if (crackStage > 0) {
            ResourceLocation texture = crackStage == 1 ? DAMAGE_MEDIUM : DAMAGE_HEAVY;
            float inflate = entity.isEmpowered() ? 0.035f : 0.012f;
            renderCrackCube(poseStack, buffer.getBuffer(RenderType.entityTranslucent(texture)), light, inflate);
        }
    }

    /**
     * 合金甲外壳：四侧换成三档观察窗贴图（护甲越残、裂纹越多），顶/底面沿用合金块。
     * <p>观察窗在贴图里是透明镂空，因此这里只画甲壳本身、不再垫一整块合金块，
     * 透过去正好看到内层略小一圈的黑曜石本体，形成 recessed 的“观察窗”。
     * 每条侧壁都按“图像上方两顶点写 v=0、下方两顶点写 v=1”排列，
     * 保证观察窗在侧面上居中偏上，不会上下颠倒。</p>
     */
    private static void renderAlloyArmor(int stage, PoseStack poseStack, MultiBufferSource buffer, int light) {
        RenderType side = stage <= 0 ? ARMOR_SIDE_INTACT : stage == 1 ? ARMOR_SIDE_DAMAGED : ARMOR_SIDE_BROKEN;
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        // 重要：一个 MultiBufferSource 在任一时刻只保留一个“共享”构建器。
        // 侧壁用的 entityCutoutNoCull 不在 fixedBuffers 里，取下一个不同类型（顶/底面的合金块）
        // 的缓冲时会先把上一个 endBatch 掉；实体渲染走的 OutlineBufferSource 还额外共用
        // 一个只装 1536 字节的 outline 缓冲。所以必须“取一种、写完、再取另一种”，
        // 两种缓冲交错持有会让先取到的 consumer 在写入时抛 IllegalStateException: Not building!。
        VertexConsumer sideConsumer = buffer.getBuffer(side);
        // 北面（-Z）：观察窗朝上，u 沿 +x。
        texturedQuad(sideConsumer, matrix, pose, light,
                0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
                0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, -1.0f);
        // 南面（+Z）：观察窗朝上，u 沿 -x。
        texturedQuad(sideConsumer, matrix, pose, light,
                1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
                0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 1.0f);
        // 东面（+X）：观察窗朝上，u 沿 -z。
        texturedQuad(sideConsumer, matrix, pose, light,
                1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f,
                0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f);
        // 西面（-X）：观察窗朝上，u 沿 +z。
        texturedQuad(sideConsumer, matrix, pose, light,
                0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f,
                0.0f, 0.0f, 1.0f, 1.0f, -1.0f, 0.0f, 0.0f);
        // 四个侧面全部写完后，才允许取第二种缓冲。
        VertexConsumer capConsumer = buffer.getBuffer(ARMOR_CAP);
        // 顶面（+Y）。
        texturedQuad(capConsumer, matrix, pose, light,
                0.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f,
                0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f);
        // 底面（-Y）。
        texturedQuad(capConsumer, matrix, pose, light,
                0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
                0.0f, 0.0f, 1.0f, 1.0f, 0.0f, -1.0f, 0.0f);
    }

    /**
     * 本体损毁叠加立方体：六面各铺一遍破坏贴图，整体比本体略大一点（inflate）避免 z-fighting。
     * <p>uv 排列与合金甲侧壁完全一致（v=0 对应图像上方、v=1 对应下方），四个侧面的贴图都是正的；
     * 法线逐个面写成真实的朝外方向——实体着色器的方向光（minecraft_mix_light）吃法线，
     * 之前正/背面被写成 (0,-1,0)/(0,1,0)，光照系数从 0.74 掉到 0.4，破损图在这两个面上又暗又糊。</p>
     */
    private static void renderCrackCube(PoseStack poseStack, VertexConsumer consumer, int light, float inflate) {
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        float min = -inflate;
        float max = 1.0f + inflate;
        // 北面（-Z）：观察图像上方两顶点写 v=0、下方两顶点写 v=1。
        quad(consumer, matrix, pose, light, min, max, min, max, max, min, max, min, min, min, min, min, 0, 0, 1, 1, 0, 0, -1);
        // 南面（+Z）。
        quad(consumer, matrix, pose, light, max, max, max, min, max, max, min, min, max, max, min, max, 0, 0, 1, 1, 0, 0, 1);
        // 东面（+X）。
        quad(consumer, matrix, pose, light, max, max, min, max, max, max, max, min, max, max, min, min, 0, 0, 1, 1, 1, 0, 0);
        // 西面（-X）。
        quad(consumer, matrix, pose, light, min, max, max, min, max, min, min, min, min, min, min, max, 0, 0, 1, 1, -1, 0, 0);
        // 顶面（+Y）。
        quad(consumer, matrix, pose, light, min, max, min, max, max, min, max, max, max, min, max, max, 0, 0, 1, 1, 0, 1, 0);
        // 底面（-Y）。
        quad(consumer, matrix, pose, light, min, min, max, max, min, max, max, min, min, min, min, min, 0, 0, 1, 1, 0, -1, 0);
    }

    private static void quad(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose, int light,
                            float x1, float y1, float z1, float x2, float y2, float z2,
                            float x3, float y3, float z3, float x4, float y4, float z4,
                            float u1, float v1, float u2, float v2, float nx, float ny, float nz) {
        vertex(consumer, matrix, pose, light, x1, y1, z1, u1, v1, nx, ny, nz);
        vertex(consumer, matrix, pose, light, x2, y2, z2, u2, v1, nx, ny, nz);
        vertex(consumer, matrix, pose, light, x3, y3, z3, u2, v2, nx, ny, nz);
        vertex(consumer, matrix, pose, light, x4, y4, z4, u1, v2, nx, ny, nz);
    }

    private static void vertex(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose, int light,
                               float x, float y, float z, float u, float v, float nx, float ny, float nz) {
        consumer.addVertex(matrix, x, y, z)
                .setColor(255, 255, 255, 255)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(pose, nx, ny, nz);
    }

    private void renderEvocationStar(MachineryEntity entity, float partialTick, PoseStack poseStack, MultiBufferSource buffer) {
        float remaining = entity.getEvocationEffectTicks() - partialTick;
        if (remaining <= 0.0f) return;

        float progress = Math.max(0.0f, Math.min(1.0f,
                1.0f - remaining / MachineryEntity.EVOCATION_EFFECT_TICKS));
        // 多层星芒按由内向外的顺序展开，最外层最终直径为 1.8 格，接近玩家高度。
        float fade = 1.0f - progress * progress * (3.0f - 2.0f * progress);
        float innerProgress = smoothstep(Math.min(1.0f, progress / 0.62f));
        float middleProgress = smoothstep(Math.max(0.0f, Math.min(1.0f, (progress - 0.08f) / 0.72f)));
        float outerProgress = smoothstep(Math.max(0.0f, Math.min(1.0f, (progress - 0.18f) / 0.82f)));

        poseStack.pushPose();
        poseStack.translate(0.0, 0.72, 0.0);
        poseStack.mulPose(entityRenderDispatcher.cameraOrientation());
        // 先绘制外层，再绘制内层，让中心区域叠加得更亮、更浓。
        renderStarLayer(poseStack, buffer, 0.10f + 1.70f * outerProgress, (int) (155.0f * fade));
        renderStarLayer(poseStack, buffer, 0.08f + 1.17f * middleProgress, (int) (190.0f * fade));
        renderStarLayer(poseStack, buffer, 0.06f + 0.66f * innerProgress, (int) (230.0f * fade));
        poseStack.popPose();
    }

    private static float smoothstep(float value) {
        return value * value * (3.0f - 2.0f * value);
    }

    private void renderStarLayer(PoseStack poseStack, MultiBufferSource buffer, float scale, int alpha) {
        poseStack.pushPose();
        poseStack.scale(scale, scale, scale);
        VertexConsumer consumer = buffer.getBuffer(EVOCATION_STAR_RENDER_TYPE);
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        billboardVertex(consumer, matrix, pose, -0.5f, 0.5f, 0.0f, 0.0f, 1.0f, alpha);
        billboardVertex(consumer, matrix, pose, 0.5f, 0.5f, 0.0f, 1.0f, 1.0f, alpha);
        billboardVertex(consumer, matrix, pose, 0.5f, -0.5f, 0.0f, 1.0f, 0.0f, alpha);
        billboardVertex(consumer, matrix, pose, -0.5f, -0.5f, 0.0f, 0.0f, 0.0f, alpha);
        poseStack.popPose();
    }

    /** 激发潜能后，把蓝光投到传感器周围 3×3 方块的顶面上，让蓝光真正"照"在方块上。 */
    private void renderBlueLightPool(MoonlightSensorEntity entity, float partialTick, PoseStack poseStack, MultiBufferSource buffer) {
        // 蓝色亮光池随呼吸一起明暗；整体提亮并加深蓝色，让蓝光更明显。
        float pulse = 0.96f + 0.22f * (float) Math.sin((entity.tickCount + partialTick) * 0.14f);
        LevelReader level = entity.level();
        BlockPos base = entity.blockPosition();
        VertexConsumer consumer = buffer.getBuffer(RenderType.lightning());
        poseStack.pushPose();
        PoseStack.Pose pose = poseStack.last();
        Matrix4f matrix = pose.pose();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                BlockPos column = base.offset(dx, 0, dz);
                int surfaceY = findLightPoolSurfaceY(level, column, base.getY());
                if (surfaceY == Integer.MIN_VALUE) continue;
                double distance = Math.sqrt(dx * dx + dz * dz);
                int red;
                int green;
                int blue;
                int alpha;
                if (distance < 0.5) {
                    red = 70; green = 160; blue = 255; alpha = 185;
                } else if (distance < 1.5) {
                    red = 52; green = 142; blue = 255; alpha = 132;
                } else {
                    red = 36; green = 122; blue = 250; alpha = 92;
                }
                alpha = (int) (alpha * pulse);
                float x0 = (float) (column.getX() - entity.getX());
                float x1 = x0 + 1.0f;
                float z0 = (float) (column.getZ() - entity.getZ());
                float z1 = z0 + 1.0f;
                // 抬高一点点避免与方块顶面闪烁，叠加混合让相邻光池交界处自然过渡。
                float y = (float) (surfaceY + 0.006 - entity.getY());
                blueGlowVertex(consumer, matrix, pose, x0, y, z0, red, green, blue, alpha);
                blueGlowVertex(consumer, matrix, pose, x1, y, z0, red, green, blue, alpha);
                blueGlowVertex(consumer, matrix, pose, x1, y, z1, red, green, blue, alpha);
                blueGlowVertex(consumer, matrix, pose, x0, y, z1, red, green, blue, alpha);
            }
        }
        poseStack.popPose();
    }

    /** 从传感器所在层向下找该列第一个顶面结实的方块表面；悬空列（如坑洞）则不投光池。 */
    private static int findLightPoolSurfaceY(LevelReader level, BlockPos column, int baseY) {
        for (int y = baseY; y >= baseY - 3; y--) {
            BlockPos pos = column.atY(y);
            BlockState state = level.getBlockState(pos);
            if (state.isFaceSturdy(level, pos, Direction.UP)) return y + 1;
        }
        return Integer.MIN_VALUE;
    }

    private static void blueGlowVertex(VertexConsumer consumer, Matrix4f matrix, PoseStack.Pose pose,
                                       float x, float y, float z,
                                       int red, int green, int blue, int alpha) {
        consumer.addVertex(matrix, x, y, z)
                .setColor(red, green, blue, alpha);
    }

    @Override
    protected int getBlockLightLevel(MachineryEntity entity, BlockPos pos) {
        if (entity instanceof MoonlightSensorEntity sensor && sensor.isEmpowered()) return 7;
        if (entity instanceof GlowstoneEntity) return 15;
        // 炽炎熔炉本体按它照进世界的 14 级光渲染，南瓜灯在暗处也保持自身明亮。
        if (entity instanceof SoulforgeEntity) return 14;
        return entity instanceof FurnaceEntity ? 10 : super.getBlockLightLevel(entity, pos);
    }

    @Override
    public ResourceLocation getTextureLocation(MachineryEntity entity) {
        return BLOCK_ATLAS;
    }
}
