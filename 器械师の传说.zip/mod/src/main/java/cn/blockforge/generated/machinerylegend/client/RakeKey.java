package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.network.PlaceRakePayload;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** 钉耙放置按键，默认绑定 J，并允许玩家在控制设置中修改。 */
@EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class RakeKey {
    public static final KeyMapping PLACE_RAKE_KEY = new KeyMapping(
            "key.machinery_legend.place_rake", InputConstants.Type.KEYSYM,
            InputConstants.KEY_J, "key.categories.machinery_legend");

    private RakeKey() {}

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(PLACE_RAKE_KEY);
    }

    @EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.GAME)
    public static final class Tick {
        private Tick() {}

        @SubscribeEvent
        public static void clientTick(ClientTickEvent.Post event) {
            while (PLACE_RAKE_KEY.consumeClick()) {
                Minecraft minecraft = Minecraft.getInstance();
                if (minecraft.player == null || minecraft.level == null || minecraft.screen != null) continue;
                if (!cn.blockforge.generated.machinerylegend.item.RakeItem.isActive(minecraft.player)
                        || !minecraft.player.getMainHandItem().is(net.minecraft.world.item.Items.IRON_HOE)) continue;
                if (minecraft.hitResult instanceof BlockHitResult hit
                        && hit.getType() == HitResult.Type.BLOCK
                        && hit.getDirection() == net.minecraft.core.Direction.UP) {
                    PacketDistributor.sendToServer(new PlaceRakePayload(hit.getBlockPos()));
                }
            }
        }
    }
}
