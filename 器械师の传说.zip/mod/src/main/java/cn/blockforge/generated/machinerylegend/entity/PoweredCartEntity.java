package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** 动力推车：外观沿用原版动力矿车，沿直线滚动并通过实体碰撞避免穿墙。 */
public final class PoweredCartEntity extends AbstractMinecart {
    private static final EntityDataAccessor<Boolean> DATA_DRIVEN =
            SynchedEntityData.defineId(PoweredCartEntity.class, EntityDataSerializers.BOOLEAN);

    private static final int DRIVE_LIFETIME_TICKS = 20 * 20;
    private static final float CONTACT_DAMAGE = 250.0f;
    private static final float EXPLOSION_DAMAGE = 120.0f;
    private static final double DRIVE_SPEED = 0.30;
    private static final double GROUND_Y_VELOCITY = -0.03;
    private static final double HORIZONTAL_EPSILON = 1.0E-7;
    private static final double STEP_HEIGHT = 1.0;
    private static final ExplosionDamageCalculator EXPLOSION_CALCULATOR = new ExplosionDamageCalculator() {
        @Override
        public float getEntityDamageAmount(net.minecraft.world.level.Explosion explosion, Entity entity) {
            // 爆炸范围仍由原版单格爆炸决定，但范围内每个实体都承受固定 120 点伤害。
            return EXPLOSION_DAMAGE;
        }

        @Override
        public boolean shouldBlockExplode(net.minecraft.world.level.Explosion explosion,
                                          net.minecraft.world.level.BlockGetter level,
                                          net.minecraft.core.BlockPos pos, BlockState state, float power) {
            return false;
        }
    };

    private static final String DRIVEN_TAG = "Driven";
    private static final String DIRECTION_X_TAG = "DirectionX";
    private static final String DIRECTION_Z_TAG = "DirectionZ";
    private static final String DRIVE_TICKS_TAG = "DriveTicks";

    private boolean driven;
    private boolean detonated;
    private double directionX;
    private double directionZ;
    private int driveTicks;

    public PoweredCartEntity(EntityType<? extends PoweredCartEntity> type, Level level) {
        super(type, level);
        setCanUseRail(false);
    }

    @Override
    protected double getDefaultGravity() {
        // 与滚动雪球保持相同的下坠速度。
        return 0.03;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void push(Entity entity) {
        // 驱动方向只由右键时玩家的站位决定，不接受其他实体的推挤。
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        // 驱动时敌对生物只作为伤害目标，不参与方块移动的实体碰撞阻挡。
        return !driven && super.canCollideWith(entity);
    }

    @Override
    public void push(Vec3 movement) {
        // 防止外力改变滚动轨迹。
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_DRIVEN, false);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        // 碰撞箱为宽 1.5、深 1.5、高 1 格；实体位置是碰撞箱底部中心。
        return EntityDimensions.fixed(1.5f, 1.0f);
    }

    @Override
    public Type getMinecartType() {
        return Type.FURNACE;
    }

    @Override
    public BlockState getDefaultDisplayBlockState() {
        return Blocks.FURNACE.defaultBlockState().setValue(
                net.minecraft.world.level.block.state.properties.BlockStateProperties.LIT, true);
    }

    @Override
    protected net.minecraft.world.item.Item getDropItem() {
        return GeneratedMod.POWERED_CART.get();
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(GeneratedMod.POWERED_CART.get());
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        // 客户端先接受交互，真正的方向计算和状态切换只在服务端执行。
        if (level().isClientSide) return InteractionResult.SUCCESS;
        if (driven) return InteractionResult.SUCCESS;

        double awayX = getX() - player.getX();
        double awayZ = getZ() - player.getZ();
        double horizontalLength = Math.sqrt(awayX * awayX + awayZ * awayZ);
        if (horizontalLength <= HORIZONTAL_EPSILON) return InteractionResult.FAIL;

        directionX = awayX / horizontalLength;
        directionZ = awayZ / horizontalLength;
        driven = true;
        entityData.set(DATA_DRIVEN, true);
        driveTicks = 0;
        setCanUseRail(false);
        setYRot((float) (Math.atan2(-directionX, directionZ) * 180.0 / Math.PI));
        setXRot(0.0f);
        setDeltaMovement(directionX * DRIVE_SPEED, 0.0, directionZ * DRIVE_SPEED);
        return InteractionResult.SUCCESS;
    }

    @Override
    public void tick() {
        if (level().isClientSide) {
            // AbstractMinecart 的客户端 tick 负责处理服务端位置插值。
            if (entityData.get(DATA_DRIVEN)) {
                super.tick();
            } else {
                baseTick();
                setDeltaMovement(Vec3.ZERO);
            }
            return;
        }

        baseTick();
        if (isRemoved()) return;
        if (!driven) {
            // 放置后保持静止，只有右键驱动才开始移动。
            setDeltaMovement(Vec3.ZERO);
            return;
        }

        driveTicks++;
        if (driveTicks >= DRIVE_LIFETIME_TICKS) {
            detonate();
            return;
        }

        boolean wasOnGround = onGround();
        double oldX = getX();
        double oldY = getY();
        double oldZ = getZ();
        AABB originalBox = getBoundingBox();
        Vec3 horizontalMotion = new Vec3(directionX * DRIVE_SPEED, 0.0, directionZ * DRIVE_SPEED);
        Vec3 oldMotion = getDeltaMovement();
        double verticalMotion = wasOnGround ? GROUND_Y_VELOCITY : oldMotion.y - getGravity();
        Vec3 requestedMotion = horizontalMotion.add(0.0, verticalMotion, 0.0);

        move(net.minecraft.world.entity.MoverType.SELF, requestedMotion);

        double requestedHorizontal = horizontalMotion.horizontalDistance();
        double movedHorizontal = Math.sqrt(
                square(getX() - oldX) + square(getZ() - oldZ));
        boolean blocked = requestedHorizontal > HORIZONTAL_EPSILON
                && (horizontalCollision || movedHorizontal < requestedHorizontal * 0.20);

        if (blocked && canStepOver(wasOnGround, horizontalMotion, originalBox)) {
            // 与滚动雪球相同：只抬升一格，抬升后的完整碰撞箱和前方空间都必须无碰撞。
            setPos(oldX, oldY + STEP_HEIGHT, oldZ);
            setOnGround(false);
            move(net.minecraft.world.entity.MoverType.SELF, horizontalMotion);
            double steppedDistance = Math.sqrt(square(getX() - oldX) + square(getZ() - oldZ));
            if (horizontalCollision || steppedDistance < requestedHorizontal * 0.20) {
                setPos(oldX, oldY, oldZ);
                stopHorizontalMotion(oldMotion.y);
            } else {
                // 抬升只改变位置，不施加额外竖直速度，避免落地后像粘液块一样反弹。
                setDeltaMovement(directionX * DRIVE_SPEED, 0.0, directionZ * DRIVE_SPEED);
            }
        } else if (blocked) {
            // 墙体高于一格或上方没有空间时停止，绝不强行恢复水平速度穿墙。
            setPos(oldX, oldY, oldZ);
            stopHorizontalMotion(oldMotion.y);
        } else {
            setDeltaMovement(directionX * DRIVE_SPEED, getDeltaMovement().y, directionZ * DRIVE_SPEED);
        }

        setYRot((float) (Math.atan2(-directionX, directionZ) * 180.0 / Math.PI));
        setXRot(0.0f);
        damageHostilesInContact();
    }

    private boolean canStepOver(boolean wasOnGround, Vec3 horizontalMotion, AABB originalBox) {
        if (!wasOnGround || horizontalMotion.horizontalDistanceSqr() <= HORIZONTAL_EPSILON) return false;
        AABB liftedBox = originalBox.move(0.0, STEP_HEIGHT, 0.0);
        AABB liftedForwardBox = liftedBox.move(horizontalMotion.x, 0.0, horizontalMotion.z);
        return level().noCollision(this, liftedBox)
                && level().noCollision(this, liftedForwardBox);
    }

    private void stopHorizontalMotion(double verticalMotion) {
        directionX = 0.0;
        directionZ = 0.0;
        setDeltaMovement(0.0, verticalMotion, 0.0);
    }

    private void damageHostilesInContact() {
        AABB box = getBoundingBox();
        for (LivingEntity target : level().getEntitiesOfClass(LivingEntity.class, box,
                entity -> entity.isAlive() && RebellionLogic.canMachineAttack(this, entity)
                        && entity.getBoundingBox().intersects(box))) {
            MachineryEntity.clearInvulnerabilityForMachineryAttack(target);
            target.hurt(level().damageSources().fellOutOfWorld(), CONTACT_DAMAGE);
        }
    }

    private void detonate() {
        if (detonated || level().isClientSide) return;
        detonated = true;

        // 保留原版单格爆炸的视觉和实体伤害范围；计算器固定伤害数值，并拦截方块破坏。
        level().explode(this,
                level().damageSources().explosion(this, this), EXPLOSION_CALCULATOR,
                getX(), getY(), getZ(), 1.0f, false, Level.ExplosionInteraction.NONE);
        discard();
    }

    private static double square(double value) {
        return value * value;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean(DRIVEN_TAG, driven);
        tag.putDouble(DIRECTION_X_TAG, directionX);
        tag.putDouble(DIRECTION_Z_TAG, directionZ);
        tag.putInt(DRIVE_TICKS_TAG, driveTicks);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        driven = tag.getBoolean(DRIVEN_TAG);
        directionX = tag.getDouble(DIRECTION_X_TAG);
        directionZ = tag.getDouble(DIRECTION_Z_TAG);
        driveTicks = tag.getInt(DRIVE_TICKS_TAG);
        entityData.set(DATA_DRIVEN, driven);
        setCanUseRail(false);
    }
}
