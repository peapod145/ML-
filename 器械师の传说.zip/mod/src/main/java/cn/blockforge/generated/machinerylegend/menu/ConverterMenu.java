package cn.blockforge.generated.machinerylegend.menu;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.player.EnergyData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;

/** 每个玩家打开的独立转化界面；无红石时手动转换，有红石时放入物品会自动转换。 */
public final class ConverterMenu extends AbstractContainerMenu {
    public static final int CONVERT_BUTTON = 0;
    private static final int INPUT_SLOT = 0;
    private static final int PLAYER_INV_START = 1;
    private static final int PLAYER_INV_END = 37;
    private final Container input;
    private final ContainerLevelAccess access;
    private final BlockPos blockPos;
    private final Player player;
    private final ContainerData data;
    private int syncedEnergy;
    private int syncedRedstoneSignal;
    private boolean converting;
    private boolean lastAutoMode;

    public ConverterMenu(int containerId, Inventory inventory, net.minecraft.network.RegistryFriendlyByteBuf data) {
        this(containerId, inventory, data.readBlockPos());
    }

    public ConverterMenu(int containerId, Inventory inventory, BlockPos blockPos) {
        super(GeneratedMod.CONVERTER_MENU.get(), containerId);
        this.player = inventory.player;
        this.blockPos = blockPos;
        this.access = ContainerLevelAccess.create(player.level(), blockPos);
        this.data = new ContainerData() {
            @Override
            public int get(int index) {
                return switch (index) {
                    case 0 -> player.level().isClientSide ? syncedEnergy : EnergyData.get(player);
                    case 1 -> player.level().isClientSide ? syncedRedstoneSignal : redstoneSignal();
                    default -> 0;
                };
            }

            @Override
            public void set(int index, int value) {
                if (index == 0) {
                    syncedEnergy = Math.max(0, Math.min(EnergyData.MAX_ENERGY, value));
                } else if (index == 1) {
                    syncedRedstoneSignal = Math.max(0, Math.min(15, value));
                }
            }

            @Override
            public int getCount() {
                return 2;
            }
        };
        addDataSlots(data);
        this.input = new SimpleContainer(1) {
            @Override
            public void setChanged() {
                super.setChanged();
                ConverterMenu.this.slotsChanged(this);
            }
        };
        this.lastAutoMode = isAutoMode();
        addSlot(new Slot(input, INPUT_SLOT, 56, 17) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return conversionValue(player, stack) > 0;
            }

            @Override
            public int getMaxStackSize() {
                return 64;
            }

            @Override
            public int getMaxStackSize(ItemStack stack) {
                return Math.min(64, stack.getMaxStackSize());
            }
        });
        addPlayerInventory(inventory);
    }

    private void addPlayerInventory(Inventory inventory) {
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(new Slot(inventory, column + row * 9 + 9, 8 + column * 18, 84 + row * 18));
            }
        }
        for (int column = 0; column < 9; column++) {
            addSlot(new Slot(inventory, column, 8 + column * 18, 142));
        }
    }

    private int redstoneSignal() {
        return player.level().hasNeighborSignal(blockPos) ? 15 : 0;
    }

    public int getEnergy() {
        return data.get(0);
    }

    public int getMaxEnergy() {
        return EnergyData.MAX_ENERGY;
    }

    public int getRedstoneSignal() {
        return data.get(1);
    }

    public boolean isAutoMode() {
        return getRedstoneSignal() > 0;
    }

    public ItemStack getInputStack() {
        return input.getItem(INPUT_SLOT);
    }

    public int getInputCount() {
        return getInputStack().getCount();
    }

    public int getInputConversionValue() {
        return conversionValue(player, getInputStack());
    }

    public int getInputTotalEnergy() {
        long total = (long) getInputCount() * getInputConversionValue();
        return (int) Math.min(Integer.MAX_VALUE, total);
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, GeneratedMod.MECHANICAL_ENERGY_CONVERTER.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (!slot.hasItem()) return result;
        ItemStack source = slot.getItem();
        result = source.copy();
        if (index == INPUT_SLOT) {
            if (!moveItemStackTo(source, PLAYER_INV_START, PLAYER_INV_END, true)) return ItemStack.EMPTY;
        } else if (conversionValue(player, source) > 0) {
            if (!moveItemStackTo(source, INPUT_SLOT, INPUT_SLOT + 1, false)) return ItemStack.EMPTY;
        } else {
            return ItemStack.EMPTY;
        }
        if (source.isEmpty()) slot.set(ItemStack.EMPTY);
        else slot.setChanged();
        return result;
    }

    @Override
    public void slotsChanged(Container container) {
        super.slotsChanged(container);
        if (container != input || converting || player.level().isClientSide) return;
        convertIfAutoMode();
    }

    @Override
    public void broadcastChanges() {
        boolean autoMode = isAutoMode();
        if (!player.level().isClientSide && autoMode && !lastAutoMode) {
            convertInput();
        }
        lastAutoMode = autoMode;
        super.broadcastChanges();
    }

    private void convertIfAutoMode() {
        if (isAutoMode()) convertInput();
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id != CONVERT_BUTTON || player != this.player || player.level().isClientSide) return false;
        return convertInput();
    }

    /** 手动按钮和红石自动模式共用的转换逻辑，尽可能转换到机械能上限。 */
    private boolean convertInput() {
        ItemStack stack = input.getItem(INPUT_SLOT);
        int value = conversionValue(player, stack);
        if (value <= 0) return false;

        int availableEnergy = Math.max(0, EnergyData.MAX_ENERGY - EnergyData.get(player));
        int amount = Math.min(stack.getCount(), availableEnergy / value);
        if (amount <= 0) return false;

        converting = true;
        try {
            EnergyData.add(player, amount * value);
            stack.shrink(amount);
            input.setItem(INPUT_SLOT, stack);
            return true;
        } finally {
            converting = false;
        }
    }

    @Override
    public void removed(Player player) {
        super.removed(player);
        clearContainer(player, input);
    }

    /** 返回单件输入物品可转换出的机械能；普通红石制品按首个有序/无序配方计算。 */
    public static int conversionValue(Player player, ItemStack stack) {
        if (stack.isEmpty()) return 0;
        if (stack.is(Items.REDSTONE)) return 25;
        if (stack.is(Items.REDSTONE_BLOCK)) return 250;
        var recipes = player.level().getRecipeManager().getAllRecipesFor(RecipeType.CRAFTING);
        for (RecipeHolder<CraftingRecipe> holder : recipes) {
            CraftingRecipe recipe = holder.value();
            ItemStack result = recipe.getResultItem(player.level().registryAccess());
            if (!result.is(stack.getItem())) continue;
            int redstoneCount = 0;
            for (Ingredient ingredient : recipe.getIngredients()) {
                redstoneCount += redstoneIngredientCount(ingredient);
            }
            if (redstoneCount > 0) return redstoneCount * 25 + 15;
        }
        return 0;
    }

    private static int redstoneIngredientCount(Ingredient ingredient) {
        int best = 0;
        for (ItemStack item : ingredient.getItems()) {
            if (item.is(Items.REDSTONE)) best = Math.max(best, 1);
            else if (item.is(Items.REDSTONE_BLOCK)) best = Math.max(best, 9);
            else {
                String id = BuiltInRegistries.ITEM.getKey(item.getItem()).toString();
                if (id.equals("minecraft:redstone_torch") || id.equals("minecraft:redstone_lamp")
                        || id.equals("minecraft:comparator") || id.equals("minecraft:repeater")) {
                    best = Math.max(best, 1);
                }
            }
        }
        return best;
    }
}
