package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** 狙击发射器：全角度高速箭矢攻击，并可释放需要蓄力的虚空激光。 */
public class SniperEmitterEntity extends MachineryEntity {
    public static final int LASER_LOCK_TICKS = 100;
    private static final EntityDataAccessor<Integer> DATA_LOCK_TARGET_ID =
            SynchedEntityData.defineId(SniperEmitterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_LOCK_TICKS =
            SynchedEntityData.defineId(SniperEmitterEntity.class, EntityDataSerializers.INT);
    private static final float ARROW_SPEED = 4.8f;
    private static final float ARROW_INACCURACY = 0.0f;
    private static final double ATTACK_RANGE = 15.0;
    private static final double MUZZLE_Y_OFFSET = 0.62;
    private static final double MUZZLE_FORWARD_OFFSET = 0.50;
    private static final float LASER_WIDTH = 1.0f;
    private static final float LASER_DAMAGE = 250.0f;
    private static final int NORMAL_COOLDOWN = 28;
    private static final DustParticleOptions LOCK_PARTICLES =
            new DustParticleOptions(new Vector3f(1.0f, 0.02f, 0.02f), 0.20f);
    private static final DustParticleOptions LASER_PARTICLES =
            new DustParticleOptions(new Vector3f(1.0f, 1.0f, 1.0f), 0.24f);

    private int shotCooldown;

    public SniperEmitterEntity(EntityType<? extends SniperEmitterEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_LOCK_TARGET_ID, -1);
        builder.define(DATA_LOCK_TICKS, 0);
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.IRON_BLOCK.defaultBlockState();
    }

    @Override
    protected boolean hasOffensiveCapability() {
        // 狙击发射器会射出箭矢并锁定目标，具备攻击能力，保留索敌与仇恨。
        return true;
    }

    @Override
    protected LivingEntity findTarget() {
        return findTarget(ATTACK_RANGE, true);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (shotCooldown > 0) shotCooldown--;

        if (getLockTicks() > 0) {
            tickLaserLock();
            return;
        }

        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || distanceTo(target) > ATTACK_RANGE || !hasLineOfSight(target)) return;
        lookAt(target, 360.0f, 360.0f);
        if (shotCooldown <= 0) {
            performRangedAttack(target, 1.0f);
            playBowShot();
            shotCooldown = NORMAL_COOLDOWN;
        }
    }

    private void tickLaserLock() {
        Entity entity = level().getEntity(getLockTargetId());
        if (!(entity instanceof LivingEntity target) || !isValidLaserTarget(target)) {
            clearLaserLock();
            return;
        }

        lookAt(target, 360.0f, 360.0f);
        spawnBeamParticles(muzzlePosition(target), targetCenter(target), LOCK_PARTICLES);
        int remaining = getLockTicks() - 1;
        setLockTicks(remaining);
        if (remaining <= 0) {
            fireLaser(target);
            clearLaserLock();
        }
    }

    private boolean isValidLaserTarget(LivingEntity target) {
        return target.isAlive() && RebellionLogic.canMachineAttack(this, target)
                && distanceTo(target) <= ATTACK_RANGE && hasLineOfSight(target);
    }

    private Vec3 muzzlePosition(LivingEntity target) {
        Vec3 direction = targetCenter(target).subtract(new Vec3(getX(), getY() + MUZZLE_Y_OFFSET, getZ())).normalize();
        return new Vec3(getX(), getY() + MUZZLE_Y_OFFSET, getZ()).add(direction.scale(MUZZLE_FORWARD_OFFSET));
    }

    private static Vec3 targetCenter(LivingEntity target) {
        return new Vec3(target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ());
    }

    public void performRangedAttack(LivingEntity target, float velocity) {
        Vec3 start = muzzlePosition(target);
        Vec3 aim = targetCenter(target).subtract(start).normalize();
        MachineryArrow arrow = new MachineryArrow(level(), this);
        arrow.setPos(start);
        arrow.setBaseDamage(4.0);
        arrow.setHomingTarget(target);
        arrow.shoot(aim.x, aim.y, aim.z, ARROW_SPEED * Math.max(velocity, 0.1f), ARROW_INACCURACY);
        level().addFreshEntity(arrow);
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || getLockTicks() > 0) return;
        LivingEntity target = findTarget();
        if (target == null) return;
        startEvocationEffect();
        level().playSound(null, blockPosition(), GeneratedMod.SNIPER_EMITTER_LOCK.get(),
                SoundSource.BLOCKS, 1.0f, 1.0f);
        setLockTargetId(target.getId());
        setLockTicks(LASER_LOCK_TICKS);
    }

    private void fireLaser(LivingEntity lockedTarget) {
        Vec3 start = muzzlePosition(lockedTarget);
        Vec3 end = targetCenter(lockedTarget);
        Vec3 beam = end.subtract(start);
        double length = Math.min(ATTACK_RANGE, beam.length());
        if (length <= 0.01) return;
        Vec3 direction = beam.normalize();
        end = start.add(direction.scale(length));
        // 蓄力激光沿用狙击发射器原本的开火音效，不换成 Bow 采样。
        level().playSound(null, blockPosition(), GeneratedMod.SNIPER_EMITTER_FIRE.get(),
                SoundSource.BLOCKS, 1.0f, 1.0f);
        spawnBeamParticles(start, end, LASER_PARTICLES);
        AABB searchBox = getBoundingBox().expandTowards(direction.scale(length)).inflate(LASER_WIDTH * 0.5 + 0.25);
        for (LivingEntity entity : level().getEntitiesOfClass(LivingEntity.class, searchBox,
                candidate -> candidate != this && candidate.isAlive() && RebellionLogic.canMachineAttack(this, candidate))) {
            Vec3 center = targetCenter(entity);
            if (distanceToSegment(center, start, end) <= LASER_WIDTH * 0.5 + Math.max(entity.getBbWidth() * 0.5, 0.2)) {
                hurtIgnoringInvulnerability(entity, level().damageSources().fellOutOfWorld(), LASER_DAMAGE);
            }
        }
    }

    private void spawnBeamParticles(Vec3 start, Vec3 end, DustParticleOptions particle) {
        if (!(level() instanceof net.minecraft.server.level.ServerLevel serverLevel)) return;
        double length = start.distanceTo(end);
        int steps = Math.max(1, (int) Math.ceil(length * 5.0));
        for (int i = 0; i <= steps; i++) {
            Vec3 point = start.lerp(end, i / (double) steps);
            serverLevel.sendParticles(particle, point.x, point.y, point.z, 1,
                    0.0, 0.0, 0.0, 0.0);
        }
    }

    private void clearLaserLock() {
        setLockTargetId(-1);
        setLockTicks(0);
    }

    private void setLockTargetId(int id) {
        entityData.set(DATA_LOCK_TARGET_ID, id);
    }

    private void setLockTicks(int ticks) {
        entityData.set(DATA_LOCK_TICKS, Math.max(0, ticks));
    }

    private int getLockTargetId() {
        return entityData.get(DATA_LOCK_TARGET_ID);
    }

    public int getLockTicks() {
        return entityData.get(DATA_LOCK_TICKS);
    }

    public LivingEntity getLockTarget() {
        Entity target = level().getEntity(getLockTargetId());
        return target instanceof LivingEntity living ? living : null;
    }

    private static double distanceToSegment(Vec3 point, Vec3 start, Vec3 end) {
        Vec3 segment = end.subtract(start);
        double lengthSquared = segment.lengthSqr();
        if (lengthSquared <= 1.0E-7) return point.distanceTo(start);
        double projection = point.subtract(start).dot(segment) / lengthSquared;
        projection = Math.max(0.0, Math.min(1.0, projection));
        return point.distanceTo(start.add(segment.scale(projection)));
    }
}
