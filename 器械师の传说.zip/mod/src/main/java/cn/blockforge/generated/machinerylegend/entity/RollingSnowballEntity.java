package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.projectile.Snowball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** 器械被下界之星激发后发射的地面滚动雪球，射出后持续 20 秒并快速增大至 4 格高。 */
public class RollingSnowballEntity extends Snowball {
    private static final int MAX_LIFETIME_TICKS = 20 * 20;
    private static final int GROWTH_DURATION_TICKS = 5 * 20;
    private static final float BASE_DAMAGE = 5.0f;
    private static final float DAMAGE_STEP = 2.5f;
    private static final float START_SCALE = 0.28f;
    // ItemDisplayContext.GROUND 的基础雪球高度约为0.5格，8倍即为4格高。
    private static final float END_SCALE = 8.0f;
    private static final double MIN_HORIZONTAL_MOTION_SQR = 1.0E-7;
    // ItemDisplayContext.GROUND 中雪球基础高度约为 0.5 格，与渲染缩放保持一致。
    private static final float BASE_HITBOX_SIZE = 0.5f;
    private double forwardX;
    private double forwardZ;
    private double forwardSpeed;
    private boolean forwardMotionInitialized;
    private boolean blockedByWall;

    public RollingSnowballEntity(EntityType<RollingSnowballEntity> type, Level level) {
        super(type, level);
    }

    public RollingSnowballEntity(EntityType<RollingSnowballEntity> type, Entity owner, Level level) {
        this(type, level);
        setOwner(owner);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        float size = BASE_HITBOX_SIZE * getGrowthScale(0.0f);
        return EntityDimensions.scalable(size, size);
    }

    @Override
    public void tick() {
        // 不调用 ThrowableProjectile.tick：它会在方块命中后再次改写位置，导致雪球绕过墙体继续飞行。
        baseTick();
        refreshDimensions();
        if (isRemoved()) return;

        if (!forwardMotionInitialized) {
            Vec3 initialMotion = getDeltaMovement();
            double horizontalSpeedSqr = initialMotion.x * initialMotion.x + initialMotion.z * initialMotion.z;
            if (horizontalSpeedSqr > MIN_HORIZONTAL_MOTION_SQR) {
                double horizontalSpeed = Math.sqrt(horizontalSpeedSqr);
                forwardX = initialMotion.x / horizontalSpeed;
                forwardZ = initialMotion.z / horizontalSpeed;
                forwardSpeed = horizontalSpeed;
                forwardMotionInitialized = true;
            }
        }

        if (tickCount >= MAX_LIFETIME_TICKS) {
            discard();
            return;
        }
        if (!forwardMotionInitialized || blockedByWall) {
            setDeltaMovement(Vec3.ZERO);
            return;
        }

        Vec3 oldMotion = getDeltaMovement();
        double oldX = getX();
        double oldY = getY();
        double oldZ = getZ();
        boolean wasOnGround = onGround();
        Vec3 horizontalMotion = new Vec3(forwardX * forwardSpeed, 0.0, forwardZ * forwardSpeed);
        double verticalMotion = wasOnGround ? 0.0 : oldMotion.y - getGravity();
        AABB originalBox = getBoundingBox();

        setDeltaMovement(horizontalMotion.x, verticalMotion, horizontalMotion.z);
        move(MoverType.SELF, new Vec3(horizontalMotion.x, verticalMotion, horizontalMotion.z));

        double movedHorizontal = Math.sqrt(square(getX() - oldX) + square(getZ() - oldZ));
        boolean blocked = horizontalCollision
                || movedHorizontal < horizontalMotion.horizontalDistance() * 0.20;
        if (blocked && canStepOver(wasOnGround, horizontalMotion, originalBox)) {
            setPos(oldX, oldY + 1.0, oldZ);
            setOnGround(false);
            move(MoverType.SELF, horizontalMotion);
            if (horizontalCollision) {
                setPos(oldX, oldY, oldZ);
                blockedByWall = true;
                setDeltaMovement(Vec3.ZERO);
            } else {
                setDeltaMovement(horizontalMotion);
            }
        } else if (blocked) {
            setPos(oldX, oldY, oldZ);
            blockedByWall = true;
            setDeltaMovement(Vec3.ZERO);
        } else {
            if (verticalCollision) setOnGround(true);
            setDeltaMovement(horizontalMotion.x, getDeltaMovement().y, horizontalMotion.z);
        }

        if (!isRemoved() && !blockedByWall && tickCount % 10 == 0) {
            float damage = getDamage();
            Entity owner = getOwner();
            AABB contactBox = getBoundingBox().inflate(0.05);
            for (LivingEntity target : level().getEntitiesOfClass(LivingEntity.class, contactBox,
                    entity -> entity != owner && entity.isAlive() && RebellionLogic.canMachineProjectileHit(owner, entity)
                            && entity.getBoundingBox().intersects(contactBox))) {
                MachineryEntity.clearInvulnerabilityForMachineryAttack(target);
                target.hurt(level().damageSources().thrown(this, owner), damage);
            }
        }
    }

    private boolean canStepOver(boolean wasOnGround, Vec3 horizontalMotion, AABB originalBox) {
        if (!wasOnGround || horizontalMotion.horizontalDistanceSqr() <= MIN_HORIZONTAL_MOTION_SQR) return false;
        AABB liftedBox = originalBox.move(0.0, 1.0, 0.0);
        AABB liftedForwardBox = liftedBox.move(horizontalMotion.x, 0.0, horizontalMotion.z);
        return level().noCollision(this, liftedBox) && level().noCollision(this, liftedForwardBox);
    }

    private static double square(double value) {
        return value * value;
    }

    public float getDamage() {
        return BASE_DAMAGE + DAMAGE_STEP * (tickCount / 10);
    }

    public float getGrowthScale(float partialTick) {
        // 在前5秒完成成长，之后保持4格高，剩余生命周期与滚动逻辑不变。
        float progress = Math.max(0.0f, Math.min(1.0f,
                (tickCount + partialTick) / (float) GROWTH_DURATION_TICKS));
        float eased = progress * progress * (3.0f - 2.0f * progress);
        return START_SCALE + (END_SCALE - START_SCALE) * eased;
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return false;
    }

}
