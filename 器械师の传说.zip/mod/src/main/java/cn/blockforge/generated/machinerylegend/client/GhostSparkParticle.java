package cn.blockforge.generated.machinerylegend.client;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;

/**
 * 幽灵大腿处的白色粒子：外观同款原版烟花火箭火星。
 * <p>贴图直接复用原版 {@code minecraft:spark_0~7} 火星动画帧
 * （与原版 {@code FireworkParticles$SparkParticle} 即烟花火箭尾焰的白色粒子同一套素材，
 * 见 particles/ghost_spark.json），但物理保持上一轮的"匀速向下喷射"：</p>
 * <ul>
 *   <li>{@code friction = 1}：速度不衰减，向下初速保持到粒子消失；</li>
 *   <li>{@code gravity = 0}：不因重力越落越快、不变向；</li>
 *   <li>{@code hasPhysics = false}：穿过方块，不在腿下就地散开。</li>
 * </ul>
 * 尺寸取火星级 0.04~0.09 格（原自制烟团为 0.14~0.35 格，用户反馈太大），
 * 寿命 14~22 tick，透明度随存活时间线性淡出，逐帧播放 spark 动画。
 */
public final class GhostSparkParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final float startAlpha;

    private GhostSparkParticle(ClientLevel level, double x, double y, double z,
                               double xd, double yd, double zd, SpriteSet sprites) {
        super(level, x, y, z, xd, yd, zd);
        this.sprites = sprites;
        this.quadSize = this.random.nextFloat() * 0.05F + 0.04F;
        this.lifetime = 14 + this.random.nextInt(9);
        this.rCol = 1.0F;
        this.gCol = 1.0F;
        this.bCol = 1.0F;
        this.friction = 1.0F;
        this.gravity = 0.0F;
        this.hasPhysics = false;
        this.startAlpha = this.random.nextFloat() * 0.15F + 0.8F;
        this.alpha = this.startAlpha;
        this.setSpriteFromAge(sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        // 半透明层：alpha 淡出必须走 PARTICLE_SHEET_TRANSLUCENT 才生效
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public void tick() {
        super.tick();
        // 逐帧播放 spark_0~7 火星动画（与原版烟花火星一致）
        this.setSpriteFromAge(this.sprites);
        this.alpha = this.age >= this.lifetime ? 0.0F
                : this.startAlpha * (1.0F - (float) this.age / (float) this.lifetime);
    }

    /** 供 {@code RegisterParticleProvidersEvent#registerSpriteSet} 使用的工厂入口。 */
    public static GhostSparkParticle create(SpriteSet sprites, ClientLevel level,
                                            double x, double y, double z,
                                            double xd, double yd, double zd) {
        return new GhostSparkParticle(level, x, y, z, xd, yd, zd, sprites);
    }
}
