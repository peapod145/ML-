package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * 器械发射的箭：只允许命中敌对生物，并且不带弹道下坠——关掉重力后沿瞄准方向直线飞行，
 * 出膛速度仍沿用发射器/狙击各自的 {@code ARROW_SPEED}，只是不再随飞行距离向下掉。
 */
public class MachineryArrow extends Arrow {
    /** 发射器箭矢最多存在 5 秒，避免未命中的箭长期堆积在世界中。 */
    private static final int MAX_LIFETIME_TICKS = 5 * 20;
    private static final double HOMING_TURN_RATE = 0.30;
    private LivingEntity homingTarget;

    public MachineryArrow(Level level, LivingEntity owner) {
        super(level, owner, Items.ARROW.getDefaultInstance(), Items.BOW.getDefaultInstance());
        // 关闭重力：器械射出的箭按直线弹道飞行，不随距离下坠（速度不变）。
        setNoGravity(true);
    }

    public void setHomingTarget(LivingEntity target) {
        homingTarget = target;
    }

    @Override
    public void tick() {
        if (!level().isClientSide && homingTarget != null && homingTarget.isAlive()) {
            steerTowardTarget();
        }
        super.tick();
        if (!isRemoved() && tickCount >= MAX_LIFETIME_TICKS) {
            discard();
        }
    }

    /**
     * 被弹开的回调（盾牌格挡、旋风投射等任何 deflect 路径）：出膛时关闭的重力在反弹后立刻恢复，
     * 器械箭不再直线飞行，改回正常下坠。
     */
    @Override
    protected void onDeflection(Entity cause, boolean playSound) {
        super.onDeflection(cause, playSound);
        setNoGravity(false);
    }

    private void steerTowardTarget() {
        Vec3 motion = getDeltaMovement();
        double speed = motion.length();
        if (speed <= 1.0E-6) return;

        Vec3 targetCenter = homingTarget.position().add(0.0, homingTarget.getBbHeight() * 0.5, 0.0);
        Vec3 desiredDirection = targetCenter.subtract(position()).normalize();
        Vec3 currentDirection = motion.scale(1.0 / speed);
        Vec3 steeredDirection = currentDirection.scale(1.0 - HOMING_TURN_RATE)
                .add(desiredDirection.scale(HOMING_TURN_RATE)).normalize();
        setDeltaMovement(steeredDirection.scale(speed));
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return RebellionLogic.canMachineProjectileHit(getOwner(), entity) && super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(net.minecraft.world.phys.EntityHitResult result) {
        if (result.getEntity() instanceof LivingEntity target && RebellionLogic.canMachineProjectileHit(getOwner(), target)) {
            MachineryEntity.clearInvulnerabilityForMachineryAttack(target);
        }
        super.onHitEntity(result);
    }
}
