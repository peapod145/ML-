package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.player.EnergyData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

public class BlueprintItem extends Item {
    private final EntityType<? extends Mob> entityType;
    private final int redstoneCost;
    private final int energyCost;
    private final int cooldownTicks;
    /** 放置音效的懒解析供应器：模组自定义音效经 DeferredHolder 注册，播放时才取值。 */
    private final Supplier<SoundEvent> placeSound;

    public BlueprintItem(Properties properties, EntityType<? extends Mob> entityType, int redstoneCost, int energyCost, int cooldownTicks,
                         boolean playStonePlaceSound) {
        this(properties, entityType, redstoneCost, energyCost, cooldownTicks,
                playStonePlaceSound ? SoundEvents.STONE_PLACE : null);
    }

    public BlueprintItem(Properties properties, EntityType<? extends Mob> entityType, int redstoneCost, int energyCost, int cooldownTicks,
                         SoundEvent placeSound) {
        this(properties, entityType, redstoneCost, energyCost, cooldownTicks,
                placeSound == null ? null : (Supplier<SoundEvent>) () -> placeSound);
    }

    public BlueprintItem(Properties properties, EntityType<? extends Mob> entityType, int redstoneCost, int energyCost, int cooldownTicks,
                         Supplier<SoundEvent> placeSound) {
        super(properties.stacksTo(1));
        this.entityType = entityType;
        this.redstoneCost = redstoneCost;
        this.energyCost = energyCost;
        this.cooldownTicks = cooldownTicks;
        this.placeSound = placeSound;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.blueprint_cost", energyCost, redstoneCost)
                .withStyle(ChatFormatting.YELLOW));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        if (player == null || (!player.isCreative() && player.getCooldowns().isOnCooldown(this))) return InteractionResult.FAIL;
        // 常规器械蓝图只能从方块顶面放置。
        if (context.getClickedFace() != Direction.UP) return InteractionResult.FAIL;
        BlockPos spawnPos = context.getClickedPos().relative(Direction.UP);
        if (!level.getBlockState(spawnPos).isAir()) return InteractionResult.FAIL;
        if (!level.isClientSide && level instanceof ServerLevel serverLevel) {
            int effectiveEnergyCost = MechanicalArmItem.reducedEnergyCost(player, energyCost);
            int effectiveRedstoneCost = MechanicalArmItem.isEquipped(player) && energyCost >= 25
                    ? Math.max(redstoneCost, Math.max(1, (effectiveEnergyCost + 24) / 25))
                    : redstoneCost;
            if (!player.isCreative() && !EnergyData.consumeEnergyOrRedstone(player, effectiveRedstoneCost, effectiveEnergyCost)) {
                EnergyData.flashInsufficient(player, "message.machinery_legend.insufficient_energy");
                return InteractionResult.FAIL;
            }
            Mob entity = entityType.create(serverLevel);
            if (entity == null) return InteractionResult.FAIL;
            entity.moveTo(spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, player.getYRot(), 0);
            entity.setPersistenceRequired();
            serverLevel.addFreshEntity(entity);
            if (placeSound != null) {
                SoundEvent sound = placeSound.get();
                if (sound != null) {
                    serverLevel.playSound(null, spawnPos, sound, SoundSource.BLOCKS, 1.0f, 1.0f);
                }
            }
            if (!player.isCreative()) player.getCooldowns().addCooldown(this, cooldownTicks);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
