package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.StarShardCarrierEffect;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.monster.Enemy;

import java.util.List;

/**
 * 怪物携带星之碎片的统一规则：
 * <ul>
 *   <li>可携带者 = 原版的僵尸/骷髅/蜘蛛家族、苦力怕、末影人；以及本模组（含以后新增）
 *       注册为 MONSTER 分类的怪物；</li>
 *   <li>生成时按 {@link #CARRY_CHANCE} 概率抽中，抽中后由 {@link #applyCarrier} 叠上绿色效果；</li>
 *   <li>击杀时由 GameEvents 掉出星之碎片，掉落物持续高亮 {@link #DROP_LIFETIME_TICKS} 刻后消失。</li>
 * </ul>
 */
public final class StarShardCarrier {
    public static final String CARRIER_KEY = "machinery_legend_star_shard_carrier";
    public static final String PENDING_KEY = "machinery_legend_star_shard_pending";
    public static final String DROP_KEY = "machinery_legend_star_shard_drop";
    /** 携带概率：5%。 */
    public static final float CARRY_CHANCE = 0.05f;
    /** 星之碎片掉落物存在时间：15 秒。 */
    public static final int DROP_LIFETIME_TICKS = 15 * 20;

    private StarShardCarrier() {}

    /** 该实体是否属于“生成时可能携带星之碎片”的怪物。 */
    public static boolean canCarry(Entity entity) {
        if (!(entity instanceof Mob)) return false;
        EntityType<?> type = entity.getType();

        // 本模组以后新增的怪物会自动纳入：只要注册为 MONSTER 分类。
        ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(type);
        if (id != null && GeneratedMod.MOD_ID.equals(id.getNamespace())
                && type.getCategory() == MobCategory.MONSTER) {
            return true;
        }

        if (!(entity instanceof Enemy)) return false;
        return type == EntityType.ZOMBIE || type == EntityType.HUSK || type == EntityType.DROWNED
                || type == EntityType.ZOMBIE_VILLAGER
                || type == EntityType.SKELETON || type == EntityType.STRAY || type == EntityType.BOGGED
                || type == EntityType.WITHER_SKELETON
                || type == EntityType.SPIDER || type == EntityType.CAVE_SPIDER
                || type == EntityType.CREEPER || type == EntityType.ENDERMAN;
    }

    public static boolean isCarrier(LivingEntity entity) {
        // 1) 同步附件：客户端唯一可靠、且对玩家/怪物都成立的判据（见下方说明）。
        // 2) 持久化标记 / 绿色效果：服务端权威判据，掉落逻辑与老存档兜底用。
        if (entity.getData(GeneratedMod.STAR_SHARD_CARRIER_FLAG)) return true;
        return entity.getPersistentData().getBoolean(CARRIER_KEY)
                || hasCarrierEffect(entity);
    }

    /**
     * 判断实体身上是否带有“星之碎片携带者”效果。
     *
     * <p><strong>只在服务端（以及“玩家自己的”效果）成立。</strong>
     * 从 1.21 起，非玩家实体的药水效果<strong>不会</strong>再同步给其他客户端：
     * {@code LivingEntity} 只把效果的粒子颜色写进 {@code DATA_EFFECT_PARTICLES} 这个同步实体数据，
     * {@code ClientboundUpdateMobEffectPacket} 只会发给玩家本人（{@code ServerPlayer}）
     * 以及骑在生物身上的玩家（{@code sendEffectToPassengers}）。
     * 因此客户端上怪物的 {@code getActiveEffects()} 是<strong>空的</strong>——
     * 这正是“玩家有绿光、怪物只有绿色药水粒子”的根因：
     * 粒子来自同步的粒子颜色，而效果判定恒为 false。</p>
     *
     * <p>绿光渲染因此改用 {@link GeneratedMod#STAR_SHARD_CARRIER_FLAG} 这个可同步数据附件，
     * 这里保留效果判定只作为服务端的权威依据与玩家自己拥有效果时的兼容路径。</p>
     */
    public static boolean hasCarrierEffect(LivingEntity entity) {
        for (MobEffectInstance instance : entity.getActiveEffects()) {
            if (instance.getEffect().value() instanceof StarShardCarrierEffect) return true;
        }
        return false;
    }

    /** 抽中后在生成阶段先打标记，等实体真正进入世界再上效果。 */
    public static void markPending(Mob mob) {
        mob.getPersistentData().putBoolean(PENDING_KEY, true);
    }

    /**
     * 把“携带者”标记同步给能看到这只怪的客户端。
     * 服务端 {@code setData} 会立即推送给正在追踪该实体的玩家；玩家之后才开始追踪时，
     * NeoForge 会在开始追踪的那一刻补发初始值，所以老存档里已有的携带者也能正常发绿光。
     */
    public static void syncCarrierFlag(Mob mob) {
        if (mob.level().isClientSide()) return;
        if (!mob.getData(GeneratedMod.STAR_SHARD_CARRIER_FLAG)) {
            mob.setData(GeneratedMod.STAR_SHARD_CARRIER_FLAG, Boolean.TRUE);
        }
    }

    /** 正式标记为携带者，并叠上永久效果作为服务端权威标识（效果本身不发粒子）。 */
    public static void applyCarrier(Mob mob) {
        mob.getPersistentData().remove(PENDING_KEY);
        mob.getPersistentData().putBoolean(CARRIER_KEY, true);
        hideCarrierParticles(mob);
        if (!hasCarrierEffect(mob)) {
            mob.addEffect(createHiddenCarrierEffect());
        }
        syncCarrierFlag(mob);
    }

    /** 携带者标识效果：永久、不显示粒子、仅保留图标位。 */
    public static MobEffectInstance createHiddenCarrierEffect() {
        // 参数依次为 (效果, 时长, 等级, ambient, visible, showIcon)：
        // visible=false → MobEffectInstance#getParticleOptions() 返回 null →
        // LivingEntity#updateSynchronizedMobEffectParticles() 同步给客户端的粒子列表为空，
        // 客户端自然不会再冒出绿色药水粒子。“发绿光”完全交给渲染层的绿光层负责。
        return new MobEffectInstance(GeneratedMod.STAR_SHARD_CARRIER,
                MobEffectInstance.INFINITE_DURATION, 0, false, false, true);
    }

    /**
     * 把已存在的“携带者”效果换成不发粒子的版本。
     *
     * <p>{@code MobEffectInstance#visible} 没有 setter，而且老存档里效果是按
     * {@code ShowParticles:1b} 存下来的，读档后仍是可见状态；所以这里在服务端把可见实例
     * 移除后重新加一个隐藏实例。效果只是标识，移除再添加没有副作用。</p>
     */
    public static void hideCarrierParticles(LivingEntity entity) {
        for (MobEffectInstance instance : List.copyOf(entity.getActiveEffects())) {
            if (instance.isVisible()
                    && instance.getEffect().value() instanceof StarShardCarrierEffect) {
                entity.removeEffect(instance.getEffect());
                entity.addEffect(createHiddenCarrierEffect());
            }
        }
    }
}
