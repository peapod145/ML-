package cn.blockforge.generated.machinerylegend.network;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.client.ClientEnergy;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

public record EnergySyncPayload(int energy, int flashTicks) implements CustomPacketPayload {
    public static final Type<EnergySyncPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "energy_sync"));
    public static final StreamCodec<io.netty.buffer.ByteBuf, EnergySyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, EnergySyncPayload::energy,
            ByteBufCodecs.VAR_INT, EnergySyncPayload::flashTicks,
            EnergySyncPayload::new);

    @Override
    public Type<EnergySyncPayload> type() { return TYPE; }

    public static void handle(EnergySyncPayload payload, net.neoforged.neoforge.network.handling.IPayloadContext context) {
        context.enqueueWork(() -> ClientEnergy.set(payload.energy(), payload.flashTicks()));
    }
}
