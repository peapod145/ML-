package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.ProjectileDeflection;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;

/**
 * 飞刀投掷实体：玩家投掷的飞刀飞行物理完全沿用箭矢（重力、插地、消亡）；
 * 飞刀发射器射出的飞刀在此基础上关闭重力，沿瞄准方向直线飞行、不带弹道下坠（出膛速度不变），
 * 但一旦被弹开（{@link #onDeflection}，如盾牌格挡、旋风投射等任何 deflect 路径）立刻恢复重力，
 * 反弹后的飞刀不再直线飞行，改为正常下坠直至落地；玩家投掷的飞刀本身就有重力，该回调对它无影响。
 * 命中生物：基础 2 点伤害；若目标护甲值低于 4，则改为 4 点伤害并穿透该目标
 * （同原版弩"穿透"附魔的穿体效果），穿透命中时播放用户提供的挥斩音效（knife_slice，
 * 两条素材随机取其一）；若目标为亡灵生物（#minecraft:undead）额外 +2 点伤害；
 * 若目标为狼人（WerewolfEntity）再额外 +2 点伤害。
 * 常规器械生物（{@link MachineryEntity} 及其子类：发射器、飞刀发射器、熔炉等）
 * 一律无法被穿透：伤害仍按护甲规则结算，但飞刀命中即停留回收，不穿体、不播挥斩音效。
 * 蓄力只影响投掷距离，不影响这里的伤害。
 * 飞刀发射器激发潜能的飞刀圈会调用 {@link #setIgnoresInvulnerability}，命中前清掉目标无敌帧，
 * 使圈上的每把飞刀都能各自结算伤害。
 * 飞刀发射器射出的普通飞刀与飞刀圈的飞刀都会调用 {@link #setOnlyHitsHostile}：器械生物的攻击
 * 飞行途中只与敌对生物（{@code Enemy}）结算命中，径直穿过其他器械生物、玩家与中立/友好生物，
 * 不会被友军挡下（常规射击与飞刀圈通用）。玩家自己投掷的飞刀不设置该开关，保持可命中一切生物。
 */
public class ThrowingKnifeEntity extends Arrow {
    /** 已穿透过的实体，不再重复命中（对应箭矢的 piercingIgnoreEntityIds）。 */
    private IntOpenHashSet piercedEntities;
    /** 伤害倍率：默认为 1.0（飞刀圈的飞刀已取消双倍伤害，不再设置该倍率）。 */
    private float damageMultiplier = 1.0F;
    /** ≥0 时为剩余存活 tick 数，倒计时结束即消失（器械射出的飞刀 15 秒后消失）；-1 表示不额外限时。 */
    private int expireTicks = -1;
    /** 命中结算时是否无视目标的无敌帧（伤害冷却）；飞刀圈射出的飞刀为 true。 */
    private boolean ignoresInvulnerability;
    /** 是否只与敌对生物结算命中；飞刀圈射出的飞刀为 true。 */
    private boolean onlyHitsHostile;

    public ThrowingKnifeEntity(EntityType<? extends ThrowingKnifeEntity> type, Level level) {
        super(type, level);
    }

    public void setDamageMultiplier(float value) {
        this.damageMultiplier = value;
    }

    public void setIgnoresInvulnerability(boolean value) {
        this.ignoresInvulnerability = value;
    }

    public void setOnlyHitsHostile(boolean value) {
        this.onlyHitsHostile = value;
    }

    public void setExpireTicks(int ticks) {
        this.expireTicks = ticks;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && this.expireTicks > 0 && --this.expireTicks == 0) {
            this.discard();
        }
    }

    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.damageMultiplier != 1.0F) {
            tag.putFloat("KnifeDamageMultiplier", this.damageMultiplier);
        }
        if (this.expireTicks >= 0) {
            tag.putInt("KnifeExpireTicks", this.expireTicks);
        }
        if (this.ignoresInvulnerability) {
            tag.putByte("KnifeIgnoresInvulnerability", (byte) 1);
        }
        if (this.onlyHitsHostile) {
            tag.putByte("KnifeOnlyHitsHostile", (byte) 1);
        }
    }

    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("KnifeDamageMultiplier")) {
            this.damageMultiplier = tag.getFloat("KnifeDamageMultiplier");
        }
        if (tag.contains("KnifeExpireTicks")) {
            this.expireTicks = tag.getInt("KnifeExpireTicks");
        }
        this.ignoresInvulnerability = tag.getByte("KnifeIgnoresInvulnerability") != 0;
        this.onlyHitsHostile = tag.getByte("KnifeOnlyHitsHostile") != 0;
    }

    @Override
    protected ItemStack getDefaultPickupItem() {
        return new ItemStack(GeneratedMod.THROWING_KNIFE.get());
    }

    /**
     * 飞刀被弹开的回调（原版 {@link net.minecraft.world.entity.projectile.Projectile#deflect} 内部调用）：
     * 无论来自盾牌格挡还是其他反弹来源，反弹之后一律恢复重力。飞刀发射器出膛时关闭的重力只保证
     * 命中前的直线弹道，一旦飞刀被弹开就回到正常下坠；玩家投掷的飞刀本来就有重力，这里等价于空操作。
     */
    @Override
    protected void onDeflection(Entity cause, boolean playSound) {
        super.onDeflection(cause, playSound);
        this.setNoGravity(false);
    }

    @Override
    protected boolean canHitEntity(Entity target) {
        // 飞刀圈的飞刀只结算敌对生物：玩家、中立与友好生物、展示框等都直接穿过。
        if (this.onlyHitsHostile && !RebellionLogic.canMachineProjectileHit(getOwner(), target)) {
            return false;
        }
        return super.canHitEntity(target)
                && (this.piercedEntities == null || !this.piercedEntities.contains(target.getId()));
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        if (this.level().isClientSide) {
            // 客户端不结算伤害，服务端判定后同步移除。
            return;
        }
        Entity owner = this.getOwner();
        DamageSource source = this.damageSources().arrow(this, owner != null ? owner : this);
        if (!(target instanceof LivingEntity living)) {
            // 非生物目标（展示框、矿车等）：按基础 2 点伤害结算并回收飞刀。
            if (this.ignoresInvulnerability) {
                target.invulnerableTime = 0;
            }
            target.hurt(source, 2.0F * this.damageMultiplier);
            this.playSound(SoundEvents.TRIDENT_HIT, 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
            this.discard();
            return;
        }
        float armor = (float) living.getArmorValue();
        // 常规器械生物（MachineryEntity 及其子类）一律无法被飞刀穿透：
        // 伤害仍按护甲规则结算，但飞刀命中即停留回收（播普通三叉戟命中声，不播挥斩音效）。
        boolean pierce = armor < 4.0F && !(living instanceof MachineryEntity);
        float damage = armor < 4.0F ? 4.0F : 2.0F;
        if (living.getType().is(EntityTypeTags.UNDEAD)) {
            damage += 2.0F;
        }
        if (living instanceof WerewolfEntity) {
            // 狼人弱点：飞刀（玩家投掷与飞刀圈通用）攻击时额外 +2 伤害
            damage += 2.0F;
        }
        damage *= this.damageMultiplier;
        int fireTicks = target.getRemainingFireTicks();
        if (this.ignoresInvulnerability) {
            // 飞刀圈的飞刀无视无敌帧：命中前清掉目标当前伤害冷却，逐把都能结算。
            target.invulnerableTime = 0;
        }
        if (target.hurt(source, damage)) {
            if (owner instanceof LivingEntity shooter) {
                shooter.setLastHurtMob(target);
            }
            if (owner instanceof ServerPlayer serverPlayer && target instanceof Player) {
                serverPlayer.connection.send(new net.minecraft.network.protocol.game.ClientboundGameEventPacket(
                        net.minecraft.network.protocol.game.ClientboundGameEventPacket.ARROW_HIT_PLAYER, 0.0F));
            }
            if (pierce) {
                // 目标可被穿透：击中时播放用户提供的挥斩音效（两条素材随机取其一），不播普通命中的三叉戟声。
                this.playSound(GeneratedMod.KNIFE_SLICE.get(), 1.0F, 1.0F);
                if (this.piercedEntities == null) {
                    this.piercedEntities = new IntOpenHashSet(5);
                }
                this.piercedEntities.add(target.getId());
                // 不 discard：飞刀穿过该生物继续飞行，同"穿透"附魔。
            } else {
                this.playSound(SoundEvents.TRIDENT_HIT, 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
                this.discard();
            }
        } else {
            // 被格挡等情形：与原版箭矢一致地反弹并减速，同时恢复重力（发射器的飞刀出膛时关了重力，
            // 反弹后不再保持直线，按正常下坠落向地面；本就有重力的玩家飞刀此处等价于空操作）。
            target.setRemainingFireTicks(fireTicks);
            this.deflect(ProjectileDeflection.REVERSE, target, owner, false);
            this.setNoGravity(false);
            this.setDeltaMovement(this.getDeltaMovement().scale(0.2));
            if (this.getDeltaMovement().lengthSqr() < 1.0E-7) {
                this.discard();
            }
        }
    }
}
