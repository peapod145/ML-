package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.WerewolfEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.WolfModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.util.Mth;

/**
 * 狼人狼形态模型：逐部件复刻原版 WolfModel（网格定义直接调用
 * {@link WolfModel#createMeshDefinition(CubeDeformation)}，保证与原版狼像素级一致），
 * 并锁定"愤怒"姿态：尾巴竖直上翘（原版 Wolf#getTailAngle() 愤怒值 1.5393804）、
 * 尾摆归零（愤怒时 tail.yRot=0），不会出现坐姿/摇尾等 tame 分支。
 * 1.21.1 的 WolfModel 泛型上界是 Wolf，狼人（Monster 子类）无法直接复用其实例，
 * 因此单独实现一个 EntityModel&lt;WerewolfEntity&gt;。
 */
public final class WerewolfWolfModel extends EntityModel<WerewolfEntity> {
    /** 原版愤怒狼的尾巴角度（Wolf#getTailAngle 的 isAngry 分支常量）。 */
    private static final float ANGRY_TAIL_X_ROT = 1.5393804F;
    private final ModelPart head;
    private final ModelPart realHead;
    private final ModelPart body;
    private final ModelPart upperBody;
    private final ModelPart rightHindLeg;
    private final ModelPart leftHindLeg;
    private final ModelPart rightFrontLeg;
    private final ModelPart leftFrontLeg;
    private final ModelPart tail;
    private final ModelPart realTail;

    public WerewolfWolfModel(ModelPart root) {
        this.head = root.getChild("head");
        this.realHead = this.head.getChild("real_head");
        this.body = root.getChild("body");
        this.upperBody = root.getChild("upper_body");
        this.rightHindLeg = root.getChild("right_hind_leg");
        this.leftHindLeg = root.getChild("left_hind_leg");
        this.rightFrontLeg = root.getChild("right_front_leg");
        this.leftFrontLeg = root.getChild("left_front_leg");
        this.tail = root.getChild("tail");
        this.realTail = this.tail.getChild("real_tail");
    }

    /** 层定义直接复用原版狼网格（狼贴图为 64×32）。 */
    public static LayerDefinition createBodyLayer() {
        return LayerDefinition.create(WolfModel.createMeshDefinition(new CubeDeformation(0.0F)), 64, 32);
    }

    /** 站立/行走分支的部件位置与四腿摆动，取自原版 WolfModel#prepareMobModel（非坐姿分支）。 */
    @Override
    public void prepareMobModel(WerewolfEntity entity, float limbSwing, float limbSwingAmount, float partialTick) {
        this.tail.yRot = 0.0F; // 愤怒时不左右摆尾
        this.body.setPos(0.0F, 14.0F, 2.0F);
        this.body.xRot = (float) (Math.PI / 2);
        this.upperBody.setPos(-1.0F, 14.0F, -3.0F);
        this.upperBody.xRot = this.body.xRot;
        this.tail.setPos(-1.0F, 12.0F, 8.0F);
        this.rightHindLeg.setPos(-2.5F, 16.0F, 7.0F);
        this.leftHindLeg.setPos(0.5F, 16.0F, 7.0F);
        this.rightFrontLeg.setPos(-2.5F, 16.0F, -4.0F);
        this.leftFrontLeg.setPos(0.5F, 16.0F, -4.0F);
        this.rightHindLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.leftHindLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
        this.rightFrontLeg.xRot = Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
        this.leftFrontLeg.xRot = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        // 原版这几个 zRot 是狼"甩水抖身/歪头"动画（Wolf#getHeadRollAngle 等），狼人不参与，归零
        this.realHead.zRot = 0.0F;
        this.upperBody.zRot = 0.0F;
        this.body.zRot = 0.0F;
        this.realTail.zRot = 0.0F;
    }

    @Override
    public void setupAnim(WerewolfEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        this.head.xRot = headPitch * (float) (Math.PI / 180.0);
        this.head.yRot = netHeadYaw * (float) (Math.PI / 180.0);
        // 原版由 WolfRenderer#getBob 传入尾角，这里直接钉死为愤怒值
        this.tail.xRot = ANGRY_TAIL_X_ROT;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer,
                               int packedLight, int packedOverlay, int color) {
        this.head.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
        this.body.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
        this.upperBody.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
        this.rightHindLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
        this.leftHindLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
        this.rightFrontLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
        this.leftFrontLeg.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
        this.tail.render(poseStack, vertexConsumer, packedLight, packedOverlay, color);
    }
}
