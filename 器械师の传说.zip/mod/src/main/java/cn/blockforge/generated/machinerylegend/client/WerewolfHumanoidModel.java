package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.WerewolfEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * 狼人人形态模型：按用户上传的 models/werewolf_humanoid.bbmodel 逐立方体复刻
 * （玩家骨架 + 狼吻部/鼻/双耳），配套贴图为同一文件内嵌的 64×64 贴图，
 * 已由 tools/make_werewolf_humanoid_tex.py 重排成 Java 标准十字 UV 布局。
 * <p>骨骼为僵尸/人形惯例（脚在 y=24）：head/body 偏移 (0,0,0)，腿 (±2,12,0)；
 * 口鼻、鼻、耳挂在 head 之下随头转动。手臂采用与原版玩家 PlayerModel 完全相同的
 * 肩关节：右键偏移 (-5,2,0)、立方体 addBox(-3,-2,-2,4,12,4)，左键偏移 (5,2,0)、
 * 立方体 addBox(-1,-2,-2,4,12,4)。两者换算到世界坐标后手臂都落在 x ±4..±8、
 * y 0..12，即手臂内侧面与 8 宽躯干的侧面严丝合缝、外沿与玩家一致，摆臂轴心也在
 * 同一肩点。动画完全继承 {@link HumanoidModel}（行走摆臂摆腿、攻击挥砍抬手、头跟随），
 * 与 PlayerModel 的表现一致。bbmodel 的 armL/legL（x 0..8 一侧）对应
 * right_arm/right_leg，与原版皮肤左右映射相同。</p>
 */
public final class WerewolfHumanoidModel extends HumanoidModel<WerewolfEntity> {

    public WerewolfHumanoidModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // 头 8x8x8 @ (0,0,0)；口鼻/鼻/耳为头之子部件（bbmodel: muzzle/nose/earR/earL）
        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0)
                        .addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        head.addOrReplaceChild("muzzle",
                CubeListBuilder.create().texOffs(0, 32)
                        .addBox(-2.0F, -3.5F, -7.0F, 4.0F, 3.0F, 3.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        // 鼻：bbmodel 深 0.5（z -7.5..-7），这里取整像素深 1（z -7.5..-6.5），后半埋入口鼻内不可见
        head.addOrReplaceChild("nose",
                CubeListBuilder.create().texOffs(16, 32)
                        .addBox(-1.0F, -3.5F, -7.5F, 2.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition earR = head.addOrReplaceChild("ear_r", CubeListBuilder.create(),
                PartPose.offset(-2.0F, -8.0F, -1.0F));
        earR.addOrReplaceChild("ear_r_2",
                CubeListBuilder.create().texOffs(24, 32)
                        .addBox(-2.0F, -1.0F, -3.0F, 2.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        earR.addOrReplaceChild("ear_r_3",
                CubeListBuilder.create().texOffs(32, 32)
                        .addBox(-2.0F, -2.0F, -3.0F, 1.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        PartDefinition earL = head.addOrReplaceChild("ear_l", CubeListBuilder.create(),
                PartPose.offset(2.0F, -8.0F, -1.0F));
        earL.addOrReplaceChild("ear_l_2",
                CubeListBuilder.create().texOffs(40, 32)
                        .addBox(0.0F, -1.0F, -3.0F, 2.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        earL.addOrReplaceChild("ear_l_3",
                CubeListBuilder.create().texOffs(48, 32)
                        .addBox(1.0F, -2.0F, -3.0F, 1.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        root.addOrReplaceChild("hat", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(32, 16)
                        .addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));
        // 手臂：与原版玩家 PlayerModel（经典/Steve）逐值一致 —— 肩关节点 (±5,2,0)，
        // 立方体右 (-3,-2,-2,4,12,4) / 左 (-1,-2,-2,4,12,4)，世界坐标同为 x ±4..±8、y 0..12，
        // 即内侧贴紧躯干侧面（齐平），外沿与玩家一致；贴图锚点沿用本模型自定义布局。
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(32, 0)
                        .addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(48, 0)
                        .addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16)
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-2.0F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(16, 16)
                        .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(2.0F, 12.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }
}
