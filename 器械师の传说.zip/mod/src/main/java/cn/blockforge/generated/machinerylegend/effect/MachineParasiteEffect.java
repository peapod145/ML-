package cn.blockforge.generated.machinerylegend.effect;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.ParasiteBotEntity;
import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * 机器寄染：被寄生机器人命中的敌对生物获得的状态，持续 30 秒。
 * 携带者每 1.5 秒向自身半径 10 格内的怪物发射一枚寄生机器人，这些机器人造成的伤害与附加的
 * 机器寄染和传染发射器射出的完全一致（含无视目标无敌帧的命中结算，见
 * {@link ParasiteBotEntity}），因此寄染会在敌群中自行扩散。
 */
public class MachineParasiteEffect extends MobEffect {
    /** 状态颜色：寄生组织的紫红色。 */
    public static final int COLOR = 0xB23BD6;
    /** 携带者向周围敌人开火的半径（格）。 */
    private static final double FIRE_RANGE = 10.0;
    /** 两次开火之间的间隔（tick）：1.5 秒 = 30 刻，与传染发射器完全一致。 */
    private static final int FIRE_INTERVAL_TICKS = 30;
    /** 与传染发射器一致的弹速。 */
    private static final float BOT_SPEED = 0.72f;

    public MachineParasiteEffect() {
        super(MobEffectCategory.HARMFUL, COLOR,
                new DustParticleOptions(new Vector3f(0.70f, 0.23f, 0.84f), 1.0f));
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        return duration % FIRE_INTERVAL_TICKS == 0;
    }

    @Override
    public boolean applyEffectTick(LivingEntity entity, int amplifier) {
        if (entity.level() instanceof ServerLevel serverLevel) {
            LivingEntity target = amplifier >= 1 ? findNearestRebelTarget(serverLevel, entity)
                    : findNearestMonster(serverLevel, entity);
            if (target != null) fireBot(serverLevel, entity, target, amplifier >= 1);
        }
        return true;
    }

    private static LivingEntity findNearestRebelTarget(ServerLevel level, LivingEntity carrier) {
        LivingEntity nearest = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class,
                carrier.getBoundingBox().inflate(FIRE_RANGE),
                entity -> entity != carrier && entity.isAlive() && RebellionLogic.canRebelParasiteTarget(carrier, entity))) {
            double distance = carrier.distanceToSqr(candidate);
            if (distance < best) {
                best = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    private static LivingEntity findNearestMonster(ServerLevel level, LivingEntity carrier) {
        LivingEntity nearest = null;
        double best = Double.MAX_VALUE;
        for (LivingEntity candidate : level.getEntitiesOfClass(LivingEntity.class,
                carrier.getBoundingBox().inflate(FIRE_RANGE),
                // 正常寄生机器人不打反逆怪物：反逆者已被对立阵营当成队友，命中判定也会放过它，这里避免空放。
                entity -> entity != carrier && entity.isAlive() && entity instanceof Enemy
                        && !RebellionLogic.isRebel(entity)
                        && carrier.distanceToSqr(entity) <= FIRE_RANGE * FIRE_RANGE)) {
            double distance = carrier.distanceToSqr(candidate);
            if (distance < best) {
                best = distance;
                nearest = candidate;
            }
        }
        return nearest;
    }

    /** 从携带者胸口朝目标射出一枚寄生机器人；命中判定与附加状态由弹射物本身完成。 */
    private static void fireBot(ServerLevel level, LivingEntity carrier, LivingEntity target, boolean rebel) {
        Vec3 start = new Vec3(carrier.getX(), carrier.getY() + carrier.getBbHeight() * 0.5, carrier.getZ());
        Vec3 delta = new Vec3(target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ()).subtract(start);
        // 寄生机器人已关闭重力直线飞行，直接瞄准目标身体中心发射，无需再抬高补偿下坠。
        Vec3 aim = delta.normalize();
        ParasiteBotEntity bot = new ParasiteBotEntity(GeneratedMod.PARASITE_BOT.get(), carrier, level);
        bot.setRebelOrigin(rebel);
        bot.setPos(start);
        bot.shoot(aim.x, aim.y, aim.z, BOT_SPEED, 0.0f);
        level.addFreshEntity(bot);
        // 与传染发射器一致：携带者射出寄生机器人时也播放 Bow 采样。
        level.playSound(null, carrier.getX(), carrier.getY() + carrier.getBbHeight() * 0.5, carrier.getZ(),
                GeneratedMod.BOW_SHOT.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
    }
}
