package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.SmallEmitterSnowballEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** 始终朝向玩家渲染的小型发射器普通雪球。 */
public class SmallEmitterSnowballRenderer extends EntityRenderer<SmallEmitterSnowballEntity> {
    private static final ItemStack SNOWBALL_STACK = new ItemStack(Items.SNOWBALL);
    private static final ResourceLocation BLOCK_ATLAS = ResourceLocation.withDefaultNamespace("textures/atlas/blocks.png");
    private final ItemRenderer itemRenderer;

    public SmallEmitterSnowballRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.itemRenderer = context.getItemRenderer();
        this.shadowRadius = 0.05f;
    }

    @Override
    public void render(SmallEmitterSnowballEntity entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
        itemRenderer.renderStatic(SNOWBALL_STACK, ItemDisplayContext.GROUND,
                light, 0, poseStack, buffer, entity.level(), entity.getId());
        poseStack.popPose();
        super.render(entity, yaw, partialTick, poseStack, buffer, light);
    }

    @Override
    public ResourceLocation getTextureLocation(SmallEmitterSnowballEntity entity) {
        return BLOCK_ATLAS;
    }
}
