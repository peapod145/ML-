package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.common.Tags;

/**
 * 石像鬼：血量 60 的地下/沼泽夜行敌对生物。
 * <ul>
 *   <li>只在 Y&lt;40 的地下（地表以下）或夜间沼泽地表生成，生成权重 16（见 biome modifier JSON）；</li>
 *   <li>白天不燃烧：直接继承 Monster，不含 Zombie 的日晒点燃逻辑，无任何燃烧判定；</li>
 *   <li>进入水中与铁傀儡一致：默认 canSwim=false 会沉底，且 decreaseAirSupply 原样返回、永不耗氧窒息；</li>
 *   <li>受击不再有渐进裂纹叠加，改为按血量整张换贴图：血量 &gt;40 用基础贴图，20 &lt; 血量 ≤40 用中损贴图，血量 ≤20 用重损贴图（见 getDamageStage）；</li>
 *   <li>死亡不再产生白烟粒子，改为迸出稍多的石头方块被破坏粒子（见 die()）；死亡动画期间也不再渲染倒下的躯体（见 GargoyleRenderer）；</li>
 *   <li>受击音效为两条石头素材随机切换，死亡音效为专用素材；</li>
 *   <li>受到镐类工具攻击时，镐子自身伤害 ×2（增益/附魔部分不重复放大，非镐类与原版完全一致）；</li>
 *   <li>攻击力随难度变化：简单 4、普通 6、困难 8（服务端逐 tick 刷新 ATTACK_DAMAGE 基础值）；</li>
 *   <li>击退抗性 500%（属性 5.0；原版公式为 1-抗性 会出现负系数，故 knockback() 内按完全免疫处理）。</li>
 * </ul>
 */
public final class GargoyleEntity extends Monster {
    /** 换贴图的两侧血量阈值：血量 &gt;40 档 0，20 &lt; 血量 ≤40 档 1，血量 ≤20 档 2。 */
    private static final float TEXTURE_HEALTH_HIGH = 40.0F;
    private static final float TEXTURE_HEALTH_LOW = 20.0F;

    /** 死亡碎石粒子只生成一次的标记（与器械生物同一做法）。 */
    private boolean deathParticlesSpawned = false;

    public GargoyleEntity(EntityType<? extends GargoyleEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 60.0)
                // 普通难度基线；实际结算值由 tick() 按当前难度刷为 4/6/8
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.24)
                .add(Attributes.FOLLOW_RANGE, 35.0)
                // 护甲 5 点
                .add(Attributes.ARMOR, 5.0)
                // 击退抗性 500%：属性值记录为 5.0（见 knockback() 的生效方式说明）
                .add(Attributes.KNOCKBACK_RESISTANCE, 5.0);
    }

    /**
     * 生成规则：
     * <ul>
     *   <li>地表以下（位置低于 MOTION_BLOCKING_NO_LEAVES 高度图，树冠不视为“地下”）：仅允许 Y&lt;40 的地下，
     *       并沿用原版怪物生成条件（暗度、可站立的方块等）；</li>
     *   <li>地表（位置不低于高度图）：仅允许沼泽生物群系 + 夜间（白天 isDay 为 true 直接排除）。</li>
     * </ul>
     */
    public static boolean checkGargoyleSpawnRules(EntityType<GargoyleEntity> type, ServerLevelAccessor level,
                                                  MobSpawnType spawnType, BlockPos pos,
                                                  RandomSource random) {
        int surfaceY = level.getLevel().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, pos.getX(), pos.getZ());
        if (pos.getY() < surfaceY) {
            // 地下：Y 小于 40 才允许
            return pos.getY() < 40 && Monster.checkMonsterSpawnRules(type, level, spawnType, pos, random);
        }
        // 地表：只在夜间的沼泽
        return !level.getLevel().isDay()
                && level.getBiome(pos).is(Tags.Biomes.IS_SWAMP)
                && Monster.checkMonsterSpawnRules(type, level, spawnType, pos, random);
    }

    /**
     * 刻意不注册 FloatGoal：FloatGoal 会把导航设为可浮水并持续按跳跃上浮（牛、僵尸因此漂在水面），
     * 而铁傀儡的 goals 恰恰没有它——无 FloatGoal + canSwim=false 才会沉底，与需求"入水沉底"一致。
     */
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Villager.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
    }

    /** 贴图档位：0=血量>40（完好），1=20<血量≤40（中损），2=血量≤20（重损）。血量经实体数据同步，客户端可直接读取。 */
    public int getDamageStage() {
        float health = getHealth();
        if (health > TEXTURE_HEALTH_HIGH) return 0;
        return health > TEXTURE_HEALTH_LOW ? 1 : 2;
    }

    /**
     * 攻击力随世界难度实时变化：简单 4、普通 6、困难 8。
     * <p>近战结算读取的就是 ATTACK_DAMAGE 属性的当前值（Mob#doHurtTarget），服务端逐 tick 刷新
     * 基础值即可覆盖难度中途切换的情况；PEACEFUL 下怪物不存活，按普通值兜底。</p>
     */
    @Override
    public void tick() {
        if (!level().isClientSide) {
            AttributeInstance attackDamage = getAttribute(Attributes.ATTACK_DAMAGE);
            if (attackDamage != null) {
                attackDamage.setBaseValue(switch (level().getDifficulty()) {
                    case EASY -> 4.0;
                    case HARD -> 8.0;
                    default -> 6.0;
                });
            }
        }
        super.tick();
    }

    /**
     * 镐类工具攻击额外 ×2 伤害（含原版所有镐与本模组的机械镐）。
     * <p>倍率只作用于“镐子自身的攻击力面板”（玩家基础伤害 1.0 + 武器携带的攻击加成修饰符），
     * 以等量追加实现：amount += 面板 × 1.0（叠加后总伤害即为面板 × 2）。力量（如幽灵头盔暗处自动附加的力量I +3）、
     * 锋利/亡灵克星等增益只按原版原样生效一次，不参与放大；非镐类攻击原样透传，与原版严格一致。</p>
     * <p>以下面板数值取自 1.21.1 反编译源码实测（非记忆推测）：
     * {@code Items} 中木剑 = {@code SwordItem.createAttributes(Tiers.WOOD, 3, -2.4F)}，
     * 全部镐 = {@code PickaxeItem.createAttributes(Tiers.X, 1.0F, -2.8F)}；
     * {@code Tiers} 第四参 attackDamageBonus 为 WOOD 0 / STONE 1 / IRON 2 / GOLD 0 / DIAMOND 3 / NETHERITE 4，
     * 修饰符 amount = 基线 + bonus；{@code MobEffects.DAMAGE_BOOST(力量)} 是每等级 +3 的
     * ATTACK_DAMAGE 属性修饰符（实体属性上，而非武器堆上，故不计入面板）。</p>
     * <p>由此，裸装（无力量/附魔）时对石像鬼的单次伤害应为：
     * 木剑 4.0（与原版完全一致）；金镐 2→4、木镐 2→4、石镐 3→6、铁镐 4→8、
     * 钻镐 5→10、下界合金镐与机械铁镐 6→12（=面板×2）。
     * 若戴幽灵头盔在亮度&lt;10 处测试，所有近战额外 +3（力量I，原版机制）：
     * 木剑 7.0、石镐 9.0——“木剑怎么还是 7”即此效果，并非镐类倍率泄漏。</p>
     */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        // 仅近战直击（direct 与 causer 同为该生物）才判定镐类加成，飞射物/爆炸等不受影响
        if (source.getDirectEntity() instanceof LivingEntity attacker && source.getEntity() == attacker) {
            ItemStack weapon = attacker.getItemBySlot(EquipmentSlot.MAINHAND);
            if (weapon.getItem() instanceof PickaxeItem) {
                amount += (float) (weaponBaseDamage(attacker, weapon) * 1.0);
            }
        }
        return super.hurt(source, amount);
    }

    /** 武器“自身”的攻击力面板：基础伤害(1.0) + 该物品主手的 ADD_VALUE 攻击伤害修饰符之和。 */
    private static double weaponBaseDamage(LivingEntity attacker, ItemStack weapon) {
        double[] weaponMod = {0.0};
        weapon.forEachModifier(EquipmentSlot.MAINHAND, (attribute, modifier) -> {
            if (modifier.operation() == AttributeModifier.Operation.ADD_VALUE
                    && attribute.value() == Attributes.ATTACK_DAMAGE.value()) {
                weaponMod[0] += modifier.amount();
            }
        });
        return attacker.getAttributeBaseValue(Attributes.ATTACK_DAMAGE) + weaponMod[0];
    }

    /**
     * 击退抗性 500%：原版按 (1 - 属性值) 结算，5.0 会得出负系数、反而把实体朝攻击者方向弹飞，
     * 因此这里按“完全免疫击退”处理（≥100% 抗性即无任何击退效果，500% 与之等效）。
     */
    @Override
    public void knockback(double strength, double x, double z) {
        if (getAttributeValue(Attributes.KNOCKBACK_RESISTANCE) >= 1.0) {
            return;
        }
        super.knockback(strength, x, z);
    }

    /**
     * 死亡时迸出稍多的石头方块被破坏粒子（与器械生物拆除同一做法：服务端 sendParticles 广播，
     * 粒子形态与玩家用镐挖掉一块石头时完全一致）。数量 36，略多于原白烟的 20 与器械的 28，
     * 均匀散布在整个碰撞箱内。die() 在死亡当刻、躯体消失的同时触发，视觉上即"崩解成一地碎石"。
     */
    @Override
    public void die(DamageSource source) {
        if (!level().isClientSide && !isRemoved() && !deathParticlesSpawned
                && level() instanceof ServerLevel serverLevel) {
            deathParticlesSpawned = true;
            BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
            serverLevel.sendParticles(stone,
                    getX(), getY() + getBbHeight() * 0.5, getZ(),
                    36,
                    getBbWidth() * 0.7, getBbHeight() * 0.45, getBbWidth() * 0.7,
                    0.16);
        }
        super.die(source);
    }

    /**
     * 死亡不再产生原版白烟粒子。
     * <p>原版流程：LivingEntity#tickDeath() 在死亡动画结束时由服务端广播 {@link EntityEvent#POOF}(=60)，
     * 客户端 handleEntityEvent 收到后生成 20 个 POOF（白烟）粒子。这里直接吞掉该事件——
     * 白烟与旧的圆石粒子替代品均不再出现；碎石效果改由 die() 里的石头破坏粒子承担。</p>
     */
    @Override
    public void handleEntityEvent(byte id) {
        if (id == EntityEvent.POOF) {
            return;
        }
        super.handleEntityEvent(id);
    }

    /**
     * 受击音效：{@code gargoyle_hurt} 事件在 sounds.json 中登记了两条素材
     * （Stone2 / Stone4 两份原样转码），原版声音引擎每次播放时从列表中随机取其一，
     * 实现游戏内随机切换。
     */
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return GeneratedMod.GARGOYLE_HURT.get();
    }

    /** 死亡音效：用户提供的 Gargoyle_death 素材。 */
    @Override
    protected SoundEvent getDeathSound() {
        return GeneratedMod.GARGOYLE_DEATH.get();
    }

    /** 与铁傀儡相同：入水不消耗氧气、不会窒息（IronGolem#decreaseAirSupply 的原样返回实现）。 */
    @Override
    protected int decreaseAirSupply(int amount) {
        return amount;
    }
}
