package cn.blockforge.generated.machinerylegend.block;

import cn.blockforge.generated.machinerylegend.entity.SoulforgeFireballEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * 炽炎弹拖着的 13 级隐形光照方块：在 {@link SoulforgeLightBlock} 的基础上多一道"残留自愈"保险。
 * <p>弹体每放置（或收养）一格光源，都会顺手注册一个延迟 {@value #RESIDUAL_CLEANUP_DELAY_TICKS} 刻的
 * 方块计划刻。弹体正常换格、命中消亡时都会即时清掉自己的光源，计划刻到点时那格多半早已是空气，
 * 空跑一次什么也不做；但如果那格里还留着同款光源方块，就检查有没有炽炎弹恰好还占着这格——
 * 有则顺延下一轮，没有则视为无主残留，直接移除。</p>
 * <p>计划刻会随区块一起存进存档（原版 block_ticks），而炽炎弹这类弹射物不存档。因此
 * "退出游戏再重载进来"时，弹体消失后仍残留的光源方块会在区块恢复 ticking 后由到点的计划刻
 * 自动清除，不会再留下悬空的 13 级光照。</p>
 */
public class SoulforgeFireballLightBlock extends SoulforgeLightBlock {
    /** 放置后延迟多少刻做残留检查：远大于弹体穿过一格的时间（约 1~2 刻），只当保险丝用。 */
    public static final int RESIDUAL_CLEANUP_DELAY_TICKS = 40;

    public SoulforgeFireballLightBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // ServerLevel 分派计划刻前已确认该格仍是本方块，这里只需判断还有没有炽炎弹正在用它。
        if (!level.getEntitiesOfClass(SoulforgeFireballEntity.class, new AABB(pos)).isEmpty()) {
            level.scheduleTick(pos, this, RESIDUAL_CLEANUP_DELAY_TICKS);
            return;
        }
        level.removeBlock(pos, false);
    }
}
