package cn.blockforge.generated.machinerylegend.block;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import cn.blockforge.generated.machinerylegend.menu.MineFieldMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.HolderLookup;

/** 矿场的持久化库存、产出计时器和相邻存储导出逻辑。 */
public final class MineFieldBlockEntity extends BaseContainerBlockEntity {
    public static final int SLOT_COUNT = 5;
    public static final int PRODUCTION_INTERVAL = 24 * 20;
    private static final String ITEMS_KEY = "Items";
    private static final String TIMER_KEY = "ProductionTimer";
    private NonNullList<ItemStack> items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);
    private int productionTimer;

    public MineFieldBlockEntity(BlockPos pos, BlockState state) {
        super(GeneratedMod.MINE_FIELD_ENTITY.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, MineFieldBlockEntity mineField) {
        if (level.isClientSide || !level.isDay()) return;
        mineField.transferToAdjacentStorage();
        if (mineField.isFull()) return;
        if (++mineField.productionTimer < PRODUCTION_INTERVAL) return;
        mineField.productionTimer = 0;
        mineField.addGeneratedOre(MineFieldBlock.rollOre(level.random));
        mineField.setChanged();
    }

    private boolean isFull() {
        for (ItemStack stack : items) {
            if (stack.isEmpty() || stack.getCount() < stack.getMaxStackSize()) return false;
        }
        return true;
    }

    private void addGeneratedOre(ItemStack generated) {
        ItemStack remaining = generated.copy();
        for (int slot = 0; slot < items.size() && !remaining.isEmpty(); slot++) {
            ItemStack current = items.get(slot);
            if (current.isEmpty()) {
                items.set(slot, remaining.copy());
                remaining = ItemStack.EMPTY;
            } else if (ItemStack.isSameItemSameComponents(current, remaining)) {
                int space = Math.min(getMaxStackSize(current), current.getMaxStackSize()) - current.getCount();
                if (space > 0) {
                    int moved = Math.min(space, remaining.getCount());
                    current.grow(moved);
                    remaining.shrink(moved);
                }
            }
        }
    }

    private void transferToAdjacentStorage() {
        if (level == null) return;
        for (Direction direction : Direction.values()) {
            Container target = HopperBlockEntity.getContainerAt(level, worldPosition.relative(direction));
            if (target == null || target == this) continue;
            boolean movedAny = false;
            for (int slot = 0; slot < items.size(); slot++) {
                ItemStack current = items.get(slot);
                if (current.isEmpty()) continue;
                ItemStack remainder = HopperBlockEntity.addItem(this, target, current, direction);
                if (remainder.getCount() != current.getCount()) movedAny = true;
                items.set(slot, remainder);
            }
            if (movedAny) setChanged();
        }
    }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("container.machinery_legend.mine_field");
    }

    @Override
    protected NonNullList<ItemStack> getItems() {
        return items;
    }

    @Override
    protected void setItems(NonNullList<ItemStack> items) {
        this.items = items;
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        items = NonNullList.withSize(SLOT_COUNT, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag.getCompound(ITEMS_KEY), items, registries);
        productionTimer = tag.getInt(TIMER_KEY);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.put(ITEMS_KEY, ContainerHelper.saveAllItems(new CompoundTag(), items, registries));
        tag.putInt(TIMER_KEY, productionTimer);
    }

    @Override
    protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
        return new MineFieldMenu(containerId, inventory, worldPosition);
    }

    @Override
    public int getContainerSize() {
        return SLOT_COUNT;
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    public int getProductionTimer() {
        return productionTimer;
    }
}
