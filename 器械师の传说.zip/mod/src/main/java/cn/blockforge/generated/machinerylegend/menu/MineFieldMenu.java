package cn.blockforge.generated.machinerylegend.menu;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.block.MineFieldBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** 矿场界面菜单，保留五格库存并同步挖矿进度。 */
public final class MineFieldMenu extends AbstractContainerMenu {
    private static final int FIELD_SLOT_START = 0;
    private static final int FIELD_SLOT_END = 5;
    private static final int PLAYER_INV_START = 5;
    private static final int PLAYER_INV_END = 41;
    private final Container field;
    private final ContainerLevelAccess access;
    private final Player player;
    private final ContainerData progressData;
    private int syncedProgress;

    public MineFieldMenu(int containerId, Inventory inventory, RegistryFriendlyByteBuf data) {
        this(containerId, inventory, data.readBlockPos());
    }

    public MineFieldMenu(int containerId, Inventory inventory, BlockPos blockPos) {
        super(GeneratedMod.MINE_FIELD_MENU.get(), containerId);
        this.player = inventory.player;
        this.field = inventory.player.level().getBlockEntity(blockPos) instanceof MineFieldBlockEntity mineField
                ? mineField
                : new net.minecraft.world.SimpleContainer(MineFieldBlockEntity.SLOT_COUNT);
        this.access = ContainerLevelAccess.create(inventory.player.level(), blockPos);
        this.progressData = new ContainerData() {
            @Override
            public int get(int index) {
                if (index != 0) return 0;
                return player.level().isClientSide
                        ? syncedProgress
                        : field instanceof MineFieldBlockEntity mineField ? mineField.getProductionTimer() : 0;
            }

            @Override
            public void set(int index, int value) {
                if (index == 0) syncedProgress = Math.max(0, Math.min(MineFieldBlockEntity.PRODUCTION_INTERVAL, value));
            }

            @Override
            public int getCount() {
                return 1;
            }
        };
        for (int slot = 0; slot < MineFieldBlockEntity.SLOT_COUNT; slot++) {
            addSlot(new Slot(field, slot, 44 + slot * 18, 20));
        }
        addPlayerInventory(inventory);
        addDataSlots(progressData);
    }

    private void addPlayerInventory(Inventory inventory) {
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                addSlot(new Slot(inventory, column + row * 9 + 9, 8 + column * 18, 51 + row * 18));
            }
        }
        for (int column = 0; column < 9; column++) {
            addSlot(new Slot(inventory, column, 8 + column * 18, 109));
        }
    }

    public int getProgress() {
        return progressData.get(0);
    }

    public int getProgressMax() {
        return MineFieldBlockEntity.PRODUCTION_INTERVAL;
    }

    @Override
    public boolean stillValid(Player player) {
        return stillValid(access, player, GeneratedMod.MINE_FIELD.get());
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (!slot.hasItem()) return result;
        ItemStack source = slot.getItem();
        result = source.copy();
        if (index < FIELD_SLOT_END) {
            if (!moveItemStackTo(source, PLAYER_INV_START, PLAYER_INV_END, true)) return ItemStack.EMPTY;
        } else if (!moveItemStackTo(source, FIELD_SLOT_START, FIELD_SLOT_END, false)) {
            return ItemStack.EMPTY;
        }
        if (source.isEmpty()) slot.set(ItemStack.EMPTY);
        else slot.setChanged();
        return result;
    }
}
