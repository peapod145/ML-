package cn.blockforge.generated.machinerylegend.mixin;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Boss 类生物获得反逆时，持续时间缩短到十分之一。 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityRebellionMixin {
    @ModifyVariable(method = "addEffect(Lnet/minecraft/world/effect/MobEffectInstance;Lnet/minecraft/world/entity/Entity;)Z",
            at = @At("HEAD"), argsOnly = true)
    private MobEffectInstance machineryLegend$shortenBossRebellion(MobEffectInstance instance) {
        if (instance == null || !instance.is(GeneratedMod.REBELLION)) return instance;
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof WitherBoss) && !(self instanceof EnderDragon)) return instance;
        int duration = instance.getDuration();
        if (duration <= 1 || duration == MobEffectInstance.INFINITE_DURATION) return instance;
        return new MobEffectInstance(instance.getEffect(), Math.max(1, duration / 10), instance.getAmplifier(),
                instance.isAmbient(), instance.isVisible(), instance.showIcon());
    }
}
