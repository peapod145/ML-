package cn.blockforge.generated.machinerylegend.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * 狼人：血量 35 的非亡灵敌对生物。
 * <ul>
 *   <li>人形态外貌为 WerewolfHumanoidModel（按用户上传狼人 bbmodel 复刻的玩家骨架 +
 *       狼吻/鼻/耳，手臂与躯干齐平），贴图为该 bbmodel 内嵌贴图重排成的
 *       werewolf_humanoid.png（见 WerewolfRenderer），碰撞箱 0.6×1.95；
 *       移动速度与僵尸一致（0.23）；</li>
 *   <li>自然生成：满月时的地表，或 Y&lt;20 的地下（生成规则见 checkWerewolfSpawnRules，
 *       权重 8 见 neoforge/biome_modifier/add_werewolf_spawns.json）；</li>
 *   <li>近战攻击伤害随难度实时变化：简单 4、普通 5、困难 7（服务端逐 tick 刷新基础值）；</li>
 *   <li>血量低于 15 时变身为狼形态（单向，不可逆）：外貌与原版愤怒的狼一致，
 *       碰撞箱 0.6×0.85，获得无限时长的速度 III 与力量 II；
 *       狼形态血量上限锁 14.9，受到治疗也无法超过（MAX_HEALTH 基础值同步改为 14.9）；</li>
 *   <li>受击与死亡音效与原版狼一致（WOLF_HURT / WOLF_DEATH）；</li>
 *   <li>掉落见 loot_table/entities/werewolf.json（钻石 10%、皮革 75%、羊肉 80%，
 *       火焰伤害致死时生羊肉换熟羊肉）；</li>
 *   <li>非亡灵生物：不加入 #minecraft:undead 标签；</li>
 *   <li>被飞刀（玩家投掷或飞刀圈）击中时额外承受 +2 伤害，判定在 ThrowingKnifeEntity 内。</li>
 * </ul>
 */
public final class WerewolfEntity extends Monster {
    /** 狼形态标记：服务端变身时写入，随实体数据同步到客户端（决定渲染模型与碰撞箱）。 */
    private static final EntityDataAccessor<Boolean> WOLF_FORM =
            SynchedEntityData.defineId(WerewolfEntity.class, EntityDataSerializers.BOOLEAN);
    /** 人形态碰撞箱与僵尸/石像鬼同宽；狼形态为原版狼 0.6×0.85。 */
    private static final EntityDimensions HUMANOID_DIMENSIONS = EntityDimensions.scalable(0.6F, 1.95F);
    private static final EntityDimensions WOLF_DIMENSIONS = EntityDimensions.scalable(0.6F, 0.85F);
    /** 血量低于该值触发变身（严格小于 15）。 */
    private static final float TRANSFORM_HEALTH_THRESHOLD = 15.0F;
    /** 狼形态血量上限：哪怕受到治疗也最高只有 14.9。 */
    private static final float WOLF_FORM_MAX_HEALTH = 14.9F;

    public WerewolfEntity(EntityType<? extends WerewolfEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 35.0)
                // 普通难度基线；实际结算值由 tick() 按当前难度刷为 4/5/7
                .add(Attributes.ATTACK_DAMAGE, 5.0)
                // 与僵尸一致（Zombie.createAttributes 的 0.23）
                .add(Attributes.MOVEMENT_SPEED, 0.23)
                .add(Attributes.FOLLOW_RANGE, 35.0);
    }

    /**
     * 满月判定：月相以 8 天为一周期，{@code dayTime / 24000 % 8 == 0} 的那天为满月日
     * （与原版月亮贴图取第 0 帧“满月”的算法一致；1.21.1 没有 getMoonPhase API）。
     */
    public static boolean isFullMoon(Level level) {
        long day = level.getDayTime() / 24000L;
        return (int)((day % 8L + 8L) % 8L) == 0;
    }

    /**
     * 生成规则：
     * <ul>
     *   <li>地下（位置低于 MOTION_BLOCKING_NO_LEAVES 高度图）：仅允许 Y&lt;20，沿用原版怪物生成条件；</li>
     *   <li>地表：仅满月时允许（Monster.checkMonsterSpawnRules 已要求黑暗，白天不会生成）。</li>
     * </ul>
     */
    public static boolean checkWerewolfSpawnRules(EntityType<WerewolfEntity> type, ServerLevelAccessor level,
                                                  MobSpawnType spawnType, BlockPos pos,
                                                  RandomSource random) {
        int surfaceY = level.getLevel().getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, pos.getX(), pos.getZ());
        if (pos.getY() < surfaceY) {
            // 地下：Y 小于 20 才允许
            return pos.getY() < 20 && Monster.checkMonsterSpawnRules(type, level, spawnType, pos, random);
        }
        // 地表：只在满月
        return isFullMoon(level.getLevel())
                && Monster.checkMonsterSpawnRules(type, level, spawnType, pos, random);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(WOLF_FORM, false);
    }

    public boolean isWolfForm() {
        return this.entityData.get(WOLF_FORM);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.0, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(6, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, Villager.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, IronGolem.class, true));
    }

    /**
     * 服务端逐 tick：
     * ① 攻击力按当前难度刷为 4/5/7（与石像鬼同一套做法）；
     * ② 血量跌破 15 触发变身（死亡中的个体不再变身）；
     * ③ 狼形态持续把血量上限钉在 14.9（防存档加载后属性被默认值覆盖）。
     */
    @Override
    public void tick() {
        if (!level().isClientSide) {
            AttributeInstance attackDamage = getAttribute(Attributes.ATTACK_DAMAGE);
            if (attackDamage != null) {
                attackDamage.setBaseValue(switch (level().getDifficulty()) {
                    case EASY -> 4.0;
                    case HARD -> 7.0;
                    default -> 5.0;
                });
            }
            if (isWolfForm()) {
                AttributeInstance maxHealth = getAttribute(Attributes.MAX_HEALTH);
                if (maxHealth != null && maxHealth.getBaseValue() != WOLF_FORM_MAX_HEALTH) {
                    maxHealth.setBaseValue(WOLF_FORM_MAX_HEALTH);
                }
                if (getHealth() > WOLF_FORM_MAX_HEALTH) {
                    setHealth(WOLF_FORM_MAX_HEALTH);
                }
            } else if (!isRemoved() && !isDeadOrDying()
                    && getHealth() > 0.0F && getHealth() < TRANSFORM_HEALTH_THRESHOLD) {
                enterWolfForm();
            }
        }
        super.tick();
    }

    /** 变身为狼形态：置同步标记（客户端据此换模型/换碰撞箱），上限锁 14.9，附加无限时长速度 III 与力量 II。 */
    private void enterWolfForm() {
        this.entityData.set(WOLF_FORM, true);
        AttributeInstance maxHealth = getAttribute(Attributes.MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(WOLF_FORM_MAX_HEALTH);
        }
        if (getHealth() > WOLF_FORM_MAX_HEALTH) {
            setHealth(WOLF_FORM_MAX_HEALTH);
        }
        // 速度 III（amplifier 2）与力量 II（amplifier 1），INFINITE_DURATION = -1 为无限时长
        addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, MobEffectInstance.INFINITE_DURATION, 2));
        addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, MobEffectInstance.INFINITE_DURATION, 1));
        refreshDimensions();
    }

    /**
     * 按形态返回基础碰撞箱。LivingEntity#getDimensions(Pose) 是 final 的，
     * 其内部走 getDefaultDimensions(Pose)，这里覆后者（狼人恒为成年，无需再乘年龄系数）。
     */
    @Override
    protected EntityDimensions getDefaultDimensions(Pose pose) {
        return isWolfForm() ? WOLF_DIMENSIONS : HUMANOID_DIMENSIONS;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (WOLF_FORM.equals(key)) {
            refreshDimensions();
        }
        super.onSyncedDataUpdated(key);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (isWolfForm()) {
            tag.putBoolean("WerewolfForm", true);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.getBoolean("WerewolfForm")) {
            this.entityData.set(WOLF_FORM, true);
            refreshDimensions();
        }
    }

    /** 受击音效与原版狼一致。 */
    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WOLF_HURT;
    }

    /** 死亡音效与原版狼一致。 */
    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WOLF_DEATH;
    }
}
