package cn.blockforge.generated.machinerylegend.client;

public final class ClientEnergy {
    private static int energy;
    private static int flashTicks;
    private ClientEnergy() {}
    public static int get() { return energy; }
    public static boolean isFlashing() { return flashTicks > 0; }
    public static void set(int value, int flash) { energy = value; flashTicks = Math.max(flashTicks, flash); }
    public static void tick() { if (flashTicks > 0) flashTicks--; }
}
