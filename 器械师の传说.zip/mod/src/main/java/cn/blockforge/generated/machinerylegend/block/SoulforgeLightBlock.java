package cn.blockforge.generated.machinerylegend.block;

import cn.blockforge.generated.machinerylegend.entity.SoulforgeEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * 炽炎熔炉系隐形光照方块：无碰撞、无渲染、不遮挡，只负责把光等级写进世界。
 * 器械本体（14 级）直接用本类；飞行中的炽炎弹（13 级）使用子类
 * {@link SoulforgeFireballLightBlock}，只换一种"主人"判定。
 * 光照等级在 BlockBehaviour.Properties 的 lightLevel 里给定，行为与荧石器械的发光方块一致。
 *
 * <p>除实体自身的即时清理外，每一格光源还带一道<b>残留自愈</b>保险：放置时注册一个延迟
 * {@code RESIDUAL_CLEANUP_DELAY_TICKS} 刻的方块计划刻，到点看这一格是否仍由存活的主人维持——
 * 是则顺延下一轮，否则按无主残留直接移除。计划刻会随区块存进存档（原版 block_ticks），
 * 新放置的灯因此永远有人复查。</p>
 *
 * <p>旧版本存档里<b>没注册过计划刻的历史残留灯</b>由
 * {@link SoulforgeLightResidualSweep} 兜底：它在服务端主线程上对已加载区块做调色板级普查，
 * 直接判定并当场移除无主的本类光源（不再依赖计划刻是否会被 ticking 区块执行）。
 * 这些无人认领的灯只要所在区块被加载就会自行熄灭，不再需要玩家进别的存档绕一圈。</p>
 */
public class SoulforgeLightBlock extends MachineryLightBlock {
    /** 放置后延迟多少刻做残留检查：远大于器械/弹体穿过一格的时间，只当保险丝用。 */
    public static final int RESIDUAL_CLEANUP_DELAY_TICKS = 40;

    public SoulforgeLightBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        if (level instanceof ServerLevel serverLevel) ensureSelfHealScheduled(serverLevel, pos);
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        // ServerLevel 分派计划刻前已确认该格仍是本方块，这里只需判断还有没有存活的主人在用。
        if (hasLivingOwnerAt(level, pos)) {
            ensureSelfHealScheduled(level, pos);
            return;
        }
        level.removeBlock(pos, false);
    }

    /**
     * 这一格是否仍由存活的主人维持。器械本体的判定是"有没有炽炎熔炉正好站在这格"：
     * 光照方块始终放在器械自身的 {@code blockPosition()} 上，两者重合即认定主人还在。
     * 炽炎弹子类改判"附近有没有还在飞的炽炎弹"。
     */
    public boolean hasLivingOwnerAt(ServerLevel level, BlockPos pos) {
        return !level.getEntitiesOfClass(SoulforgeEntity.class, new AABB(pos),
                owner -> !owner.isRemoved() && owner.blockPosition().equals(pos)).isEmpty();
    }

    /**
     * 注册一次残留自愈检查。同一格同一方块类型的计划刻在原版容器里天然去重
     * （{@code LevelChunkTicks#add} 只在时间更早时才覆盖），所以这里重复调用不会堆表。
     */
    public void ensureSelfHealScheduled(ServerLevel level, BlockPos pos) {
        level.scheduleTick(pos, this, RESIDUAL_CLEANUP_DELAY_TICKS);
    }
}
