package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.neoforged.fml.ModList;

import java.util.List;

/** 奥格拉斯的机械臂：装备在副手或 Curios 制品槽时降低机械能消耗。 */
public final class MechanicalArmItem extends Item {
    public MechanicalArmItem(Properties properties) {
        super(properties.stacksTo(1));
    }

    public static boolean isEquipped(Player player) {
        if (player.getOffhandItem().is(GeneratedMod.MECHANICAL_ARM.get())) return true;
        return ModList.get().isLoaded("curios") && CuriosCompat.isEquipped(player);
    }

    public static int reducedEnergyCost(Player player, int energyCost) {
        if (energyCost < 25 || !isEquipped(player)) return energyCost;
        return (energyCost + 1) / 2;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.mechanical_arm"));
    }
}
