package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.LightLayer;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class GhostHelmetItem extends ArmorItem {
    private static final Holder<ArmorMaterial> MATERIAL = Holder.direct(createMaterial());

    public GhostHelmetItem(Properties properties) {
        super(MATERIAL, Type.HELMET, properties.durability(100));
    }

    private static ArmorMaterial createMaterial() {
        EnumMap<Type, Integer> defense = new EnumMap<>(Type.class);
        for (Type type : Type.values()) defense.put(type, 0);
        defense.put(Type.HELMET, 1);
        return new ArmorMaterial(
                defense,
                15,
                SoundEvents.ARMOR_EQUIP_LEATHER,
                () -> Ingredient.EMPTY,
                List.of(new ArmorMaterial.Layer(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "ghost_helmet"))),
                0.0f,
                0.0f
        );
    }

    /** 玩家当前是否佩戴着幽灵天冠。 */
    public static boolean isWorn(Player player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).is(GeneratedMod.GHOST_HELMET.get());
    }

    /** 佩戴天冠时记录本刻开始前的饥饿值，本刻结束时据此还原被 exhaustion 吃掉的饥饿值。 */
    private static final Map<UUID, Integer> FOOD_SNAPSHOT = new ConcurrentHashMap<>();

    /** 玩家 tick 开始前调用：佩戴幽灵天冠则记下饥饿值快照，未佩戴则清掉残留记录。 */
    public static void beginTick(Player player) {
        if (player.level().isClientSide()) return;
        if (isWorn(player)) {
            FOOD_SNAPSHOT.put(player.getUUID(), player.getFoodData().getFoodLevel());
        } else {
            FOOD_SNAPSHOT.remove(player.getUUID());
        }
    }

    /**
     * 佩戴后：饥饿值不再下降——exhaustion 照常累积，原版每攒满 4.0 点先扣 1 点饱和度、
     * 饱和度扣光才落到饥饿值，这里只把本刻被扣掉的饥饿值还原，即饱和度仍然消耗、
     * 饥饿值保持不变；当玩家所处环境的亮度小于 10 时获得“抗性提升 1、力量 1、速度 1、夜视”。
     */
    public static void tick(Player player) {
        if (player.level().isClientSide()) return;
        if (!isWorn(player)) return;

        // 行走、跳跃、攻击、溺水以及“饥饿”效果都靠累计 exhaustion 消耗食物：
        // 饱和度的扣减原样保留，只还原本刻饥饿值被扣掉的那一步。
        Integer snapshot = FOOD_SNAPSHOT.remove(player.getUUID());
        FoodData food = player.getFoodData();
        if (snapshot != null && food.getFoodLevel() < snapshot) {
            food.setFoodLevel(snapshot);
        }

        // 有效环境亮度 = max(方块光照, 天空光 - 天空变暗)，随时间变化，避免白天屋外误触发。
        int brightness = player.level().getRawBrightness(player.blockPosition(), player.level().getSkyDarken());
        if (brightness >= 10) return;

        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 300, 0, true, false, true));
    }

    /**
     * 说明：平时不显示任何效果条目，只留一行灰色 Shift 提示；
     * 按住 Shift 时才按"暗所强化 / 饥饿保护 / 饱食进食"三节展开详细内容（与其他物品同款交互）。
     */
    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        if (flag.hasShiftDown()) {
            tooltip.add(Component.translatable("tooltip.machinery_legend.ghost_helmet_dark_title").withStyle(ChatFormatting.GOLD));
            tooltip.add(Component.translatable("tooltip.machinery_legend.ghost_helmet_dark_detail").withStyle(ChatFormatting.YELLOW));
            tooltip.add(Component.translatable("tooltip.machinery_legend.ghost_helmet_hunger_title").withStyle(ChatFormatting.GOLD));
            tooltip.add(Component.translatable("tooltip.machinery_legend.ghost_helmet_hunger_detail").withStyle(ChatFormatting.YELLOW));
            tooltip.add(Component.translatable("tooltip.machinery_legend.ghost_helmet_eat_title").withStyle(ChatFormatting.GOLD));
            tooltip.add(Component.translatable("tooltip.machinery_legend.ghost_helmet_eat_detail").withStyle(ChatFormatting.YELLOW));
        } else {
            tooltip.add(Component.translatable("tooltip.machinery_legend.ghost_helmet_shift").withStyle(ChatFormatting.GRAY));
        }
    }

    /**
     * 附近（±1 格）是否存在足以让幽灵从半透明回到普通状态的方块光照。
     * <p>所需光照等级随难度变化：简单 8、普通 11、困难 13（和平难度按普通兜底，
     * 幽灵本不会在和平难度自然生成）。</p>
     */
    public static boolean hasNearbyStrongBlockLight(net.minecraft.world.entity.Entity entity) {
        int threshold = switch (entity.level().getDifficulty()) {
            case EASY -> 8;
            case HARD -> 13;
            default -> 11;
        };
        BlockPos center = entity.blockPosition();
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    if (entity.level().getBrightness(LightLayer.BLOCK, center.offset(x, y, z)) >= threshold) return true;
                }
            }
        }
        return false;
    }
}
