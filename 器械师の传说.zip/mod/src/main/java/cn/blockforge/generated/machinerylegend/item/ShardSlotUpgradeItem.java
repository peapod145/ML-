package cn.blockforge.generated.machinerylegend.item;

import cn.blockforge.generated.machinerylegend.player.ShardData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/** 碎片槽位升级：右键使用使碎片槽位 +1，上限 5 格。 */
public final class ShardSlotUpgradeItem extends Item {
    public ShardSlotUpgradeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide()) {
            return InteractionResultHolder.success(stack);
        }
        if (!ShardData.upgrade(player)) {
            player.displayClientMessage(Component.translatable("message.machinery_legend.shard_slot_maxed"), true);
            return InteractionResultHolder.fail(stack);
        }
        if (!player.isCreative()) {
            stack.shrink(1);
        }
        player.displayClientMessage(Component.translatable("message.machinery_legend.shard_slot_upgraded",
                ShardData.getSlots(player)), true);
        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6f, 1.6f);
        return InteractionResultHolder.success(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, context, tooltip, flag);
        tooltip.add(Component.translatable("tooltip.machinery_legend.shard_slot_upgrade").withStyle(ChatFormatting.GRAY));
    }
}
