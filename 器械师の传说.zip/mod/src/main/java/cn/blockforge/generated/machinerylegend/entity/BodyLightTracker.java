package cn.blockforge.generated.machinerylegend.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * 器械生物“在本体所在格维护一格隐形光照方块”的公用逻辑。
 *
 * <p>荧石、熔炉、炽炎熔炉三台发光器械共用同一套流程——每刻把灯挪到本体当前格、
 * 换格时先撤旧灯、实体消亡时撤灯——差别只有光照方块类型，因此收敛到这里。
 * 所有世界读写都带“区块未加载就跳过”的护栏：退出存档的批量卸载半途调用方块读写会抛
 * {@code "Chunk not there when requested"}，打断 {@code stopServer()} 并让 level.dat 落盘被跳过。</p>
 */
final class BodyLightTracker {
    private final Mob owner;
    private final Block lightBlock;
    private BlockPos pos;

    BodyLightTracker(Mob owner, Block lightBlock) {
        this.owner = owner;
        this.lightBlock = lightBlock;
    }

    /** 当前维持的光照方块位置；没有则为 null。 */
    BlockPos pos() {
        return pos;
    }

    /** 每刻调用：本体换格时先撤旧灯，再在当前格放置（或认领）光照方块。 */
    void update() {
        BlockPos currentPos = owner.blockPosition();
        if (pos != null && !pos.equals(currentPos)) remove(pos);
        if (!owner.level().isLoaded(currentPos)) return;

        BlockState currentState = owner.level().getBlockState(currentPos);
        if (currentState.isAir() || currentState.is(lightBlock)) {
            BlockState lightState = lightBlock.defaultBlockState();
            if (!currentState.equals(lightState)) owner.level().setBlock(currentPos, lightState, 3);
            pos = currentPos;
        } else {
            pos = null;
        }
    }

    /** 撤掉指定格的灯；那一格已被别的方块占据时自动跳过。 */
    void remove(BlockPos target) {
        if (!owner.level().isLoaded(target)) return;
        if (owner.level().getBlockState(target).is(lightBlock)) {
            owner.level().removeBlock(target, false);
        }
    }

    /** 撤掉当前灯并复位引用（服务端清场）。 */
    void clear() {
        if (owner.level().isClientSide || pos == null) return;
        remove(pos);
        pos = null;
    }

    /** 只复位引用、不碰方块：区块因卸载而暂存时，灯随实体一起存盘，重载后重新接管。 */
    void forget() {
        pos = null;
    }
}
