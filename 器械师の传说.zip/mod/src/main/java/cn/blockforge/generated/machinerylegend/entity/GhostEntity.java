package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.item.GhostHelmetItem;
import net.minecraft.core.BlockPos;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.fluids.FluidType;

public final class GhostEntity extends Zombie {
    private static final EntityDataAccessor<Boolean> TRANSPARENT =
            SynchedEntityData.defineId(GhostEntity.class, EntityDataSerializers.BOOLEAN);

    /**
     * 悬停基准纵向速度：原版非飞行 LivingEntity 每 tick 在 travel() 里做
     * {@code vy = (vy - 0.08) * 0.98}，把 vy 设为 0.08 恰好抵消重力、实现定高悬停。
     */
    private static final double HOVER_BASE = 0.08;

    public GhostEntity(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        setCanBreakDoors(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.0);
    }

    public static boolean checkGhostSpawnRules(EntityType<GhostEntity> type, ServerLevelAccessor level,
                                                MobSpawnType spawnType, BlockPos pos,
                                                net.minecraft.util.RandomSource random) {
        return !level.getLevel().isDay() && Monster.checkMonsterSpawnRules(type, level, spawnType, pos, random);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(TRANSPARENT, true);
    }

    public boolean isGhostTransparent() {
        return entityData.get(TRANSPARENT);
    }

    /** 是否正受荧石激发潜能施加的缓慢 V 与挖掘疲劳 V 影响（两效果同时存在并达到 V 级）。 */
    private boolean isGlowstoneDebuffed() {
        MobEffectInstance slow = getEffect(MobEffects.MOVEMENT_SLOWDOWN);
        MobEffectInstance dig = getEffect(MobEffects.DIG_SLOWDOWN);
        return slow != null && dig != null
                && slow.getAmplifier() >= 4
                && dig.getAmplifier() >= 4;
    }

    private void setGhostTransparent(boolean transparent) {
        entityData.set(TRANSPARENT, transparent);
    }

    @Override
    protected boolean supportsBreakDoorGoal() {
        return false;
    }

    /** 幽灵行走时不发出脚步声：覆盖 Zombie 的脚步逻辑且不再调用 super。 */
    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
    }

    /** 幽灵在水中不受窒息伤害：让 NeoForge 的呼吸逻辑视其为可在任意流体中呼吸。 */
    @Override
    public boolean canDrownInFluidType(FluidType type) {
        return false;
    }

    /** 幽灵在水中永远保持幽灵形态：关闭原版 Zombie 的溺尸转化开关，水中倒计时永不启动。 */
    @Override
    protected boolean convertsInWater() {
        return false;
    }

    /**
     * 兜底：若 conversionTime 已被其他途径设置（如旧存档 NBT、模组交互），
     * 顺手清零，彻底杜绝转成溺尸的可能。
     */
    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide() && isUnderWaterConverting()) {
            conversionTime = -1;
        }
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType spawnType, SpawnGroupData spawnData) {
        // 传入"非幼年、无鸡骑士"的 ZombieGroupData，跳过原版的幼年变体与鸡骑士分支，
        // 但保留原版其余生成逻辑（默认装备等）；随后再兜底强制成年。
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, spawnType,
                spawnData instanceof Zombie.ZombieGroupData ? spawnData : new Zombie.ZombieGroupData(false, false));
        setItemSlot(EquipmentSlot.HEAD, new ItemStack(GeneratedMod.GHOST_HELMET.get()));
        setDropChance(EquipmentSlot.HEAD, 0.0f);
        setCanBreakDoors(false);
        setBaby(false);
        return data;
    }

    @Override
    public void aiStep() {
        // 伪飞行·悬停下坠（与 Blaze 逐字一致）：离地且在下坠时把竖直速度乘 0.6，落得慢、显得在飘。
        if (!this.onGround() && this.getDeltaMovement().y() < 0.0) {
            this.setDeltaMovement(this.getDeltaMovement().multiply(1.0, 0.6, 1.0));
        }
        super.aiStep();
        if (level().isClientSide()) {
            // 腿部不断冒出白色、烟花火箭同款火星粒子：ghost_spark 复用原版 spark_0~7 火星贴图
            // （纯白、匀速向下喷射，原版 SMOKE 是深灰且恒定上飘，满足不了"白色且向下"）。
            // 上一版每 tick 喷 2 团大烟雾显得太多太大，现在改为每 2 tick 喷 1 颗火星级小粒子
            //（0.04~0.09 格，渲染端见 client.GhostSparkParticle），初速恒定向下（friction=1 不衰减）。
            if (this.tickCount % 2 == 0) {
                double width = this.getBbWidth() + 0.1;
                double px = this.getX() + (this.random.nextDouble() - 0.5) * width;
                double pz = this.getZ() + (this.random.nextDouble() - 0.5) * width;
                double py = this.getY() + 0.1 + this.random.nextDouble() * 0.35;
                this.level().addParticle(GeneratedMod.GHOST_SPARK.get(), px, py, pz,
                        this.random.nextGaussian() * 0.008,
                        -(0.06 + this.random.nextDouble() * 0.05),
                        this.random.nextGaussian() * 0.008);
            }
            return;
        }

        // 白天燃烧与原版僵尸、骷髅完全同判据：isSunSensitive() && isSunBurnTick()。
        // isSunBurnTick()（Mob）要求：白天、服务端、眼部位置 canSeeSky（头顶无非透明方块遮挡）、
        // 不在水/雨/气泡/细雪中、光照强度大于 0.5 且通过原版随机判定；任一条件不满足则不点燃。
        // 因此白天站在屋檐、树叶、方块天花板等遮挡下不会燃烧，与原版行为一致；
        // 点燃时长同样取原版的 8 秒（Entity#igniteForSeconds）。
        if (isSunSensitive() && isSunBurnTick()) {
            igniteForSeconds(8.0f);
        }
        // 显形逻辑保持原样，不受本次燃烧改动影响。
        boolean revealed = level().isDay() || isOnFire() || GhostHelmetItem.hasNearbyStrongBlockLight(this);
        // 受到荧石激发潜能施加的缓慢 V 与挖掘疲劳 V 期间（效果持续 5 秒）强制显露，取消半透明；
        // 半透明状态下的 90% 减伤由 getDamageAfterMagicAbsorb() 处理。
        setGhostTransparent(!(revealed || isGlowstoneDebuffed()));
    }

    /**
     * 新的飞行方式（服务端逐 tick 接管纵向速度）：
     * <p>① 脚在液体里时优先"悬浮在液面"：目标高度取液面，离液面越深上浮越快，
     * 到达液面（脚恰好入水，fluidSurface≈0）后自动转为悬停，不会扎进水底。</p>
     * <p>② 不在液体里且有目标时，与目标保持同一高度追击：纵向速度按眼睛高度差做
     * 比例控制并加悬停基准（抵消重力），目标高则升、目标低则降、同高则定高平飞，
     * 速度限幅 ±0.45 格/tick，不会瞬移式窜升。</p>
     * <p>没有目标时保持原有烈焰人式悬停下坠（aiStep 里的 ×0.6）。</p>
     */
    @Override
    protected void customServerAiStep() {
        Vec3 motion = this.getDeltaMovement();
        // getFluidTypeHeight 返回"液面相对脚底的高度"（脚在液体里时 >0，否则 0），
        // getMaxHeightFluidType 取接触最高的流体类型 —— 对水、岩浆及模组流体通用。
        double fluidSurface = this.getFluidTypeHeight(this.getMaxHeightFluidType());
        if (fluidSurface > 0.0) {
            // 悬浮在液面：把脚底往"液面上方 0.15 格"推，比例收敛。
            double wanted = HOVER_BASE + Mth.clamp((fluidSurface - 0.15) * 0.35, -0.2, 0.45);
            this.setDeltaMovement(motion.x, wanted, motion.z);
            this.hasImpulse = true;
        } else {
            LivingEntity target = this.getTarget();
            if (target != null && this.canAttack(target)) {
                double heightDiff = target.getEyeY() - this.getEyeY();
                double wanted = HOVER_BASE + Mth.clamp(heightDiff * 0.22, -0.45, 0.45);
                this.setDeltaMovement(motion.x, wanted, motion.z);
                this.hasImpulse = true;
            }
        }
        super.customServerAiStep();
    }

    /**
     * 悬停追击：幽灵浮空时脚不接触地面，GroundPathNavigation 找不到路径，
     * 于是没人设置前进输入（zza），{@code travel()} 每 tick 用零输入重建水平速度，
     * 导致幽灵"升到目标高度后就停在空中不动"。这里在没有任何移动输入时补上：
     * 面向目标并按 zza=1 的常规前进管线推进——速度仍由 travel() 走 MOVEMENT_SPEED
     * 属性计算，与地面僵尸追击目标完全一致；地面有路径时 zza 本来就 &gt; 0，不受影响。
     */
    @Override
    public void travel(Vec3 movementInput) {
        if (!this.level().isClientSide() && movementInput.z <= 0.0) {
            LivingEntity target = this.getTarget();
            if (target != null && target.isAlive() && this.canAttack(target)) {
                double dx = target.getX() - this.getX();
                double dz = target.getZ() - this.getZ();
                if (dx * dx + dz * dz > 1.0E-4) {
                    this.setYRot((float) (Mth.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F);
                    movementInput = new Vec3(movementInput.x, movementInput.y, 1.0);
                }
            }
        }
        super.travel(movementInput);
    }

    /**
     * 免疫摔落伤害：1.21.1 的摔落伤害唯一入口是 {@code Entity#causeFallDamage(float, float, DamageSource)}
     * （落地时经 {@code Block#fallOn} 调用；本版本已无 causesFallDamage()），返回 false 即不结算伤害。
     * 落地的方块粒子、音效等原版行为不受影响。
     */
    @Override
    public boolean causeFallDamage(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source.is(DamageTypeTags.IS_FIRE)) {
            setGhostTransparent(false);
            igniteForSeconds(8.0f);
        }
        return super.hurt(source, amount);
    }

    /**
     * 半透明状态下获得 90% 减伤：实际伤害仅保留 10%。
     * <p>关键点：NeoForge 1.21.1 的 {@code LivingEntity#actuallyHurt()} 虽然会调用本方法，
     * 但把返回值直接丢弃（字节码里 {@code getDamageAfterMagicAbsorb} 调用后紧跟一个 pop），
     * 真正扣血用的是当前 {@code DamageContainer} 的 {@code getNewDamage()}。
     * 所以只返回 {@code f * 0.1F} 在游戏内完全无效——必须把 90% 减伤写进容器的
     * {@code INNATE_RESISTANCE} 档位，它才会被 {@code actuallyHurt()} 计入扣血量。</p>
     */
    @Override
    protected float getDamageAfterMagicAbsorb(DamageSource source, float amount) {
        float afterMagic = super.getDamageAfterMagicAbsorb(source, amount);
        if (!isGhostTransparent()) return afterMagic;
        // 炽炎弹无视半透明 90% 减伤：伤害原样结算，不写入 INNATE_RESISTANCE 档位。
        if (source.getDirectEntity() instanceof SoulforgeFireballEntity) return afterMagic;

        if (!this.damageContainers.isEmpty()) {
            DamageContainer container = this.damageContainers.peek();
            // getNewDamage() 此时已扣除护甲与附魔保护，再从中扣掉 90%，保留 10%。
            float remaining = container.getNewDamage();
            if (remaining > 0.0F) {
                container.setReduction(DamageContainer.Reduction.INNATE_RESISTANCE, remaining * 0.9F);
                afterMagic = remaining * 0.1F;
            }
        } else {
            // 兜底：容器缺失时至少让返回值是正确的减伤结果。
            afterMagic *= 0.1F;
        }
        return afterMagic;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.SKELETON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SKELETON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return GeneratedMod.GHOST_DEATH.get();
    }

    @Override
    public void knockback(double strength, double x, double z) {
        // 原版属性不接受负值；按 -0.5 击退抗性的实际效果，将承受的击退放大到 150%。
        super.knockback(strength * 1.5, x, z);
    }
}
