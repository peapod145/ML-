package cn.blockforge.generated.machinerylegend.mixin;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.world.Container;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 让星之碎片不会被漏斗、漏斗矿车之类的吸取型方块/载具收走。
 *
 * <p>原版 {@code HopperBlockEntity#suckInItems} 会把吸取范围内的所有 {@link ItemEntity}
 * 逐个交给 {@code addItem(Container, ItemEntity)}；漏斗方块和漏斗矿车都走这一条路径，
 * 而 NeoForge 只为玩家拾取提供了 {@code ItemEntityPickupEvent}，吸取型方块没有对应事件，
 * 所以在这一层把星之碎片挡回去：返回 false 表示“这一个没吸走”，
 * 吸取循环会继续处理范围内的其他掉落物，其余行为完全不变。</p>
 */
@Mixin(HopperBlockEntity.class)
public abstract class HopperBlockEntityMixin {
    @Inject(
            method = "addItem(Lnet/minecraft/world/Container;Lnet/minecraft/world/entity/item/ItemEntity;)Z",
            at = @At("HEAD"),
            cancellable = true)
    private static void machineryLegend$rejectStarShard(Container container, ItemEntity itemEntity,
                                                       CallbackInfoReturnable<Boolean> cir) {
        ItemStack stack = itemEntity.getItem();
        if (!stack.isEmpty() && stack.is(GeneratedMod.STAR_SHARD.get())) {
            cir.setReturnValue(false);
        }
    }
}
