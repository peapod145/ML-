package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** 小型发射器：只在夜间工作，荧石粉唤醒后白天也会工作。 */
public class SmallEmitterEntity extends MachineryEntity {
    private static final EntityDataAccessor<Boolean> DATA_AWAKE =
            SynchedEntityData.defineId(SmallEmitterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_DAY_SLEEPING =
            SynchedEntityData.defineId(SmallEmitterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final int NORMAL_COOLDOWN = 30;
    protected static final int EMPOWERED_COOLDOWN = 40;
    protected static final int EMPOWERED_DURATION = 400;
    private static final double TARGET_SEARCH_RANGE = 15.0;
    private static final double NORMAL_ATTACK_RANGE = 5.0;
    private static final double MUZZLE_Y_OFFSET = 0.36;
    private static final double MUZZLE_FORWARD_OFFSET = 0.36;
    /** 普通攻击冷却与攻击半径：炽炎熔炉按发射器参数在构造器里覆盖，默认值与旧行为一致。 */
    protected int normalCooldown = NORMAL_COOLDOWN;
    protected double normalAttackRange = NORMAL_ATTACK_RANGE;
    protected int shotCooldown;
    protected int empoweredCooldown;
    protected int empoweredTicks;

    public SmallEmitterEntity(EntityType<? extends SmallEmitterEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_AWAKE, false);
        builder.define(DATA_DAY_SLEEPING, false);
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.DISPENSER.defaultBlockState();
    }

    @Override
    protected boolean hasOffensiveCapability() {
        // 小型发射器会射出弹射物，具备攻击能力，保留索敌与仇恨。
        return true;
    }

    @Override
    protected LivingEntity findTarget() {
        // 索敌范围独立于攻击范围，始终以自身为中心搜索半径15格内的敌对生物。
        return findTarget(TARGET_SEARCH_RANGE, true);
    }

    @Override
    public void tick() {
        super.tick();
        // 小型发射器始终保持水平炮口，不能因索敌而抬头或低头。
        setXRot(0.0f);
        if (level().isClientSide) return;

        if (empoweredTicks > 0) empoweredTicks--;
        if (shotCooldown > 0) shotCooldown--;
        if (empoweredCooldown > 0) empoweredCooldown--;
        boolean daySleeping = isDaySleeping();
        if (entityData.get(DATA_DAY_SLEEPING) != daySleeping) {
            entityData.set(DATA_DAY_SLEEPING, daySleeping);
        }
        if (daySleeping) return;

        // 强化后无论是否存在目标，都沿着器械当前朝向发射一发滚动雪球。
        if (empoweredTicks > 0) {
            tickEmpowered();
            return;
        }

        LivingEntity target = getTarget();
        double attackRange = normalAttackRange;
        if (target == null || !target.isAlive() || !hasLineOfSight(target) || distanceTo(target) > attackRange) return;
        lookAt(target, 360.0f, 360.0f);
        setXRot(0.0f);

        if (shotCooldown <= 0) {
            fireProjectile(target);
            playBowShot();
            shotCooldown = normalCooldown;
        }
    }

    /** 强化期分支：默认每 40 刻射出一发滚动雪球；炽炎熔炉等子类可整体替换强化弹道。 */
    protected void tickEmpowered() {
        if (empoweredCooldown <= 0) {
            fireRollingSnowball();
            playBowShot();
            empoweredCooldown = EMPOWERED_COOLDOWN;
        }
    }

    /** 射出一发普通弹药；传染发射器继承后把雪球换成寄生机器人。 */
    protected void fireProjectile(LivingEntity target) {
        Vec3 direction = horizontalForward();
        Vec3 start = muzzlePosition(direction);
        SmallEmitterSnowballEntity snowball = new SmallEmitterSnowballEntity(
                GeneratedMod.SMALL_EMITTER_SNOWBALL.get(), this, level());
        snowball.setPos(start);
        snowball.shoot(direction.x, direction.y, direction.z, 0.72f, 0.0f);
        level().addFreshEntity(snowball);
    }

    protected void fireRollingSnowball() {
        Vec3 direction = horizontalForward();
        Vec3 start = muzzlePosition(direction);
        RollingSnowballEntity snowball = new RollingSnowballEntity(
                GeneratedMod.ROLLING_SNOWBALL.get(), this, level());
        snowball.setPos(start);
        // 不关闭投射物重力，让滚动雪球按抛射物规则下坠并落地滚动。
        // 这是唯一保留重力的器械弹药：其余器械弹药（箭、飞刀、普通雪球、寄生机器人、炽炎弹）
        // 都已关闭重力直线飞行；滚动雪球靠下坠落地才有"滚动"机制，故此发维持原样。
        snowball.shoot(direction.x, direction.y, direction.z, 0.30f, 0.0f);
        level().addFreshEntity(snowball);
        // 激发状态只用于释放这一发滚动雪球，发射成功后恢复常规状态。
        empoweredTicks = 0;
    }

    protected Vec3 muzzlePosition(Vec3 direction) {
        return new Vec3(getX(), getY() + MUZZLE_Y_OFFSET, getZ()).add(direction.scale(MUZZLE_FORWARD_OFFSET));
    }

    public boolean isDaySleeping() {
        return level().isDay() && !isPermanentlyAwake();
    }

    /**
     * 睡觉标识只允许在白天休眠时显示；夜间生效或被荧石粉唤醒时都必须隐藏。
     */
    public boolean shouldRenderSleepingIndicator() {
        return entityData.get(DATA_DAY_SLEEPING);
    }

    /** 是否已被荧石粉永久唤醒。 */
    public boolean isPermanentlyAwake() {
        return entityData.get(DATA_AWAKE);
    }

    public void wake() {
        if (!level().isClientSide) {
            entityData.set(DATA_AWAKE, true);
            entityData.set(DATA_DAY_SLEEPING, false);
        }
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || isDaySleeping()) return;
        startEvocationEffect();
        empoweredTicks = EMPOWERED_DURATION;
        empoweredCooldown = 0;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Awake", isPermanentlyAwake());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.getBoolean("Awake")) wake();
    }
}
