package cn.blockforge.generated.machinerylegend;

import cn.blockforge.generated.machinerylegend.entity.EmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.FurnaceEntity;
import cn.blockforge.generated.machinerylegend.entity.MachineryEntity;
import cn.blockforge.generated.machinerylegend.entity.SmallEmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.SmallEmitterSnowballEntity;
import cn.blockforge.generated.machinerylegend.entity.RollingSnowballEntity;
import cn.blockforge.generated.machinerylegend.entity.ObsidianEntity;
import cn.blockforge.generated.machinerylegend.entity.MineTntEntity;
import cn.blockforge.generated.machinerylegend.entity.InvasionDrownedEntity;
import cn.blockforge.generated.machinerylegend.entity.InvasionHuskEntity;
import cn.blockforge.generated.machinerylegend.entity.InvasionZombieEntity;
import cn.blockforge.generated.machinerylegend.entity.CheatingVillagerEntity;
import cn.blockforge.generated.machinerylegend.entity.PoweredCartEntity;
import cn.blockforge.generated.machinerylegend.entity.RakeEntity;
import cn.blockforge.generated.machinerylegend.entity.SniperEmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.KnifeEmitterEntity;
import cn.blockforge.generated.machinerylegend.entity.MoonlightSensorEntity;
import cn.blockforge.generated.machinerylegend.entity.GhostEntity;
import cn.blockforge.generated.machinerylegend.entity.GlowstoneEntity;
import cn.blockforge.generated.machinerylegend.entity.GargoyleEntity;
import cn.blockforge.generated.machinerylegend.entity.WerewolfEntity;
import cn.blockforge.generated.machinerylegend.entity.PunchPistonEntity;
import cn.blockforge.generated.machinerylegend.entity.InfectenserEntity;
import cn.blockforge.generated.machinerylegend.entity.ParasiteBotEntity;
import cn.blockforge.generated.machinerylegend.entity.SoulforgeEntity;
import cn.blockforge.generated.machinerylegend.entity.SoulforgeFireballEntity;
import cn.blockforge.generated.machinerylegend.item.InfectenserBlueprintItem;
import cn.blockforge.generated.machinerylegend.effect.MachineParasiteEffect;
import cn.blockforge.generated.machinerylegend.effect.RebellionEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.PotionItem;
import net.minecraft.world.item.ThrowablePotionItem;
import net.minecraft.world.item.LingeringPotionItem;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.core.component.DataComponents;

import java.util.List;
import cn.blockforge.generated.machinerylegend.item.BlueprintItem;
import cn.blockforge.generated.machinerylegend.item.PunchPistonBlueprintItem;
import cn.blockforge.generated.machinerylegend.item.ThrowingKnifeItem;
import cn.blockforge.generated.machinerylegend.entity.ThrowingKnifeEntity;
import cn.blockforge.generated.machinerylegend.item.GhostHelmetItem;
import cn.blockforge.generated.machinerylegend.item.GargoyleSpawnEggItem;
import cn.blockforge.generated.machinerylegend.item.WerewolfSpawnEggItem;
import cn.blockforge.generated.machinerylegend.item.SniperBlueprintItem;
import cn.blockforge.generated.machinerylegend.item.PoweredCartItem;
import cn.blockforge.generated.machinerylegend.item.RakeItem;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import cn.blockforge.generated.machinerylegend.item.MachineryPickaxeItem;
import cn.blockforge.generated.machinerylegend.item.MechanicalArmItem;
import cn.blockforge.generated.machinerylegend.item.BestiaryItem;
import cn.blockforge.generated.machinerylegend.item.InvasionFlagItem;
import cn.blockforge.generated.machinerylegend.item.StarShardItem;
import cn.blockforge.generated.machinerylegend.item.ShardSlotUpgradeItem;
import cn.blockforge.generated.machinerylegend.effect.StarShardCarrierEffect;
import cn.blockforge.generated.machinerylegend.network.RecordBestiaryPayload;
import cn.blockforge.generated.machinerylegend.network.PlaceRakePayload;
import cn.blockforge.generated.machinerylegend.block.MechanicalEnergyConverterBlock;
import cn.blockforge.generated.machinerylegend.block.MechanicalEnergyConverterBlockEntity;
import cn.blockforge.generated.machinerylegend.block.MineFieldBlock;
import cn.blockforge.generated.machinerylegend.block.MineFieldBlockEntity;
import cn.blockforge.generated.machinerylegend.block.FurnaceLightBlock;
import cn.blockforge.generated.machinerylegend.block.GlowstoneLightBlock;
import cn.blockforge.generated.machinerylegend.block.SoulforgeLightBlock;
import cn.blockforge.generated.machinerylegend.block.SoulforgeFireballLightBlock;
import cn.blockforge.generated.machinerylegend.block.SoulforgeLightResidualSweep;
import cn.blockforge.generated.machinerylegend.menu.ConverterMenu;
import cn.blockforge.generated.machinerylegend.menu.MineFieldMenu;
import cn.blockforge.generated.machinerylegend.network.EnergyNetwork;
import net.neoforged.neoforge.common.NeoForge;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

@Mod(GeneratedMod.MOD_ID)
public final class GeneratedMod {
    public static final String MOD_ID = "machinery_legend";
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MOD_ID);
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITY_TYPES = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(BuiltInRegistries.MENU, MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, MOD_ID);
    public static final DeferredRegister<SoundEvent> SOUND_EVENTS = DeferredRegister.create(BuiltInRegistries.SOUND_EVENT, MOD_ID);
    public static final DeferredRegister<MobEffect> MOB_EFFECTS = DeferredRegister.create(BuiltInRegistries.MOB_EFFECT, MOD_ID);
    public static final DeferredRegister<ParticleType<?>> PARTICLE_TYPES = DeferredRegister.create(Registries.PARTICLE_TYPE, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);
    // 可同步的数据附件：NeoForge 会把值自动发给“能看到该实体”的客户端，并在这名玩家开始追踪实体时补发初始值。
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENT_TYPES = DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, MOD_ID);
    /**
     * 星之碎片携带者标记（仅作客户端视觉判定）：1.21 起非玩家实体的药水效果不会同步给其他客户端，
     * 客户端 {@code getActiveEffects()} 里根本没有怪物的效果，只拿得到同步的粒子颜色。
     * 所以绿光必须靠这个附件把“是不是携带者”独立同步过去，服务端 setData 一次即可。
     */
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<Boolean>> STAR_SHARD_CARRIER_FLAG =
            ATTACHMENT_TYPES.register("star_shard_carrier",
                    () -> AttachmentType.<Boolean>builder(() -> Boolean.FALSE).sync(ByteBufCodecs.BOOL).build());
    /**
     * 反逆发光标记（仅作客户端视觉判定）：与 {@link #STAR_SHARD_CARRIER_FLAG} 同一套道理，
     * 非玩家实体的药水效果不会同步给其他客户端，品红发光必须靠这个附件把“是否处于反逆”
     * 独立同步过去。服务端每刻按权威效果刷新，只在值变化时写入。
     */
    public static final DeferredHolder<AttachmentType<?>, AttachmentType<Boolean>> REBELLION_FLAG =
            ATTACHMENT_TYPES.register("rebellion",
                    () -> AttachmentType.<Boolean>builder(() -> Boolean.FALSE).sync(ByteBufCodecs.BOOL).build());

    public static final DeferredItem<Item> ENERGY_GEAR = ITEMS.register("energy_gear", () -> new Item(new Item.Properties().stacksTo(64)));
    public static final DeferredBlock<Block> MECHANICAL_ENERGY_CONVERTER = BLOCKS.register("mechanical_energy_converter", () -> new MechanicalEnergyConverterBlock(BlockBehaviour.Properties.of().mapColor(net.minecraft.world.level.material.MapColor.METAL).strength(3.5f).requiresCorrectToolForDrops().noOcclusion().sound(net.minecraft.world.level.block.SoundType.METAL)));
    public static final DeferredItem<BlockItem> MECHANICAL_ENERGY_CONVERTER_ITEM = ITEMS.register("mechanical_energy_converter", () -> new BlockItem(MECHANICAL_ENERGY_CONVERTER.get(), new Item.Properties()));
    public static final DeferredBlock<Block> MINE_FIELD = BLOCKS.register("mine_field", () -> new MineFieldBlock(BlockBehaviour.Properties.of().mapColor(net.minecraft.world.level.material.MapColor.COLOR_GRAY).strength(3.0f).requiresCorrectToolForDrops().noOcclusion().sound(net.minecraft.world.level.block.SoundType.METAL).lightLevel(state -> 5)));
    public static final DeferredItem<BlockItem> MINE_FIELD_ITEM = ITEMS.register("mine_field", () -> new BlockItem(MINE_FIELD.get(), new Item.Properties()));
    public static final DeferredBlock<Block> FURNACE_LIGHT = BLOCKS.register("furnace_light", () -> new FurnaceLightBlock(BlockBehaviour.Properties.of().noCollission().noOcclusion().air().lightLevel(state -> 10)));
    public static final DeferredBlock<Block> GLOWSTONE_LIGHT = BLOCKS.register("glowstone_light", () -> new GlowstoneLightBlock(BlockBehaviour.Properties.of().noCollission().noOcclusion().air().lightLevel(state -> 15)));
    // 炽炎熔炉本体的隐形光照方块：14 级光，发光逻辑与荧石器械一致。
    public static final DeferredBlock<Block> SOULFORGE_LIGHT = BLOCKS.register("soulforge_light", () -> new SoulforgeLightBlock(BlockBehaviour.Properties.of().noCollission().noOcclusion().air().lightLevel(state -> 14)));
    // 炽炎弹拖着的 13 级移动光源：跟随弹体所在格，只在空气格里放置；带计划刻兜底，
    // 退出游戏重载后自动清除弹体消失时残留的无主光源方块。
    public static final DeferredBlock<Block> SOULFORGE_FIREBALL_LIGHT = BLOCKS.register("soulforge_fireball_light", () -> new SoulforgeFireballLightBlock(BlockBehaviour.Properties.of().noCollission().noOcclusion().air().lightLevel(state -> 13)));
    public static final DeferredItem<Item> BLANK_BLUEPRINT = ITEMS.register("blank_blueprint", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final DeferredItem<Item> MACHINERY_PICKAXE = ITEMS.register("machinery_pickaxe", () -> new MachineryPickaxeItem(new Item.Properties().durability(400)));
    public static final DeferredItem<RakeItem> MACHINERY_RAKE = ITEMS.register("machinery_rake", () -> new RakeItem(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<MechanicalArmItem> MECHANICAL_ARM = ITEMS.register("mechanical_arm", () -> new MechanicalArmItem(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<BestiaryItem> BESTIARY = ITEMS.register("bestiary", () -> new BestiaryItem(new Item.Properties()));
    public static final DeferredItem<InvasionFlagItem> INVASION_FLAG = ITEMS.register("invasion_flag", () -> new InvasionFlagItem(new Item.Properties().stacksTo(16)));
    public static final DeferredItem<PoweredCartItem> POWERED_CART = ITEMS.register("powered_cart", () -> new PoweredCartItem(new Item.Properties()));
    // 飞刀：投掷型武器，堆叠上限 16。
    public static final DeferredItem<ThrowingKnifeItem> THROWING_KNIFE = ITEMS.register("throwing_knife", () -> new ThrowingKnifeItem(new Item.Properties().stacksTo(16)));
    public static final DeferredHolder<EntityType<?>, EntityType<EmitterEntity>> EMITTER = ENTITY_TYPES.register("emitter", () -> EntityType.Builder.of(EmitterEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(12).updateInterval(1).build("emitter"));
    public static final DeferredHolder<EntityType<?>, EntityType<FurnaceEntity>> FURNACE = ENTITY_TYPES.register("furnace_machine", () -> EntityType.Builder.of(FurnaceEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(12).updateInterval(1).build("furnace_machine"));
    public static final DeferredHolder<EntityType<?>, EntityType<ObsidianEntity>> OBSIDIAN = ENTITY_TYPES.register("obsidian_machine", () -> EntityType.Builder.of(ObsidianEntity::new, MobCategory.MISC).sized(0.9f, 1.0f).clientTrackingRange(12).updateInterval(1).build("obsidian_machine"));
    public static final DeferredHolder<EntityType<?>, EntityType<MineTntEntity>> MINE_TNT = ENTITY_TYPES.register("mine_tnt", () -> EntityType.Builder.of(MineTntEntity::new, MobCategory.MISC).sized(0.9f, 0.75f).clientTrackingRange(12).updateInterval(1).build("mine_tnt"));
    public static final DeferredHolder<EntityType<?>, EntityType<InvasionZombieEntity>> INVASION_ZOMBIE = ENTITY_TYPES.register("invasion_zombie", () -> EntityType.Builder.of(InvasionZombieEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("invasion_zombie"));
    public static final DeferredHolder<EntityType<?>, EntityType<InvasionHuskEntity>> INVASION_HUSK = ENTITY_TYPES.register("invasion_husk", () -> EntityType.Builder.of(InvasionHuskEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("invasion_husk"));
    public static final DeferredHolder<EntityType<?>, EntityType<InvasionDrownedEntity>> INVASION_DROWNED = ENTITY_TYPES.register("invasion_drowned", () -> EntityType.Builder.of(InvasionDrownedEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("invasion_drowned"));
    public static final DeferredHolder<EntityType<?>, EntityType<SmallEmitterEntity>> SMALL_EMITTER = ENTITY_TYPES.register("small_emitter", () -> EntityType.Builder.of(SmallEmitterEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(12).updateInterval(1).build("small_emitter"));
    public static final DeferredHolder<EntityType<?>, EntityType<SmallEmitterSnowballEntity>> SMALL_EMITTER_SNOWBALL = ENTITY_TYPES.register("small_emitter_snowball", () -> EntityType.Builder.<SmallEmitterSnowballEntity>of((type, level) -> new SmallEmitterSnowballEntity(type, level), MobCategory.MISC).sized(0.25f, 0.25f).clientTrackingRange(8).updateInterval(1).build("small_emitter_snowball"));
    public static final DeferredHolder<EntityType<?>, EntityType<RollingSnowballEntity>> ROLLING_SNOWBALL = ENTITY_TYPES.register("rolling_snowball", () -> EntityType.Builder.<RollingSnowballEntity>of((type, level) -> new RollingSnowballEntity(type, level), MobCategory.MISC).sized(0.6f, 0.6f).clientTrackingRange(12).updateInterval(1).build("rolling_snowball"));
    public static final DeferredHolder<EntityType<?>, EntityType<CheatingVillagerEntity>> CHEATING_VILLAGER = ENTITY_TYPES.register("cheating_villager", () -> EntityType.Builder.of(CheatingVillagerEntity::new, MobCategory.CREATURE).sized(0.6f, 1.95f).clientTrackingRange(10).build("cheating_villager"));
    public static final DeferredHolder<EntityType<?>, EntityType<PoweredCartEntity>> POWERED_CART_ENTITY = ENTITY_TYPES.register("powered_cart", () -> EntityType.Builder.<PoweredCartEntity>of(PoweredCartEntity::new, MobCategory.MISC).sized(1.5f, 1.0f).clientTrackingRange(12).updateInterval(1).build("powered_cart"));
    public static final DeferredHolder<EntityType<?>, EntityType<RakeEntity>> RAKE = ENTITY_TYPES.register("rake", () -> EntityType.Builder.<RakeEntity>of(RakeEntity::new, MobCategory.MISC).sized(1.5f, 1.0f).clientTrackingRange(12).updateInterval(1).build("rake"));
     public static final DeferredHolder<EntityType<?>, EntityType<SniperEmitterEntity>> SNIPER_EMITTER = ENTITY_TYPES.register("sniper_emitter", () -> EntityType.Builder.of(SniperEmitterEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(16).updateInterval(1).build("sniper_emitter"));
     public static final DeferredHolder<EntityType<?>, EntityType<MoonlightSensorEntity>> MOONLIGHT_SENSOR = ENTITY_TYPES.register("moonlight_sensor", () -> EntityType.Builder.of(MoonlightSensorEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(12).updateInterval(1).build("moonlight_sensor"));
     public static final DeferredHolder<EntityType<?>, EntityType<GhostEntity>> GHOST = ENTITY_TYPES.register("ghost", () -> EntityType.Builder.of(GhostEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("ghost"));
     public static final DeferredHolder<EntityType<?>, EntityType<GlowstoneEntity>> GLOWSTONE = ENTITY_TYPES.register("glowstone_machine", () -> EntityType.Builder.of(GlowstoneEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(12).updateInterval(1).build("glowstone_machine"));
     public static final DeferredHolder<EntityType<?>, EntityType<GargoyleEntity>> GARGOYLE = ENTITY_TYPES.register("gargoyle", () -> EntityType.Builder.of(GargoyleEntity::new, MobCategory.MONSTER).sized(0.8f, 1.95f).clientTrackingRange(8).build("gargoyle"));
     // 狼人：人形态碰撞箱 0.6×1.95（变狼后由实体自身换成原版狼 0.6×0.85）。
     public static final DeferredHolder<EntityType<?>, EntityType<WerewolfEntity>> WEREWOLF = ENTITY_TYPES.register("werewolf", () -> EntityType.Builder.of(WerewolfEntity::new, MobCategory.MONSTER).sized(0.6f, 1.95f).clientTrackingRange(8).build("werewolf"));
     // 冲击活塞：大小与碰撞箱与黑曜石器械一致（0.9 × 1.0）。
     public static final DeferredHolder<EntityType<?>, EntityType<PunchPistonEntity>> PUNCH_PISTON = ENTITY_TYPES.register("punch_piston", () -> EntityType.Builder.of(PunchPistonEntity::new, MobCategory.MISC).sized(0.9f, 1.0f).clientTrackingRange(12).updateInterval(1).build("punch_piston"));
     // 飞刀投掷实体：尺寸与追踪参数同原版箭矢。
     public static final DeferredHolder<EntityType<?>, EntityType<ThrowingKnifeEntity>> THROWING_KNIFE_PROJECTILE = ENTITY_TYPES.register("throwing_knife_projectile", () -> EntityType.Builder.<ThrowingKnifeEntity>of(ThrowingKnifeEntity::new, MobCategory.MISC).sized(0.5f, 0.5f).clientTrackingRange(4).updateInterval(10).build("throwing_knife_projectile"));
     // 飞刀发射器：碰撞箱与追踪参数同发射器，血量 20 沿用器械基础属性。
     public static final DeferredHolder<EntityType<?>, EntityType<KnifeEmitterEntity>> KNIFE_EMITTER = ENTITY_TYPES.register("knife_emitter", () -> EntityType.Builder.of(KnifeEmitterEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(12).updateInterval(1).build("knife_emitter"));
     // 传染发射器：血量、碰撞箱、视野与攻击逻辑沿用小型发射器，射出寄生机器人。
     public static final DeferredHolder<EntityType<?>, EntityType<InfectenserEntity>> INFECTENSER = ENTITY_TYPES.register("infectenser", () -> EntityType.Builder.of(InfectenserEntity::new, MobCategory.MISC).sized(0.75f, 1.0f).clientTrackingRange(12).updateInterval(1).build("infectenser"));
     // 寄生机器人：传染发射器的弹射物，碰撞箱按 16×32 贴图比例设为 0.4 × 0.8。
     public static final DeferredHolder<EntityType<?>, EntityType<ParasiteBotEntity>> PARASITE_BOT = ENTITY_TYPES.register("parasite_bot", () -> EntityType.Builder.<ParasiteBotEntity>of((type, level) -> new ParasiteBotEntity(type, level), MobCategory.MISC).sized(0.4f, 0.8f).clientTrackingRange(8).updateInterval(1).build("parasite_bot"));
     // 机器寄染：被寄生机器人命中的敌人获得 30 秒的寄染状态，会向周围怪物发射寄生机器人。
     public static final DeferredHolder<MobEffect, MobEffect> MACHINE_PARASITE = MOB_EFFECTS.register("machine_parasite", MachineParasiteEffect::new);
      public static final DeferredHolder<MobEffect, MobEffect> REBELLION = MOB_EFFECTS.register("rebellion", RebellionEffect::new);

      private static PotionContents rebellionContents(int duration) {
          // visible=false：命中后不生成反逆效果的药水粒子（图标仍显示）。
          return new PotionContents(java.util.Optional.empty(), java.util.Optional.empty(),
                  List.of(new MobEffectInstance(REBELLION, duration, 0, false, false, true)));
      }

      public static final DeferredItem<PotionItem> HYPNO_POTION = ITEMS.register("hypno_potion",
              () -> new PotionItem(new Item.Properties().stacksTo(1)
                      .component(DataComponents.POTION_CONTENTS, rebellionContents(20 * 30))));
      public static final DeferredItem<ThrowablePotionItem> SPLASH_HYPNO_POTION = ITEMS.register("splash_hypno_potion",
              () -> new ThrowablePotionItem(new Item.Properties().stacksTo(1)
                      .component(DataComponents.POTION_CONTENTS, rebellionContents(20 * 30))));
      public static final DeferredItem<LingeringPotionItem> LINGERING_HYPNO_POTION = ITEMS.register("lingering_hypno_potion",
              () -> new LingeringPotionItem(new Item.Properties().stacksTo(1)
                      .component(DataComponents.POTION_CONTENTS, rebellionContents(20 * 30))));
     // 星之碎片：拾取后填入碎片槽；空手右键器械生物消耗 1 个使其激发潜能。
     public static final DeferredItem<StarShardItem> STAR_SHARD = ITEMS.register("star_shard", () -> new StarShardItem(new Item.Properties()));
     // 碎片槽位升级：与坑爹村民用 16 钻石换取，右键使碎片槽位 +1（上限 5）。
     public static final DeferredItem<ShardSlotUpgradeItem> SHARD_SLOT_UPGRADE = ITEMS.register("shard_slot_upgrade", () -> new ShardSlotUpgradeItem(new Item.Properties().stacksTo(16)));
     // 携带星之碎片的怪物标识：绿色药水效果，仅作绿光展示。
     public static final DeferredHolder<MobEffect, MobEffect> STAR_SHARD_CARRIER = MOB_EFFECTS.register("star_shard_carrier", StarShardCarrierEffect::new);
     // 炽炎熔炉：碰撞箱与外形大小沿用黑曜石器械（0.9 × 1.0），血量 20 用器械基础属性。
     public static final DeferredHolder<EntityType<?>, EntityType<SoulforgeEntity>> SOULFORGE = ENTITY_TYPES.register("soulforge", () -> EntityType.Builder.of(SoulforgeEntity::new, MobCategory.MISC).sized(0.9f, 1.0f).clientTrackingRange(12).updateInterval(1).build("soulforge"));
     // 炽炎弹：碰撞箱与可见弹体一致（3/4 方块，0.75 × 0.75），高频同步保证弹道平滑。
     public static final DeferredHolder<EntityType<?>, EntityType<SoulforgeFireballEntity>> SOULFORGE_FIREBALL = ENTITY_TYPES.register("soulforge_fireball", () -> EntityType.Builder.<SoulforgeFireballEntity>of((type, level) -> new SoulforgeFireballEntity(type, level), MobCategory.MISC).sized(0.75f, 0.75f).clientTrackingRange(8).updateInterval(1).build("soulforge_fireball"));
     public static final DeferredItem<GhostHelmetItem> GHOST_HELMET = ITEMS.register("ghost_helmet", () -> new GhostHelmetItem(new Item.Properties().stacksTo(1)));
     public static final DeferredItem<DeferredSpawnEggItem> GHOST_SPAWN_EGG = ITEMS.register("ghost_spawn_egg", () -> new DeferredSpawnEggItem(GHOST, 0xC8C8C8, 0xEEEEEE, new Item.Properties()));
     public static final DeferredItem<GargoyleSpawnEggItem> GARGOYLE_SPAWN_EGG = ITEMS.register("gargoyle_spawn_egg", () -> new GargoyleSpawnEggItem(GARGOYLE, new Item.Properties()));
     // 狼人刷怪蛋：使用用户提供的整张 16×16 贴图（白色乘色原样显示）。
     public static final DeferredItem<DeferredSpawnEggItem> WEREWOLF_SPAWN_EGG = ITEMS.register("werewolf_spawn_egg", () -> new WerewolfSpawnEggItem(WEREWOLF, new Item.Properties()));
     public static final DeferredItem<DeferredSpawnEggItem> INVASION_ZOMBIE_SPAWN_EGG = ITEMS.register("invasion_zombie_spawn_egg", () -> new DeferredSpawnEggItem(INVASION_ZOMBIE, 0x4CA33A, 0x8FBC5B, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> INVASION_HUSK_SPAWN_EGG = ITEMS.register("invasion_husk_spawn_egg", () -> new DeferredSpawnEggItem(INVASION_HUSK, 0xB89B72, 0xD4C39A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> INVASION_DROWNED_SPAWN_EGG = ITEMS.register("invasion_drowned_spawn_egg", () -> new DeferredSpawnEggItem(INVASION_DROWNED, 0x0F6B66, 0x3E9A91, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> CHEATING_VILLAGER_SPAWN_EGG = ITEMS.register("cheating_villager_spawn_egg", () -> new DeferredSpawnEggItem(CHEATING_VILLAGER, 0xD8C8A1, 0x463A67, new Item.Properties()));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MechanicalEnergyConverterBlockEntity>> MECHANICAL_ENERGY_CONVERTER_ENTITY = BLOCK_ENTITY_TYPES.register("mechanical_energy_converter", () -> BlockEntityType.Builder.of(MechanicalEnergyConverterBlockEntity::new, MECHANICAL_ENERGY_CONVERTER.get()).build(null));
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MineFieldBlockEntity>> MINE_FIELD_ENTITY = BLOCK_ENTITY_TYPES.register("mine_field", () -> BlockEntityType.Builder.of(MineFieldBlockEntity::new, MINE_FIELD.get()).build(null));
    public static final DeferredHolder<MenuType<?>, MenuType<ConverterMenu>> CONVERTER_MENU = MENUS.register("mechanical_energy_converter", () -> IMenuTypeExtension.create(ConverterMenu::new));
    public static final DeferredHolder<MenuType<?>, MenuType<MineFieldMenu>> MINE_FIELD_MENU = MENUS.register("mine_field", () -> IMenuTypeExtension.create(MineFieldMenu::new));

    public static final DeferredItem<BlueprintItem> EMITTER_BLUEPRINT = ITEMS.register("emitter_blueprint", () -> new BlueprintItem(new Item.Properties(), EMITTER.get(), 4, 100, 150, true));
    public static final DeferredItem<BlueprintItem> FURNACE_BLUEPRINT = ITEMS.register("furnace_blueprint", () -> new BlueprintItem(new Item.Properties(), FURNACE.get(), 2, 50, 150, true));
    public static final DeferredItem<BlueprintItem> OBSIDIAN_BLUEPRINT = ITEMS.register("obsidian_blueprint", () -> new BlueprintItem(new Item.Properties(), OBSIDIAN.get(), 2, 50, 600, true));
    public static final DeferredItem<BlueprintItem> MINE_TNT_BLUEPRINT = ITEMS.register("mine_tnt_blueprint", () -> new BlueprintItem(new Item.Properties(), MINE_TNT.get(), 1, 25, 600, net.minecraft.sounds.SoundEvents.GRASS_PLACE));
    public static final DeferredItem<BlueprintItem> SMALL_EMITTER_BLUEPRINT = ITEMS.register("small_emitter_blueprint", () -> new BlueprintItem(new Item.Properties(), SMALL_EMITTER.get(), 0, 0, 150, true));
    public static final DeferredItem<BlueprintItem> MOONLIGHT_SENSOR_BLUEPRINT = ITEMS.register("moonlight_sensor_blueprint", () -> new BlueprintItem(new Item.Properties(), MOONLIGHT_SENSOR.get(), 1, 25, 150, true));
     public static final DeferredItem<SniperBlueprintItem> SNIPER_EMITTER_BLUEPRINT = ITEMS.register("sniper_emitter_blueprint", () -> new SniperBlueprintItem(new Item.Properties()));
     // 飞刀发射器蓝图：消耗 150 机械能或 6 红石，冷却 7.5 秒（150 tick），放置音效同发射器（石头放置声）。
     public static final DeferredItem<BlueprintItem> KNIFE_EMITTER_BLUEPRINT = ITEMS.register("knife_emitter_blueprint", () -> new BlueprintItem(new Item.Properties(), KNIFE_EMITTER.get(), 6, 150, 150, true));
     // 传染发射器蓝图：右键小型发射器改造成传染发射器，固定 30 秒冷却，只能从坑爹村民处交易获得。
     public static final DeferredItem<InfectenserBlueprintItem> INFECTENSER_BLUEPRINT = ITEMS.register("infectenser_blueprint", () -> new InfectenserBlueprintItem(new Item.Properties()));
     public static final DeferredItem<BlueprintItem> GLOWSTONE_BLUEPRINT = ITEMS.register("glowstone_blueprint", () -> new BlueprintItem(new Item.Properties(), GLOWSTONE.get(), 1, 25, 600, true));
     // 冲击活塞蓝图：消耗 75 机械能或 3 红石，冷却 7.5 秒（150 tick）。
     public static final DeferredItem<PunchPistonBlueprintItem> PUNCH_PISTON_BLUEPRINT = ITEMS.register("punch_piston_blueprint", () -> new PunchPistonBlueprintItem(new Item.Properties(), PUNCH_PISTON.get(), 3, 75, 150));
     // 炽炎熔炉蓝图：消耗 225 机械能或 9 红石，冷却 7 秒（140 tick），放置器械生物炽炎熔炉。
     public static final DeferredItem<BlueprintItem> SOULFORGE_BLUEPRINT = ITEMS.register("soulforge_blueprint", () -> new BlueprintItem(new Item.Properties(), SOULFORGE.get(), 9, 225, 140, true));
    public static final DeferredHolder<SoundEvent, SoundEvent> FURNACE_REDSTONE_PICKUP = SOUND_EVENTS.register("furnace_redstone_pickup",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "furnace_redstone_pickup")));
    public static final DeferredHolder<SoundEvent, SoundEvent> EVOCATION = SOUND_EVENTS.register("evocation",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "evocation")));
    public static final DeferredHolder<SoundEvent, SoundEvent> SMALL_EMITTER_WAKEUP = SOUND_EVENTS.register("small_emitter_wakeup",
            () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "small_emitter_wakeup")));
     public static final DeferredHolder<SoundEvent, SoundEvent> SNIPER_EMITTER_LOCK = SOUND_EVENTS.register("sniper_emitter_lock",
             () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "sniper_emitter_lock")));
     public static final DeferredHolder<SoundEvent, SoundEvent> SNIPER_EMITTER_FIRE = SOUND_EVENTS.register("sniper_emitter_fire",
             () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "sniper_emitter_fire")));
     public static final DeferredHolder<SoundEvent, SoundEvent> MOONLIGHT_SENSOR_UPGRADE = SOUND_EVENTS.register("moonlight_sensor_upgrade",
             () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "moonlight_sensor_upgrade")));
     public static final DeferredHolder<SoundEvent, SoundEvent> GHOST_DEATH = SOUND_EVENTS.register("ghost_death",
             () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "ghost_death")));
     // 幽灵大腿处的白色粒子：外观为原版烟花火箭的火星（spark_0~7 贴图），小号纯白、匀速向下喷射
     //（渲染端见 client.GhostSparkParticle，材质 particles/ghost_spark.json）
     public static final DeferredHolder<ParticleType<?>, SimpleParticleType> GHOST_SPARK = PARTICLE_TYPES.register("ghost_spark",
             () -> new SimpleParticleType(false));
     // 石像鬼受击（sounds.json 内含两条素材，播放时随机取其一）与死亡音效
     public static final DeferredHolder<SoundEvent, SoundEvent> GARGOYLE_HURT = SOUND_EVENTS.register("gargoyle_hurt",
             () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "gargoyle_hurt")));
     public static final DeferredHolder<SoundEvent, SoundEvent> GARGOYLE_DEATH = SOUND_EVENTS.register("gargoyle_death",
             () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "gargoyle_death")));
      // 冲击活塞专属音效：放置（Stone3）、拆除与死亡（Stone4-2）、攻击（Punch），均为用户提供的素材转码。
      public static final DeferredHolder<SoundEvent, SoundEvent> PUNCH_PISTON_PLACE = SOUND_EVENTS.register("punch_piston_place",
              () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "punch_piston_place")));
      public static final DeferredHolder<SoundEvent, SoundEvent> PUNCH_PISTON_REMOVE = SOUND_EVENTS.register("punch_piston_remove",
              () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "punch_piston_remove")));
      public static final DeferredHolder<SoundEvent, SoundEvent> PUNCH_PISTON_PUNCH = SOUND_EVENTS.register("punch_piston_punch",
              () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "punch_piston_punch")));
      // 飞刀穿透生物时的挥斩音效（sounds.json 内含 Slice1/Slice2 两条素材，播放时随机取其一）
      public static final DeferredHolder<SoundEvent, SoundEvent> KNIFE_SLICE = SOUND_EVENTS.register("knife_slice",
              () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "knife_slice")));
      // 传染发射器激发潜能时的倒计时预警音效（用户提供的 Parabot_tick 采样）
      public static final DeferredHolder<SoundEvent, SoundEvent> PARABOT_TICK = SOUND_EVENTS.register("parabot_tick",
              () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "parabot_tick")));
      // 器械开火音效：狙击/小型/传染发射器用弓弦（Bow），发射器与飞刀发射器用枪声（Shot）
      public static final DeferredHolder<SoundEvent, SoundEvent> BOW_SHOT = SOUND_EVENTS.register("bow_shot",
              () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "bow_shot")));
      public static final DeferredHolder<SoundEvent, SoundEvent> GUN_SHOT = SOUND_EVENTS.register("gun_shot",
              () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(MOD_ID, "gun_shot")));


    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MACHINERY_TAB = CREATIVE_MODE_TABS.register("machinery_legend", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.machinery_legend"))
            .icon(() -> new ItemStack(ENERGY_GEAR.get()))
            .displayItems((parameters, output) -> {
                output.accept(ENERGY_GEAR.get());
                output.accept(MECHANICAL_ENERGY_CONVERTER_ITEM.get());
                 output.accept(MINE_FIELD_ITEM.get());
                output.accept(MACHINERY_PICKAXE.get());
                 output.accept(MACHINERY_RAKE.get());
                output.accept(MECHANICAL_ARM.get());
                output.accept(THROWING_KNIFE.get());
                output.accept(STAR_SHARD.get());
                output.accept(SHARD_SLOT_UPGRADE.get());
                 output.accept(HYPNO_POTION.get());
                 output.accept(SPLASH_HYPNO_POTION.get());
                 output.accept(LINGERING_HYPNO_POTION.get());
                 output.accept(BESTIARY.get());
                output.accept(BLANK_BLUEPRINT.get());
                output.accept(EMITTER_BLUEPRINT.get());
                output.accept(FURNACE_BLUEPRINT.get());
                output.accept(OBSIDIAN_BLUEPRINT.get());
                output.accept(MINE_TNT_BLUEPRINT.get());
                 output.accept(SMALL_EMITTER_BLUEPRINT.get());
                 output.accept(MOONLIGHT_SENSOR_BLUEPRINT.get());
                 output.accept(SNIPER_EMITTER_BLUEPRINT.get());
                 output.accept(KNIFE_EMITTER_BLUEPRINT.get());
                 output.accept(INFECTENSER_BLUEPRINT.get());
                 output.accept(GLOWSTONE_BLUEPRINT.get());
                 output.accept(PUNCH_PISTON_BLUEPRINT.get());
                 output.accept(SOULFORGE_BLUEPRINT.get());
                output.accept(INVASION_FLAG.get());
                 output.accept(POWERED_CART.get());
                output.accept(GHOST_HELMET.get());
                 output.accept(GHOST_SPAWN_EGG.get());
                 output.accept(INVASION_ZOMBIE_SPAWN_EGG.get());
                output.accept(INVASION_HUSK_SPAWN_EGG.get());
                output.accept(INVASION_DROWNED_SPAWN_EGG.get());
                 output.accept(CHEATING_VILLAGER_SPAWN_EGG.get());
                 output.accept(GARGOYLE_SPAWN_EGG.get());
                 output.accept(WEREWOLF_SPAWN_EGG.get());
            })
            .build());

    public GeneratedMod(IEventBus modBus) {
        ITEMS.register(modBus);
        BLOCKS.register(modBus);
        BLOCK_ENTITY_TYPES.register(modBus);
        MENUS.register(modBus);
        ENTITY_TYPES.register(modBus);
        SOUND_EVENTS.register(modBus);
        MOB_EFFECTS.register(modBus);
        PARTICLE_TYPES.register(modBus);
        CREATIVE_MODE_TABS.register(modBus);
        ATTACHMENT_TYPES.register(modBus);
        modBus.addListener(net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent.class, event -> event.registrar("1")
                .playToServer(RecordBestiaryPayload.TYPE, RecordBestiaryPayload.STREAM_CODEC, RecordBestiaryPayload::handle)
                 .playToServer(PlaceRakePayload.TYPE,
                         PlaceRakePayload.STREAM_CODEC,
                         PlaceRakePayload::handle));
        modBus.addListener(EnergyNetwork::register);
        modBus.addListener(net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent.class, event -> {
            event.put(EMITTER.get(), MachineryEntity.createAttributes().build());
            event.put(FURNACE.get(), MachineryEntity.createAttributes().build());
            event.put(OBSIDIAN.get(), ObsidianEntity.createAttributes().build());
            event.put(MINE_TNT.get(), MachineryEntity.createAttributes().build());
            event.put(INVASION_ZOMBIE.get(), InvasionZombieEntity.createAttributes().build());
            event.put(INVASION_HUSK.get(), InvasionHuskEntity.createAttributes().build());
            event.put(INVASION_DROWNED.get(), InvasionDrownedEntity.createAttributes().build());
            event.put(SMALL_EMITTER.get(), MachineryEntity.createAttributes().build());
             event.put(MOONLIGHT_SENSOR.get(), MachineryEntity.createAttributes().build());
             event.put(SNIPER_EMITTER.get(), MachineryEntity.createAttributes().build());
             // 飞刀发射器：血量 20、固定原地，与发射器同一套器械属性。
             event.put(KNIFE_EMITTER.get(), MachineryEntity.createAttributes().build());
             // 传染发射器：血量 20、碰撞箱与索敌同小型发射器，沿用器械基础属性。
             event.put(INFECTENSER.get(), MachineryEntity.createAttributes().build());
            event.put(CHEATING_VILLAGER.get(), CheatingVillagerEntity.createAttributes().build());
             event.put(GHOST.get(), GhostEntity.createAttributes().build());
             event.put(GLOWSTONE.get(), GlowstoneEntity.createAttributes().build());
             event.put(GARGOYLE.get(), GargoyleEntity.createAttributes().build());
             // 狼人：血量 35、僵尸速度、攻击力按难度实时刷 4/5/7
             event.put(WEREWOLF.get(), WerewolfEntity.createAttributes().build());
             // 冲击活塞：血量 20、固定原地，直接沿用器械基础属性。
             event.put(PUNCH_PISTON.get(), MachineryEntity.createAttributes().build());
             // 炽炎熔炉：血量 20、固定原地，直接沿用器械基础属性。
             event.put(SOULFORGE.get(), MachineryEntity.createAttributes().build());
        });
        modBus.addListener(net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent.class, event ->
                 event.register(GHOST.get(), net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND,
                         net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                         GhostEntity::checkGhostSpawnRules,
                         net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent.Operation.REPLACE));
        // 石像鬼：Y<40 的地下与夜间沼泽地表，两处判定都写在 checkGargoyleSpawnRules 内。
        modBus.addListener(net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent.class, event ->
                event.register(GARGOYLE.get(), net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND,
                        net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        GargoyleEntity::checkGargoyleSpawnRules,
                        net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent.Operation.REPLACE));
        // 狼人：满月地表或 Y<20 地下，两处判定都写在 checkWerewolfSpawnRules 内。
        modBus.addListener(net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent.class, event ->
                event.register(WEREWOLF.get(), net.minecraft.world.entity.SpawnPlacementTypes.ON_GROUND,
                        net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                        WerewolfEntity::checkWerewolfSpawnRules,
                        net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent.Operation.REPLACE));
         NeoForge.EVENT_BUS.register(GameEvents.class);
        // 催眠药水的酿造台配方（金苹果 + 粗制的药水；红石延长、火药/龙息升级为喷溅/滞留型）。
        NeoForge.EVENT_BUS.addListener(net.neoforged.neoforge.event.brewing.RegisterBrewingRecipesEvent.class,
                cn.blockforge.generated.machinerylegend.potion.HypnoBrewingRecipe::register);
        // 炽炎系光照方块的区块载入普查：旧存档里从没注册过自愈计划刻的残留灯由这条通道补上自愈机会。
        NeoForge.EVENT_BUS.register(SoulforgeLightResidualSweep.class);
    }
}
