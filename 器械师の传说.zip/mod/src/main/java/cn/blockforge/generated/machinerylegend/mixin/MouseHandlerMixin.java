package cn.blockforge.generated.machinerylegend.mixin;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.MouseHandler;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * 反逆期间的本地玩家鼠标左右键颠倒。
 *
 * <p>{@link MouseHandler#onPress} 同时承担按下与松开（action 1/0），统一把按钮 0 与 1 互换后，
 * 后续所有判定（攻击/使用、{@code isLeftPressed} 等）都会自然对调；中键与滚轮不受影响。</p>
 */
@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @ModifyVariable(method = "onPress(JIII)V", at = @At("HEAD"), argsOnly = true, index = 3)
    private int machineryLegend$invertMouseButtons(int button) {
        if (button != 0 && button != 1) return button;
        Player player = Minecraft.getInstance().player;
        if (player == null || !player.hasEffect(GeneratedMod.REBELLION)) return button;
        return button == 0 ? 1 : 0;
    }
}
