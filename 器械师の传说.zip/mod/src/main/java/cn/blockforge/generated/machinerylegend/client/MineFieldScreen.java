package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.menu.MineFieldMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 矿场库存界面，在原版漏斗界面空白处显示挖矿进度。 */
public final class MineFieldScreen extends AbstractContainerScreen<MineFieldMenu> {
    private static final ResourceLocation HOPPER_LOCATION = ResourceLocation.withDefaultNamespace("textures/gui/container/hopper.png");
    private static final int XP_EMPTY = 0xFF101010;
    private static final int XP_BORDER = 0xFF303030;
    private static final int XP_DARK = 0xFF1D7A1D;
    private static final int XP_LIGHT = 0xFF80FF20;

    public MineFieldScreen(MineFieldMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 176;
        imageHeight = 133;
        titleLabelX = 8;
        titleLabelY = 6;
        inventoryLabelX = 8;
        inventoryLabelY = 41;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;
        graphics.blit(HOPPER_LOCATION, x, y, 0, 0, imageWidth, imageHeight);

        // 经验条配色和高亮层次与原版经验条一致，放在漏斗槽位和玩家背包之间。
        int barX = x + 40;
        int barY = y + 42;
        int barWidth = 128;
        graphics.fill(barX, barY, barX + barWidth, barY + 7, XP_BORDER);
        graphics.fill(barX + 1, barY + 1, barX + barWidth - 1, barY + 6, XP_EMPTY);
        int progress = Math.max(0, Math.min(menu.getProgressMax(), menu.getProgress()));
        int filled = Math.round((barWidth - 2) * progress / (float) menu.getProgressMax());
        if (filled > 0) {
            graphics.fill(barX + 1, barY + 1, barX + 1 + filled, barY + 3, XP_LIGHT);
            graphics.fill(barX + 1, barY + 3, barX + 1 + filled, barY + 6, XP_DARK);
        }
    }
}
