package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderLivingEvent;

@EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.GAME)
public final class ClientGameEvents {
    /** 反胃效果用的那张屏幕边缘贴图，这里拿它做同一圈的品红滤镜。 */
    private static final ResourceLocation SCREEN_EDGE_TEXTURE =
            ResourceLocation.withDefaultNamespace("textures/misc/nausea.png");
    // 品红滤镜颜色（加法混合）：原版反胃是 (0.2, 0.4, 0.2) 的绿，这里换成 R/B 高、G 低的品红。
    private static final float FILTER_RED = 0.45F;
    private static final float FILTER_GREEN = 0.10F;
    private static final float FILTER_BLUE = 0.45F;

    private ClientGameEvents() {}

    @SubscribeEvent
    public static void clientTick(ClientTickEvent.Post event) {
        ClientEnergy.tick();
    }

    /**
     * 兜底挂载星之碎片绿光层：即使 EntityRenderersEvent.AddLayers 那条路径没有生效，
     * 这里也会在每次渲染活体之前把绿光层（幂等地）补上，当帧即可见。
     */
    @SubscribeEvent
    public static void ensureStarShardGlowLayer(RenderLivingEvent.Pre event) {
        StarShardGlowLayer.decorate(event.getRenderer());
    }

    /**
     * 玩家自己中反逆时，屏幕四周叠一圈品红滤镜，观感与反胃效果相同（同一张贴图 + 加法混合），
     * 只是颜色从绿换成品红。本地玩家身上的药水效果客户端一定拿得到，所以这里直接查 {@code hasEffect}。
     */
    @SubscribeEvent
    public static void renderRebellionScreenFilter(RenderGuiEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || !minecraft.player.hasEffect(GeneratedMod.REBELLION)) return;
        GuiGraphics graphics = event.getGuiGraphics();
        int width = graphics.guiWidth();
        int height = graphics.guiHeight();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        // 与反胃覆盖层一致：两个 ONE 的加法混合，把贴图颜色直接加到画面上。
        RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE,
                GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
        graphics.setColor(FILTER_RED, FILTER_GREEN, FILTER_BLUE, 1.0F);
        graphics.blit(SCREEN_EDGE_TEXTURE, 0, 0, -90, 0.0F, 0.0F, width, height, width, height);
        graphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
    }
}
