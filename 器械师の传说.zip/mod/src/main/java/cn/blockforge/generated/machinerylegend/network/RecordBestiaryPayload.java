package cn.blockforge.generated.machinerylegend.network;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.item.BestiaryItem;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

/** 客户端请求记录准心指向的敌对生物。服务端会重新验证目标。 */
public record RecordBestiaryPayload(int entityId) implements CustomPacketPayload {
    public static final Type<RecordBestiaryPayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "record_bestiary"));
    public static final StreamCodec<io.netty.buffer.ByteBuf, RecordBestiaryPayload> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, RecordBestiaryPayload::entityId, RecordBestiaryPayload::new);

    @Override
    public Type<RecordBestiaryPayload> type() {
        return TYPE;
    }

    public static void handle(RecordBestiaryPayload payload,
                              net.neoforged.neoforge.network.handling.IPayloadContext context) {
        context.enqueueWork(() -> {
            if (context.player() instanceof ServerPlayer player) {
                BestiaryItem.recordTarget(player, payload.entityId());
            }
        });
    }
}
