package cn.blockforge.generated.machinerylegend.block;

/** 荧石器械本体所处的隐形光照方块，向周围提供荧石等级的 15 级光照。 */
public class GlowstoneLightBlock extends MachineryLightBlock {
    public GlowstoneLightBlock(Properties properties) {
        super(properties);
    }
}
