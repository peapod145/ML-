package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.entity.PoweredCartEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MinecartRenderer;
import net.minecraft.client.model.geom.ModelLayers;

/** 使用原版动力矿车模型渲染动力推车，并将可见高度调整为约 0.8 格。 */
public final class PoweredCartRenderer extends MinecartRenderer<PoweredCartEntity> {
    public PoweredCartRenderer(EntityRendererProvider.Context context) {
        super(context, ModelLayers.FURNACE_MINECART);
        this.shadowRadius = 0.45f;
    }

    @Override
    public void render(PoweredCartEntity entity, float yaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int light) {
        poseStack.pushPose();
        // 原版动力矿车连同炉体顶端约为 1.03125 格，纵向缩放后可见高度约为 0.8 格。
        poseStack.scale(1.0f, 0.775f, 1.0f);
        super.render(entity, yaw, partialTick, poseStack, buffer, light);
        poseStack.popPose();
    }
}
