package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.entity.CheatingVillagerEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.CrossedArmsItemLayer;
import net.minecraft.client.renderer.entity.layers.CustomHeadLayer;
import net.minecraft.resources.ResourceLocation;

/**
 * 坑爹村民的专用渲染器：把原版村民模型直接绘制成用户提供的整张贴图
 * （头/身/臂/腿 + 帽/外套壳层），不叠加原版职业服装层，因此保留原版村民
 * 的交互与僵尸行为，只替换外观贴图。
 *
 * 本次调整：隐藏帽子壳层。原版 VillagerModel 的 {@code hat}（UV 32,0）与
 * {@code hat_rim}（UV 30,47）是罩在头上的帽与帽檐，单独把它们设为不可见即可，
 * 头部几何（UV 0,0）保持不变。注意不能用 {@code hatVisible(false)}，它会连
 * {@code head} 一起隐藏，导致没有头。
 */
public class CheatingVillagerRenderer extends MobRenderer<CheatingVillagerEntity, VillagerModel<CheatingVillagerEntity>> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "textures/entity/villager/cheating_villager.png");

    public CheatingVillagerRenderer(EntityRendererProvider.Context context) {
        super(context, new VillagerModel<>(context.bakeLayer(ModelLayers.VILLAGER)), 0.5F);
        // 保留原版村民的头部挂件层与交叉抱臂层，去掉职业服装叠加层（贴图已含服装）。
        this.addLayer(new CustomHeadLayer<>(this, context.getModelSet(), context.getItemInHandRenderer()));
        this.addLayer(new CrossedArmsItemLayer<>(this, context.getItemInHandRenderer()));
        // 隐藏帽子壳层：只藏 hat 与 hat_rim，不动 head。
        // 注意：原版 VillagerModel 里 hat 挂在 head 下、hat_rim 挂在 hat 下，
        // 直接从 root 取 "hat" 会拿到 null（正是此前资源重载时抛 NPE 卡加载界面的原因）。
        ModelPart head = this.model.root().getChild("head");
        if (head != null) {
            ModelPart hat = head.getChild("hat");
            if (hat != null) {
                hat.visible = false;
                ModelPart hatRim = hat.getChild("hat_rim");
                if (hatRim != null) {
                    hatRim.visible = false;
                }
            }
        }
    }

    @Override
    public ResourceLocation getTextureLocation(CheatingVillagerEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(CheatingVillagerEntity entity, PoseStack poseStack, float partialTick) {
        float scale = 0.9375F * entity.getAgeScale();
        poseStack.scale(scale, scale, scale);
    }

    @Override
    protected float getShadowRadius(CheatingVillagerEntity entity) {
        float radius = super.getShadowRadius(entity);
        if (entity.isBaby()) {
            radius *= 0.5F;
        }
        return radius;
    }
}
