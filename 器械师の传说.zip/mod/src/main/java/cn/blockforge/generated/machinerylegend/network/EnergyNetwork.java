package cn.blockforge.generated.machinerylegend.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

public final class EnergyNetwork {
    private EnergyNetwork() {}
    public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("1")
                .playToClient(EnergySyncPayload.TYPE, EnergySyncPayload.STREAM_CODEC, EnergySyncPayload::handle)
                .playToClient(ShardSyncPayload.TYPE, ShardSyncPayload.STREAM_CODEC, ShardSyncPayload::handle);
    }
}
