package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.effect.RebellionLogic;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerLevel;

/** 地雷TNT：先埋藏，15秒后出土；敌对生物触碰时无地形爆炸。 */
public class MineTntEntity extends MachineryEntity {
    private static final int EMERGE_TICKS = 300;
    private static final int EMERGE_ANIMATION_TICKS = 24;
    private static final float DAMAGE = 120.0f;
    private static final double TRIGGER_RADIUS = 1.0;
    private static final String EMERGED_TAG = "Emerged";
    private static final EntityDataAccessor<Boolean> DATA_EMERGED = SynchedEntityData.defineId(MineTntEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_EMERGE_TICKS_LEFT = SynchedEntityData.defineId(MineTntEntity.class, EntityDataSerializers.INT);
    private boolean emerged;
    private boolean detonated;

    public MineTntEntity(EntityType<? extends MineTntEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_EMERGED, false);
        builder.define(DATA_EMERGE_TICKS_LEFT, 0);
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.TNT.defaultBlockState();
    }

    @Override
    protected boolean hasOffensiveCapability() {
        // 地雷TNT出土后对触碰的敌对生物造成爆炸伤害，具备攻击能力，保留原有索敌行为。
        return true;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || detonated) return;

        if (!emerged && tickCount >= EMERGE_TICKS) {
            emerged = true;
            entityData.set(DATA_EMERGED, true);
            entityData.set(DATA_EMERGE_TICKS_LEFT, EMERGE_ANIMATION_TICKS);
            spawnEmergenceParticles();
        } else if (emerged) {
            int ticksLeft = entityData.get(DATA_EMERGE_TICKS_LEFT);
            if (ticksLeft > 0) entityData.set(DATA_EMERGE_TICKS_LEFT, ticksLeft - 1);
        }
        if (!emerged) return;

        LivingEntity touchingHostile = level().getEntitiesOfClass(LivingEntity.class,
                        getBoundingBox().inflate(0.08), entity ->
                                entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity))
                .stream().min((a, b) -> Double.compare(distanceToSqr(a), distanceToSqr(b))).orElse(null);
        if (touchingHostile != null) detonate();
    }

    private void detonate() {
        if (detonated || level().isClientSide) return;
        detonated = true;

        var explosion = level().explode(this, getX(), getY() + 0.15, getZ(), 0.0f, false,
                Level.ExplosionInteraction.NONE);
        level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(TRIGGER_RADIUS), entity ->
                        entity != this && entity.isAlive() && RebellionLogic.canMachineAttack(this, entity))
                .forEach(entity -> hurtIgnoringInvulnerability(entity, level().damageSources().explosion(explosion), DAMAGE));

        if (level() instanceof ServerLevel serverLevel) {
            BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, net.minecraft.world.level.block.Blocks.DIRT.defaultBlockState());
            BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
            serverLevel.sendParticles(dirt, getX(), getY() + 0.35, getZ(), 18, 0.45, 0.35, 0.45, 0.18);
            serverLevel.sendParticles(stone, getX(), getY() + 0.4, getZ(), 12, 0.4, 0.3, 0.4, 0.2);
        }
        discard();
    }

    public boolean isEmerged() {
        return entityData.get(DATA_EMERGED);
    }

    /** 返回出土动画进度，0 是完全埋藏，1 是完全出土。 */
    public float getEmergeProgress(float partialTick) {
        if (!isEmerged()) return 0.0f;
        int ticksLeft = entityData.get(DATA_EMERGE_TICKS_LEFT);
        if (ticksLeft <= 0) return 1.0f;
        float progress = 1.0f - (ticksLeft - partialTick) / (float) EMERGE_ANIMATION_TICKS;
        return Math.max(0.0f, Math.min(1.0f, progress));
    }

    private void spawnEmergenceParticles() {
        if (!(level() instanceof ServerLevel serverLevel)) return;
        BlockParticleOption dirt = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState());
        BlockParticleOption stone = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState());
        serverLevel.sendParticles(dirt, getX(), getY() + 0.18, getZ(), 20, 0.45, 0.18, 0.45, 0.16);
        serverLevel.sendParticles(stone, getX(), getY() + 0.25, getZ(), 8, 0.35, 0.20, 0.35, 0.12);
    }

    public void setEmerged(boolean emerged) {
        this.emerged = emerged;
        entityData.set(DATA_EMERGED, emerged);
        // 读档时保持已经完成的状态，不重复播放出土动画。
        entityData.set(DATA_EMERGE_TICKS_LEFT, 0);
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide) return;
        if (!isEmerged()) setEmerged(true);
        startEvocationEffect();
        int count = 2 + random.nextInt(2);
        for (int i = 0; i < count; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = 2.0 + random.nextDouble() * 8.0;
            double x = getX() + Math.cos(angle) * distance;
            double z = getZ() + Math.sin(angle) * distance;
            double vx = Math.cos(angle) * (0.18 + random.nextDouble() * 0.18);
            double vz = Math.sin(angle) * (0.18 + random.nextDouble() * 0.18);
            ItemEntity tnt = new ItemEntity(level(), x, getY() + 0.7, z,
                    new ItemStack(Items.TNT), vx, 0.48 + random.nextDouble() * 0.18, vz);
            tnt.getPersistentData().putBoolean("machinery_legend_mine_tnt_drop", true);
            tnt.setPickUpDelay(40);
            tnt.lifespan = 1200;
            level().addFreshEntity(tnt);
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean(EMERGED_TAG, emerged);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setEmerged(tag.getBoolean(EMERGED_TAG));
    }
}
