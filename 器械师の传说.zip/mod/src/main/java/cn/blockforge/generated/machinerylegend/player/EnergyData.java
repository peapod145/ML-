package cn.blockforge.generated.machinerylegend.player;

import cn.blockforge.generated.machinerylegend.network.EnergySyncPayload;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.PacketDistributor;

public final class EnergyData {
    public static final int MAX_ENERGY = 10000;
    private static final String ENERGY_KEY = "machinery_legend_energy";
    private static final String FLASH_KEY = "machinery_legend_energy_flash";

    private EnergyData() {}

    public static int get(Player player) {
        return player.getPersistentData().getInt(ENERGY_KEY);
    }

    public static void set(Player player, int amount) {
        player.getPersistentData().putInt(ENERGY_KEY, Math.max(0, Math.min(MAX_ENERGY, amount)));
        sync(player, 0);
    }

    public static boolean consume(Player player, int amount) {
        if (get(player) < amount) return false;
        set(player, get(player) - amount);
        return true;
    }

    public static void add(Player player, int amount) {
        set(player, get(player) + amount);
    }

    public static boolean consumeEnergyOrRedstone(Player player, int redstone, int energy) {
        if (get(player) >= energy) {
            consume(player, energy);
            return true;
        }
        int found = countRedstone(player);
        if (found < redstone) return false;
        removeRedstone(player, redstone);
        return true;
    }

    public static void flashInsufficient(Player player, String key) {
        player.getPersistentData().putInt(FLASH_KEY, 20);
        player.displayClientMessage(Component.translatable(key), true);
        sync(player, 20);
    }

    public static void tick(Player player) {
        CompoundTag data = player.getPersistentData();
        int flash = data.getInt(FLASH_KEY);
        if (flash > 0) data.putInt(FLASH_KEY, flash - 1);
        if (player instanceof ServerPlayer serverPlayer && player.tickCount % 10 == 0) sync(serverPlayer, flash);
    }

    public static void sync(Player player, int flashTicks) {
        if (player instanceof ServerPlayer serverPlayer) {
            PacketDistributor.sendToPlayer(serverPlayer, new EnergySyncPayload(get(player), flashTicks));
        }
    }

    public static int countRedstone(Player player) {
        int count = 0;
        for (ItemStack stack : player.getInventory().items) if (stack.is(Items.REDSTONE)) count += stack.getCount();
        return count;
    }

    public static void removeRedstone(Player player, int amount) {
        int remaining = amount;
        for (int i = 0; i < player.getInventory().items.size() && remaining > 0; i++) {
            ItemStack stack = player.getInventory().items.get(i);
            if (stack.is(Items.REDSTONE)) {
                int removed = Math.min(remaining, stack.getCount());
                stack.shrink(removed);
                remaining -= removed;
            }
        }
        player.getInventory().setChanged();
    }
}
