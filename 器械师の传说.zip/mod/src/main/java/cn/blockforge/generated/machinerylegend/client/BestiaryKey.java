package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.network.RecordBestiaryPayload;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.world.phys.EntityHitResult;

@EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class BestiaryKey {
    public static final KeyMapping RECORD_KEY = new KeyMapping(
            "key.machinery_legend.record_bestiary", InputConstants.Type.KEYSYM,
            InputConstants.KEY_Y, "key.categories.machinery_legend");

    private BestiaryKey() {}

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(RECORD_KEY);
    }

    @EventBusSubscriber(modid = GeneratedMod.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.GAME)
    public static final class Tick {
        private Tick() {}

        @SubscribeEvent
        public static void clientTick(ClientTickEvent.Post event) {
            while (RECORD_KEY.consumeClick()) {
                Minecraft minecraft = Minecraft.getInstance();
                if (minecraft.player == null || minecraft.level == null || minecraft.screen != null) continue;
                if (!cn.blockforge.generated.machinerylegend.item.BestiaryItem.isActive(minecraft.player)) continue;
                if (minecraft.hitResult instanceof EntityHitResult hit
                        && hit.getEntity() instanceof LivingEntity living
                        && living instanceof Enemy && living.isAlive()) {
                    PacketDistributor.sendToServer(new RecordBestiaryPayload(living.getId()));
                }
            }
        }
    }
}
