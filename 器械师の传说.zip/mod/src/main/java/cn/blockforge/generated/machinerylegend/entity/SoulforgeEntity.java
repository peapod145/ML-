package cn.blockforge.generated.machinerylegend.entity;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * 炽炎熔炉：整体是一只散发少量原版火焰粒子的南瓜灯，白天睡觉时换成雕刻南瓜且停发粒子。
 * 碰撞箱与外形大小沿用黑曜石器械（0.9 × 1.0），血量 20；白天睡觉、荧石粉唤醒与下界之星
 * 激发潜能等夜间器械逻辑直接继承小型发射器。
 *
 * <p>索敌、视野与攻击节奏对齐发射器：15 格射程、28 刻一发、开火用发射器同款枪声采样，
 * 弹体换成直线飞行的炽炎弹（命中 4 点伤害并点燃 5 秒，见 {@link SoulforgeFireballEntity}）。</p>
 *
 * <p>激发潜能：向前方按左右交替的正弦波射出共 60 发炽炎弹（每 2 刻一发），
 * 偏角为 sin(波次位置 × 2π/8) × 45°，波峰恰为 ±45°，
 * 左右两端弹道与枪口连线的夹角即 90°。</p>
 *
 * <p>发光逻辑与荧石器械相同：所在格是空气时放置 14 级隐形光照方块，离开时清除。</p>
 */
public class SoulforgeEntity extends SmallEmitterEntity {
    /** 攻击参数对齐发射器：射程 15 格、28 刻一发。 */
    private static final double ATTACK_RANGE = 15.0;
    private static final int SHOT_COOLDOWN = 28;
    /** 炽炎弹直线飞行速度。 */
    private static final float FIREBALL_SPEED = 1.5f;
    /** 南瓜灯占 0.9 格立方体，枪口取正面中心略高处。 */
    private static final double MUZZLE_Y_OFFSET = 0.52;
    private static final double MUZZLE_FORWARD_OFFSET = 0.5;
    /** 激发潜能：共 60 发、每 2 刻一发。 */
    private static final int EMPOWERED_SHOTS = 60;
    private static final int EMPOWERED_INTERVAL = 2;
    /** 波形周期 8 发：sin 波峰恰好落在 ±45°，左右两端弹道夹角 90°。 */
    private static final int WAVE_PERIOD_SHOTS = 8;
    private static final double WAVE_MAX_DEVIATION = Math.PI / 4.0;

    private int empoweredShots;
    private int empoweredIntervalCooldown;
    /** 跟着本体走的一格隐形光照方块（14 级）。 */
    private final BodyLightTracker light = new BodyLightTracker(this, GeneratedMod.SOULFORGE_LIGHT.get());

    public SoulforgeEntity(EntityType<? extends SoulforgeEntity> type, Level level) {
        super(type, level);
        normalAttackRange = ATTACK_RANGE;
        normalCooldown = SHOT_COOLDOWN;
    }

    @Override
    protected BlockState getDeathParticleState() {
        return Blocks.JACK_O_LANTERN.defaultBlockState();
    }

    /** 视野逻辑对齐发射器：方形 15 格搜索盒（小型发射器父类是圆形，这里改回发射器的方形判定）。 */
    @Override
    protected LivingEntity findTarget() {
        return findTarget(ATTACK_RANGE, false);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            tickFlameParticles();
            return;
        }
        // 强化波次因白天休眠等中断而未射满时清场，避免残留计数挡住下一次激发。
        if (empoweredTicks <= 0 && empoweredShots > 0) {
            empoweredShots = 0;
            empoweredIntervalCooldown = 0;
        }
        // 已被移除（kill()/死亡/区块卸载）的实体不再维护光照，防止边清场边重新放灯。
        if (isRemoved()) {
            light.clear();
            return;
        }
        light.update();
    }

    /** 客户端：清醒的南瓜灯持续散发少量原版火焰粒子；睡觉（雕刻南瓜）时不散发。 */
    private void tickFlameParticles() {
        if (shouldRenderSleepingIndicator()) return;
        if (tickCount % 6 != 0) return;
        level().addParticle(ParticleTypes.FLAME,
                getX() + (random.nextDouble() - 0.5) * 0.84,
                getY() + 0.3 + random.nextDouble() * 0.55,
                getZ() + (random.nextDouble() - 0.5) * 0.84,
                0.0, 0.02 + random.nextDouble() * 0.02, 0.0);
    }

    /** 普通攻击：向目标射出一发炽炎弹（直线、带少量移动预判）。 */
    @Override
    protected void fireProjectile(LivingEntity target) {
        // 目标可能已在同刻被其它伤害带走，先做存活校验再取位置。
        if (target.isRemoved() || !target.isAlive()) return;
        Vec3 forward = horizontalForward();
        Vec3 start = new Vec3(getX(), getY() + MUZZLE_Y_OFFSET, getZ()).add(forward.scale(MUZZLE_FORWARD_OFFSET));
        Vec3 aim = aimAtTarget(target, start);
        SoulforgeFireballEntity bolt = new SoulforgeFireballEntity(
                GeneratedMod.SOULFORGE_FIREBALL.get(), this, level(), 0, -1);
        bolt.setPos(start);
        bolt.shoot(aim.x, aim.y, aim.z, FIREBALL_SPEED, 0.0f);
        level().addFreshEntity(bolt);
    }

    /** 直线弹道：瞄准目标身体中心，并按飞行耗时对移动目标做少量预判。 */
    private Vec3 aimAtTarget(LivingEntity target, Vec3 start) {
        Vec3 center = new Vec3(target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ());
        Vec3 motion = target.getDeltaMovement();
        double flightTicks = Math.min(10.0, Math.max(1.0, start.distanceTo(center) / FIREBALL_SPEED));
        Vec3 predicted = center.add(motion.x * flightTicks, motion.y * flightTicks * 0.5, motion.z * flightTicks);
        return predicted.subtract(start).normalize();
    }

    /** 攻击表现对齐发射器：开火使用发射器同款枪声采样。 */
    @Override
    protected void playBowShot() {
        level().playSound(null, blockPosition(), GeneratedMod.GUN_SHOT.get(), SoundSource.HOSTILE, 1.0f, 1.0f);
    }

    @Override
    public void triggerEmpowered() {
        if (level().isClientSide || isDaySleeping() || empoweredShots > 0) return;
        startEvocationEffect();
        empoweredTicks = EMPOWERED_DURATION;
        empoweredShots = EMPOWERED_SHOTS;
        empoweredIntervalCooldown = 0;
    }

    /**
     * 激发潜能弹道：共 60 发、每 2 刻沿正前方射出一发炽炎弹；
     * 偏角取 sin(波次位置 × 2π/8) × 45°，左右交替、波峰恰为 ±45°，
     * 左右两端弹道与枪口连线的夹角即 90°。
     */
    @Override
    protected void tickEmpowered() {
        if (empoweredShots <= 0) {
            empoweredTicks = 0;
            return;
        }
        if (empoweredIntervalCooldown > 0) {
            empoweredIntervalCooldown--;
            return;
        }
        int index = EMPOWERED_SHOTS - empoweredShots;
        double deviation = WAVE_MAX_DEVIATION * Math.sin(index * (2.0 * Math.PI / WAVE_PERIOD_SHOTS));
        Vec3 direction = rotateYaw(horizontalForward(), deviation);
        Vec3 start = new Vec3(getX(), getY() + MUZZLE_Y_OFFSET, getZ()).add(direction.scale(MUZZLE_FORWARD_OFFSET));
        SoulforgeFireballEntity bolt = new SoulforgeFireballEntity(
                GeneratedMod.SOULFORGE_FIREBALL.get(), this, level(), 0, -1);
        bolt.setPos(start);
        bolt.shoot(direction.x, direction.y, direction.z, FIREBALL_SPEED, 0.0f);
        level().addFreshEntity(bolt);
        playBowShot();
        empoweredShots--;
        empoweredIntervalCooldown = EMPOWERED_INTERVAL;
    }

    /** 绕竖直轴旋转方向向量（radians>0 为向右手侧偏转），供本器械波形与炽炎弹分裂共用。 */
    static Vec3 rotateYaw(Vec3 direction, double radians) {
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        return new Vec3(direction.x * cos + direction.z * sin, direction.y,
                -direction.x * sin + direction.z * cos).normalize();
    }

    /**
     * 覆盖 kill()/死亡/区块卸载等一切把实体踢出世界的移除路径。原版只按 onRemovedFromLevel
     * 通知撤灯，缺了这一步，被杀死的器械的 14 级光照方块会残留进存档，重载后变成无人认领
     * 的悬空灯（旧存档里残留光源的成因之一）。此刻 getRemovalReason() 已由 setRemoved 写好。
     */
    @Override
    public void onRemovedFromLevel() {
        super.onRemovedFromLevel();
        if (level().isClientSide) return;
        Entity.RemovalReason reason = getRemovalReason();
        // 真正销毁（死亡、kill()、跨维度传送）才撤灯；因区块卸载而暂存时，光照方块随实体一起存盘，
        // 这里只复位引用，重载后由 light.update() 重新接管。
        if (reason == Entity.RemovalReason.CHANGED_DIMENSION
                || (reason != null && reason.shouldDestroy())) {
            light.clear();
        } else {
            light.forget();
        }
        empoweredTicks = 0;
        empoweredShots = 0;
        empoweredIntervalCooldown = 0;
    }

    /** 激发潜能属于瞬时表现：不写进存档，避免重进后接着上一轮波次继续刷弹。 */
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("empoweredTicks", 0);
        tag.putInt("empoweredShots", 0);
        tag.putInt("empoweredIntervalCooldown", 0);
    }
}
