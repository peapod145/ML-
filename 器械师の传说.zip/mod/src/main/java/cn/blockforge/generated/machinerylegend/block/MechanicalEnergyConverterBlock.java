package cn.blockforge.generated.machinerylegend.block;

import cn.blockforge.generated.machinerylegend.menu.ConverterMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.neoforged.neoforge.common.util.FakePlayer;
import com.mojang.serialization.MapCodec;

/** 机械能转化器：输入库存属于当前打开界面的玩家，不在方块之间共享。 */
public final class MechanicalEnergyConverterBlock extends BaseEntityBlock {
    public static final MapCodec<MechanicalEnergyConverterBlock> CODEC = simpleCodec(MechanicalEnergyConverterBlock::new);

    public MechanicalEnergyConverterBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new MechanicalEnergyConverterBlockEntity(pos, state);
    }

    private InteractionResult openConverter(Level level, BlockPos pos, Player player) {
        if (player instanceof FakePlayer) return InteractionResult.PASS;
        if (!level.isClientSide && player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            serverPlayer.openMenu(new net.minecraft.world.SimpleMenuProvider(
                    (id, inventory, ignored) -> new ConverterMenu(id, inventory, pos),
                    Component.translatable("container.machinery_legend.mechanical_energy_converter")), buf -> buf.writeBlockPos(pos));
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return openConverter(level, pos, player);
    }

    @Override
    protected ItemInteractionResult useItemOn(net.minecraft.world.item.ItemStack stack, BlockState state, Level level,
                                               BlockPos pos, Player player, net.minecraft.world.InteractionHand hand,
                                               BlockHitResult hit) {
        return ItemInteractionResult.sidedSuccess(openConverter(level, pos, player) == InteractionResult.SUCCESS || level.isClientSide);
    }
}
