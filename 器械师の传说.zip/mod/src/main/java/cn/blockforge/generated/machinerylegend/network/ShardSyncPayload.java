package cn.blockforge.generated.machinerylegend.network;

import cn.blockforge.generated.machinerylegend.GeneratedMod;
import cn.blockforge.generated.machinerylegend.client.ClientShards;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** 服务端 -> 客户端：同步碎片槽的当前碎片数与槽位数，供右侧 HUD 显示。 */
public record ShardSyncPayload(int count, int slots) implements CustomPacketPayload {
    public static final Type<ShardSyncPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(GeneratedMod.MOD_ID, "shard_sync"));
    public static final StreamCodec<io.netty.buffer.ByteBuf, ShardSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShardSyncPayload::count,
            ByteBufCodecs.VAR_INT, ShardSyncPayload::slots,
            ShardSyncPayload::new);

    @Override
    public Type<ShardSyncPayload> type() { return TYPE; }

    public static void handle(ShardSyncPayload payload, net.neoforged.neoforge.network.handling.IPayloadContext context) {
        context.enqueueWork(() -> ClientShards.set(payload.count(), payload.slots()));
    }
}
