package cn.blockforge.generated.machinerylegend.client;

import cn.blockforge.generated.machinerylegend.menu.ConverterMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;

/** 机械能转化器界面：采用自绘的浅色容器布局，并提供转换信息。 */
public final class ConverterScreen extends AbstractContainerScreen<ConverterMenu> {
    private static final int PANEL_OUTER = 0xFF9A9A9A;
    private static final int PANEL_BORDER = 0xFFE9E9E9;
    private static final int PANEL_SURFACE = 0xFFF7F7F7;
    private static final int PANEL_INNER = 0xFFD6D6D6;
    private static final int SLOT_EDGE = 0xFF858585;
    private static final int SLOT_SURFACE = 0xFFECECEC;
    private static final int ENERGY_EMPTY = 0xFF777777;
    private static final int ENERGY_DARK = 0xFF277A55;
    private static final int ENERGY_LIGHT = 0xFF56C7A2;
    private Button convertButton;

    public ConverterScreen(ConverterMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 176;
        imageHeight = 166;
        titleLabelX = 8;
        titleLabelY = 6;
        inventoryLabelX = 8;
        inventoryLabelY = 74;
    }

    @Override
    protected void init() {
        super.init();
        convertButton = addRenderableWidget(Button.builder(
                        Component.translatable("gui.machinery_legend.converter_button"),
                        button -> {
                            if (Minecraft.getInstance().gameMode != null) {
                                Minecraft.getInstance().gameMode.handleInventoryButtonClick(menu.containerId, ConverterMenu.CONVERT_BUTTON);
                            }
                        })
                .bounds(leftPos + 108, topPos + 50, 60, 20)
                .build());
        updateButtonState();
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        updateButtonState();
    }

    private void updateButtonState() {
        if (convertButton == null) return;
        convertButton.active = !menu.isAutoMode() && menu.getInputConversionValue() > 0 && menu.getEnergy() < menu.getMaxEnergy();
        convertButton.setMessage(Component.translatable(menu.isAutoMode()
                ? "gui.machinery_legend.converter_button_auto"
                : "gui.machinery_legend.converter_button"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        int x = leftPos;
        int y = topPos;

        // 自绘浅色容器面板，不调用任何原版工作方块界面贴图。
        graphics.fill(x, y, x + imageWidth, y + imageHeight, PANEL_OUTER);
        graphics.fill(x + 1, y + 1, x + imageWidth - 1, y + imageHeight - 1, PANEL_BORDER);
        graphics.fill(x + 2, y + 2, x + imageWidth - 2, y + 72, PANEL_SURFACE);
        graphics.fill(x + 2, y + 74, x + imageWidth - 2, y + imageHeight - 2, PANEL_SURFACE);
        graphics.fill(x + 4, y + 18, x + 172, y + 72, PANEL_INNER);
        graphics.fill(x + 4, y + 82, x + 172, y + 138, PANEL_INNER);
        graphics.fill(x + 4, y + 140, x + 172, y + 164, PANEL_INNER);
        graphics.fill(x + 5, y + 19, x + 170, y + 20, 0xFFB8B8B8);
        graphics.fill(x + 5, y + 71, x + 170, y + 73, 0xFFB8B8B8);
        graphics.fill(x + 5, y + 138, x + 170, y + 140, 0xFFB8B8B8);

        drawSlot(graphics, x + 56, y + 17);
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 9; column++) {
                drawSlot(graphics, x + 8 + column * 18, y + 84 + row * 18);
            }
        }
        for (int column = 0; column < 9; column++) {
            drawSlot(graphics, x + 8 + column * 18, y + 142);
        }

        int barX = x + 112;
        int barY = y + 39;
        int barWidth = 32;
        graphics.fill(barX, barY, barX + barWidth, barY + 7, ENERGY_EMPTY);
        int maxEnergy = Math.max(1, menu.getMaxEnergy());
        int filled = Math.min(barWidth - 2, Math.round((barWidth - 2) * menu.getEnergy() / (float) maxEnergy));
        if (filled > 0) {
            graphics.fill(barX + 1, barY + 1, barX + 1 + filled, barY + 3, ENERGY_LIGHT);
            graphics.fill(barX + 1, barY + 3, barX + 1 + filled, barY + 6, ENERGY_DARK);
        }

        // 红石信号灯：无信号时熄灭，有信号时亮红，直观提示自动转换状态。
        int lampColor = menu.getRedstoneSignal() > 0 ? 0xFFE04432 : 0xFFB98B86;
        graphics.fill(x + 102, y + 48, x + 108, y + 54, 0xFF777777);
        graphics.fill(x + 103, y + 49, x + 107, y + 53, lampColor);
    }

    private static void drawSlot(GuiGraphics graphics, int x, int y) {
        graphics.fill(x - 1, y - 1, x + 18, y + 18, SLOT_EDGE);
        graphics.fill(x, y, x + 17, y + 17, SLOT_SURFACE);
        graphics.fill(x + 1, y + 1, x + 16, y + 16, 0xFFC8C8C8);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, titleLabelX, titleLabelY, 0xFF404040, false);
        graphics.drawString(font, playerInventoryTitle, inventoryLabelX, inventoryLabelY, 0xFF404040, false);
        graphics.drawCenteredString(font, Component.translatable("gui.machinery_legend.converter_input"), 65, 38, 0xFF404040);

        graphics.drawString(font, Component.translatable("gui.machinery_legend.converter_energy"), 92, 8, 0xFF404040, false);
        graphics.drawString(font,
                Component.translatable("gui.machinery_legend.converter_energy_value", menu.getEnergy(), menu.getMaxEnergy()),
                92, 19, 0xFF555555, false);

        Component mode = Component.translatable(menu.isAutoMode()
                ? "gui.machinery_legend.converter_mode_auto"
                : "gui.machinery_legend.converter_mode_manual");
        int modeColor = menu.isAutoMode() ? 0xFF3F8F64 : 0xFF555555;
        graphics.drawString(font, mode, 8, 56, modeColor, false);
        if (menu.getRedstoneSignal() > 0) {
            graphics.drawString(font,
                    Component.translatable("gui.machinery_legend.converter_redstone", menu.getRedstoneSignal()),
                    92, 29, 0xFF8A3B30, false);
        }
    }

    @Override
    protected void renderTooltip(GuiGraphics graphics, int mouseX, int mouseY) {
        ItemStack input = menu.getInputStack();
        if (isHovering(56, 17, 18, 18, mouseX, mouseY) && !input.isEmpty()) {
            List<Component> tooltipComponents = new ArrayList<>(getTooltipFromContainerItem(input));
            tooltipComponents.add(Component.translatable("gui.machinery_legend.converter_item_count", input.getCount()));
            tooltipComponents.add(Component.translatable("gui.machinery_legend.converter_item_value", menu.getInputConversionValue()));
            tooltipComponents.add(Component.translatable("gui.machinery_legend.converter_item_total", menu.getInputTotalEnergy()));
            List<FormattedCharSequence> tooltip = tooltipComponents.stream()
                    .map(Component::getVisualOrderText)
                    .toList();
            graphics.renderTooltip(font, tooltip, mouseX, mouseY);
            return;
        }
        super.renderTooltip(graphics, mouseX, mouseY);
        if (isHovering(112, 39, 32, 7, mouseX, mouseY)) {
            graphics.renderTooltip(font,
                    Component.translatable("gui.machinery_legend.converter_energy_tooltip", menu.getEnergy(), menu.getMaxEnergy()),
                    mouseX, mouseY);
        }
    }
}
