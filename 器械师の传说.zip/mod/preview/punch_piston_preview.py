#!/usr/bin/env python3
"""Software isometric preview of the PunchPiston entity, mirroring pistonBox() face/UV defs."""
import math
from PIL import Image

TEX = "/tmp/piston_tex/assets/minecraft/textures/block"
side = Image.open(f"{TEX}/piston_side.png").convert("RGBA")
top = Image.open(f"{TEX}/piston_top.png").convert("RGBA")
bottom = Image.open(f"{TEX}/piston_bottom.png").convert("RGBA")
inner = Image.open(f"{TEX}/piston_inner.png").convert("RGBA")

def sample(img, u, v):
    px, py = img.size
    x = min(px - 1, max(0, int(u * px - 0.001)))
    y = min(py - 1, max(0, int(v * py - 0.001)))
    return img.getpixel((x, y))

def make_tex(img, u0, u1, v0, v1, res=64):
    out = Image.new("RGBA", (res, res))
    for yy in range(res):
        for xx in range(res):
            u = u0 + (u1 - u0) * xx / (res - 1)
            v = v0 + (v1 - v0) * yy / (res - 1)
            out.putpixel((xx, yy), sample(img, u, v))
    return out

def rot_basis(yaw_deg, pitch_deg):
    y, p = math.radians(yaw_deg), math.radians(pitch_deg)
    # camera basis: right, up, forward (in model space)
    # view: yaw about Y, then pitch about X
    def mul(m, v):
        return [sum(m[r][c] * v[c] for c in range(3)) for r in range(3)]
    Ry = [[math.cos(y), 0, -math.sin(y)], [0, 1, 0], [math.sin(y), 0, math.cos(y)]]
    Rx = [[1, 0, 0], [0, math.cos(p), -math.sin(p)], [0, math.sin(p), math.cos(p)]]
    R = mul(Rx, Ry)  # rows: right / (recomputed below)
    return Ry, Rx, mul

def project(p, Ry, Rx):
    v = [p[0], p[1], p[2]]
    # model -> rotated (Ry about Y then Rx about X): view coords (x right, y up-ish, z forward/into screen)
    vy = [sum(Ry[r][c] * v[c] for c in range(3)) for r in range(3)]
    vc = [sum(Rx[r][c] * vy[c] for c in range(3)) for r in range(3)]
    sx, sy, depth = vc
    return sx, -sy, depth  # screen y down

def draw_face(img, corners, tex, uv, shade):
    # corners: 4 model-space; uv: (u0,v0),(u1,v0),(u1,v1),(u0,v1)
    W, H = img.size
    pts = [project(c) for c in corners]
    (u00, u01), (u10, u11) = ((uv[0][0], uv[0][1]), (uv[1][0], uv[1][1]))
    # screen bbox
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    x0, x1 = min(xs), max(xs); y0, y1 = min(ys), max(ys)
    if x1 - x0 < 0.5 or y1 - y0 < 0.5:
        return
    res = 48
    # build warped texture: sample via inverse bilinear of parallelogram (affine since axonometric)
    A, B, C, D = pts
    ex1 = (B[0] - A[0], B[1] - A[1])  # u axis
    ex2 = (D[0] - A[0], D[1] - A[1])  # v axis
    det = ex1[0] * ex2[1] - ex1[1] * ex2[0]
    if abs(det) < 1e-6:
        return
    tile = make_tex(tex, u00, u10, u01, u11, res=48)
    px0, px1 = int(math.floor(x0)), int(math.ceil(x1))
    py0, py1 = int(math.floor(y0)), int(math.ceil(y1))
    crop = Image.new("RGBA", (px1 - px0, py1 - py0), (0, 0, 0, 0))
    for yy in range(crop.size[1]):
        for xx in range(crop.size[0]):
            sx, sy = px0 + xx + 0.5, py0 + yy + 0.5
            ddx, ddy = sx - A[0], sy - A[1]
            a = (ddx * ex2[1] - ddy * ex2[0]) / det
            b = (ddy * ex1[0] - ddx * ex1[1]) / det
            if -1e-3 <= a <= 1 + 1e-3 and -1e-3 <= b <= 1 + 1e-3:
                col = tile.getpixel((min(47, max(0, int(a * 47))), min(47, max(0, int(b * 47)))))
                col = (int(col[0] * shade), int(col[1] * shade), int(col[2] * shade), col[3])
                crop.putpixel((xx, yy), col)
    img.alpha_composite(crop, (px0, py0))

def box(faces_out, a0, a1, b0, b1, c0, c1, front_tex, back_tex, side_tex, draw_back, side_vmax):
    """Mirror pistonBox(): axis along z? Here generic with z-axis: corners in (x,y,z)."""
    X, Y, Z = a0, a1, b0, b1, c0, c1
    mn = dict(minX=X, maxX=x_, minZ=None)
def _add(faces, corners, tex, uv, depth, shade):
    faces.append((depth, corners, tex, uv, shade))

def piston_box(faces, minX, maxX, minY, maxY, minZ, maxZ, front, back, side, draw_back, side_vmax, uv_full=True):
    # Java face definitions, UVs: texturedQuad order c1..c4 with uv (u1,v1)(u2,v1)(u2,v2)(u1,v2)
    # front (north, z=minZ): c=(minX,minY,minZ),(maxX,minY,minZ),(maxX,maxY,minZ),(minX,maxY,minZ) uv (0,0)(1,0)(1,1)(0,1)
    _add(faces, [(minX,minY,minZ),(maxX,minY,minZ),(maxX,maxY,minZ),(minX,maxY,minZ)], front, ((0,0),(1,1)), (minZ*0), 1.0)
    if draw_back:
        _add(faces, [(maxX,minY,maxZ),(minX,minY,maxZ),(minX,maxY,maxZ),(maxX,maxY,maxZ)], back, ((0,0),(1,1)), maxZ, 0.72)
    # east: c=(maxX,minY,minZ),(maxX,maxY,minZ),(maxX,maxY,maxZ),(maxX,minY,maxZ) u along +y, v along +z [0,vmax]
    _add(faces, [(maxX,minY,minZ),(maxX,maxY,minZ),(maxX,maxY,maxZ),(maxX,minY,maxZ)], side, ((0,0),(1,side_vmax)), maxX, 0.86)
    # west
    _add(faces, [(minX,minY,minZ),(minX,maxY,minZ),(minX,maxY,maxZ),(minX,minY,maxZ)], side, ((0,0),(1,side_vmax)), minX, 0.86)
    # up
    _add(faces, [(minX,maxY,minZ),(maxX,maxY,minZ),(maxX,maxY,maxZ),(minX,maxY,maxZ)], side, ((0,0),(1,side_vmax)), maxY, 1.0)
    # down
    _add(faces, [(minX,minY,minZ),(maxX,minY,minZ),(maxX,minY,maxZ),(minX,minY,maxZ)], side, ((0,0),(1,side_vmax)), minY, 0.6)

def render_scene(path, extension, head_present, head_size=(0.05,0.95,0.05,0.95)):
    Ry, Rx, _ = None, None, None
    yaw = math.radians(38.0); pitch = math.radians(-24.0)
    Ry = [[math.cos(yaw),0,-math.sin(yaw)],[0,1,0],[math.sin(yaw),0,math.cos(yaw)]]
    Rx = [[1,0,0],[0,math.cos(pitch),-math.sin(pitch)],[0,math.sin(pitch),math.cos(pitch)]]
    faces = []
    PISTON_MIN, PISTON_MAX, HEAD_BACK, HEAD_THICK, ARM_HALF = 0.05, 0.95, 0.30, 0.25, 0.22
    piston_box(faces, PISTON_MIN, PISTON_MAX, PISTON_MIN, PISTON_MAX, HEAD_BACK, 0.95, inner, bottom, side, True, 1.0)
    if extension > 0.02:
        piston_box(faces, 0.5-ARM_HALF, 0.5+ARM_HALF, 0.5-ARM_HALF, 0.5+ARM_HALF,
                   HEAD_BACK-extension, HEAD_BACK, side, side, side, False, 0.25)
        if head_present:
            piston_box(faces, PISTON_MIN, PISTON_MAX, PISTON_MIN, PISTON_MAX,
                       HEAD_BACK-extension-HEAD_THICK, HEAD_BACK-extension, top, top, side, True, 0.25)
    elif head_present:
        piston_box(faces, PISTON_MIN, PISTON_MAX, PISTON_MIN, PISTON_MAX,
                   HEAD_BACK-HEAD_THICK, HEAD_BACK, top, top, side, True, 0.25)
    else:
        grow = 0.45
        half = 0.45*(grow**0.6); bump = 0.22*math.sin(math.pi*grow)
        fz = HEAD_BACK-HEAD_THICK-bump
        piston_box(faces, 0.5-half, 0.5+half, 0.5-half, 0.5+half, fz, fz+HEAD_THICK, top, top, side, True, 0.25)
    # project & sort
    proj = []
    for (d0, corners, tex, uv, depth, shade) in faces:
        pts = []
        for c in corners:
            v = [c[0]-0.5, c[1]-0.5, c[2]-0.5]
            vy = [sum(Ry[r][k]*v[k] for k in range(3)) for r in range(3)]
            vc = [sum(Rx[r][k]*vy[k] for k in range(3)) for r in range(3)]
            pts.append((vc[0], -vc[1], vc[2]))
        # signed area for culling
        a = pts
        area = 0.0
        for i in range(4):
            x1,y1,_ = a[i]; x2,y2,_ = a[(i+1)%4]
            area += x1*y2 - x2*y1
        if area > 0:  # back-facing given screen y down
            continue
        avg = sum(p[2] for p in pts)/4
        proj.append((avg, pts, tex, uv, shade))
    proj.sort(key=lambda t: -t[0])  # far first
    S = 420; SC = 190; OFF = S/2
    img = Image.new("RGBA", (S, S), (245, 245, 245, 255))
    def to_px(p): return (p[0]*SC+OFF, p[1]*SC+OFF)
    for avg, pts, tex, uv, shade in proj:
        c = [to_px(p) for p in pts]
        _draw_poly_tex(img, c, tex, uv, shade)
    img.convert("RGB").save(path)

def _draw_poly_tex(img, c, tex, uv, shade):
    (u00,v00),(u11,v11) = uv
    xs=[p[0] for p in c]; ys=[p[1] for p in c]
    x0,x1=int(math.floor(min(xs))),int(math.ceil(max(xs)))
    y0,y1=int(math.floor(min(ys))),int(math.ceil(max(ys)))
    A,B,C,D = c
    e1=(B[0]-A[0],B[1]-A[1]); e2=(D[0]-A[0],D[1]-A[1])
    det=e1[0]*e2[1]-e1[1]*e2[0]
    if abs(det)<1e-6: return
    inside=[]
    for yy in range(y0,y1):
        for xx in range(x0,x1):
            sx,sy=xx+0.5,yy+0.5
            # point-in-quad via edge cross
            inn=True
            for i in range(4):
                x1e,y1e=c[i]; x2e,y2e=c[(i+1)%4]
                if (x2e-x1e)*(sy-y1e)-(y2e-y1e)*(sx-x1e) < 0:
                    inn=False; break
            if not inn: continue
            ddx,ddy=sx-A[0],sy-A[1]
            a=(ddx*e2[1]-ddy*e2[0])/det; b=(ddy*e1[0]-ddx*e1[1])/det
            if -1e-3<=a<=1+1e-3 and -1e-3<=b<=1+1e-3:
                inside.append((xx,yy,a,b))
    px=[]
    for (xx,yy,a,b) in inside:
        u=u00+(u11-u00)*a; v=v00+(v11-v00)*b
        col=sample(tex,u,v)
        col=(int(col[0]*shade),int(col[1]*shade),int(col[2]*shade),255)
        px.append(((xx,y0 if False else yy),col))
    from PIL import ImageDraw
    for ((xx,yy),col) in px:
        img.putpixel((xx,yy),col)

if __name__ == "__main__":
    render_scene("/workspace/mod/preview/idle.png", 0.0, True)
    render_scene("/workspace/mod/preview/empowered.png", 2.6, True)
    render_scene("/workspace/mod/preview/nogrow.png", 0.0, False)
    print("done")
