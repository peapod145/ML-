import base64
import json
from pathlib import Path

from bbmodel import Model

m = Model("moonlight_sensor", tex_size=64)
m.region("stone", 0, 0, 32, 32)
m.region("plate", 32, 0, 64, 32)
m.fill("stone", (112, 116, 120))
m.fill("plate", (55, 64, 72))

base = m.group("sensor_base", origin=(8, 0, 8))
# 四个独立骨骼让升级时的四块翻盖可以分别绕外侧铰链翻起。
flaps = {
    "north_west": (2.0, 2.0, 5.4, 5.4, (3.7, 3.0, 5.4)),
    "north_east": (10.6, 2.0, 14.0, 5.4, (12.3, 3.0, 5.4)),
    "south_west": (2.0, 10.6, 5.4, 14.0, (3.7, 3.0, 10.6)),
    "south_east": (10.6, 10.6, 14.0, 14.0, (12.3, 3.0, 10.6)),
}
m.cube("base", (1.6, 0.0, 1.6), (14.4, 2.4, 14.4), tex="stone", parent=base)
for name, x0, z0, x1, z1, origin in (
    (name, x0, z0, x1, z1, origin)
    for name, (x0, z0, x1, z1, origin) in flaps.items()
):
    flap = m.group(name + "_flap", origin=origin, parent=base)
    m.cube(name, (x0, 2.4, z0), (x1, 3.0, z1), tex="plate", parent=flap)

upgrade = m.animation("upgrade", length=1.0, loop="once")
for name in flaps:
    bone = name + "_flap"
    # 北侧两块绕 X 轴向北翻起，南侧两块绕 X 轴向南翻起。
    rotation = (72, 0, 0) if name.startswith("north_") else (-72, 0, 0)
    upgrade.rot(bone, 0.0, (0, 0, 0))
    upgrade.rot(bone, 0.70, rotation, interp="catmullrom")
    upgrade.rot(bone, 1.0, rotation, interp="catmullrom")

output = Path("models/moonlight_sensor.bbmodel")
m.save(str(output))

# 将用户提供的 16x16 顶部贴图嵌入 bbmodel，并只给主体顶面使用它。
texture_path = Path("src/main/resources/assets/machinery_legend/textures/entity/moonlight_sensor_top.png")
data = json.loads(output.read_text(encoding="utf-8"))
base_element = next(element for element in data["elements"] if element.get("name") == "base")
base_element["faces"]["up"]["texture"] = 1
base_element["faces"]["up"]["uv"] = [0.0, 0.0, 16.0, 16.0]
raw = texture_path.read_bytes()
data["textures"].append({
    "path": "moonlight_sensor_top.png",
    "name": "moonlight_sensor_top.png",
    "folder": "",
    "namespace": "machinery_legend",
    "id": "1",
    "group": "",
    "width": 16,
    "height": 16,
    "uv_width": 16,
    "uv_height": 16,
    "particle": False,
    "use_as_default": False,
    "layers_enabled": False,
    "sync_to_project": "",
    "render_mode": "cutout",
    "render_sides": "auto",
    "frame_time": 1,
    "frame_order_type": "loop",
    "frame_order": "",
    "frame_interpolate": False,
    "visible": True,
    "internal": True,
    "saved": False,
    "uuid": "moonlight-sensor-top-texture",
    "relative_path": "../src/main/resources/assets/machinery_legend/textures/entity/moonlight_sensor_top.png",
    "source": "data:image/png;base64," + base64.b64encode(raw).decode("ascii"),
})
output.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
