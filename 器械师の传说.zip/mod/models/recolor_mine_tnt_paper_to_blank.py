#!/usr/bin/env python3
"""把“地雷TNT蓝图”物品的纸面颜色改成与“空白蓝图”一致。

背景：上一轮已让 mine_tnt_blueprint.png 的形状与 emitter_blueprint.png
逐像素一致，纸面被换成了米棕/卡其配色。本轮只改纸面颜色：
按阴影角色把 9 个纸面棕色一一映射到 blank_blueprint.png 里真实存在的
蓝色（主纸面->空白主色，暗描边->空白深蓝，高光->空白浅蓝……）。

中央红色圆徽记、右下红点、以及全部 alpha 轮廓保持逐像素不变。
"""
import os
from PIL import Image

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX_DIR = os.path.join(BASE, "src", "main", "resources", "assets",
                       "machinery_legend", "textures", "item")
DST = os.path.join(TEX_DIR, "mine_tnt_blueprint.png")
BLANK = os.path.join(TEX_DIR, "blank_blueprint.png")

# 纸面（米棕/卡其 -> 空白蓝图的纸面蓝，目标色均为 blank 调色板实际色）
PAPER_REMAP = {
    (160, 120, 80, 255): (80, 120, 240, 255),   # 纸面主体   -> 空白主色
    (200, 160, 120, 255): (40, 80, 200, 255),   # 中间调     -> 空白主阴影
    (120, 80, 40, 255): (0, 40, 120, 255),      # 深色描边   -> 空白描边
    (80, 80, 40, 255): (0, 40, 80, 255),        # 更暗描边   -> 空白深蓝
    (80, 40, 0, 255): (0, 0, 80, 255),          # 最深棕     -> 空白最深
    (160, 160, 120, 255): (40, 120, 200, 255),  # 卡其边缘   -> 空白中亮蓝
    (200, 200, 160, 255): (40, 120, 240, 255),  # 浅高光     -> 空白高光
    (240, 200, 160, 255): (80, 160, 240, 255),  # 亮高光     -> 空白亮高光
    (240, 240, 200, 255): (120, 200, 240, 255), # 最亮高光   -> 空白最亮
}

# 徽记/红点：保持地雷TNT的红，逐像素不动
KEEP = {
    (200, 160, 160, 255),  # 徽记主体（粉红弹体）
    (160, 120, 120, 255),  # 徽记暗缘
    (160, 80, 80, 255),    # 徽记暗红
    (200, 80, 80, 255),    # 徽记亮红
    (160, 40, 40, 255),    # 右下红点
}


def main():
    # 自检：目标色必须都在空白蓝图调色板里
    blank_pal = set(blank_px for blank_px in
                    Image.open(BLANK).convert("RGBA").getdata()
                    if blank_px[3] == 255)
    for tgt in PAPER_REMAP.values():
        assert tgt in blank_pal, f"target {tgt} not in blank palette"

    img = Image.open(DST).convert("RGBA")
    px = img.load()
    unmapped = set()
    changed = 0
    for y in range(img.height):
        for x in range(img.width):
            p = px[x, y]
            if p[3] == 0:
                continue
            if p in KEEP:
                continue
            if p not in PAPER_REMAP:
                unmapped.add(p)
                continue
            px[x, y] = PAPER_REMAP[p]
            changed += 1
    assert not unmapped, f"unexpected opaque colors: {unmapped}"
    before = img.copy()
    img.save(DST)

    # 核验：形状/徽记逐像素不变，纸面已全部换成空白蓝
    a = before.load()
    b = Image.open(DST).convert("RGBA").load()
    alpha_diff = sum(1 for y in range(16) for x in range(16)
                     if a[x, y][3] != b[x, y][3])
    emblem_diff = sum(1 for y in range(16) for x in range(16)
                      if a[x, y] in KEEP and a[x, y] != b[x, y])
    brown_left = sum(1 for y in range(16) for x in range(16)
                     if b[x, y] in PAPER_REMAP)
    paper_now_blank = all(b[x, y] in blank_pal or b[x, y][3] == 0
                          or b[x, y] in KEEP
                          for y in range(16) for x in range(16))
    print(f"saved {DST}")
    print(f"paper pixels recolored: {changed}")
    print(f"alpha mask differences: {alpha_diff}")
    print(f"emblem pixels altered: {emblem_diff}")
    print(f"brown paper pixels left: {brown_left}")
    print(f"all opaque colors in blank palette or kept emblem: {paper_now_blank}")
    assert alpha_diff == 0 and emblem_diff == 0 and brown_left == 0
    assert paper_now_blank


if __name__ == "__main__":
    main()
