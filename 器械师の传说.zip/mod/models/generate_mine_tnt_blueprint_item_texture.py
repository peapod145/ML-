#!/usr/bin/env python3
"""让“地雷TNT蓝图”物品纹理与“发射器蓝图”形状完全一致。

做法：直接以 emitter_blueprint.png 的像素网格为模板（倾斜纸张 +
边缘装订耳片的轮廓逐像素复制，连 alpha=0 的像素也原样保留），
只把颜色换成地雷TNT蓝图自己的配色：
  - 蓝色纸面  -> 地雷TNT的米棕/卡其纸面色
  - 中央浅蓝圆徽记 -> 地雷TNT的红色炸弹徽记（粉红主体+亮红中心）
  - 右下红点  -> 地雷TNT自己的暗红色
形状与发射器蓝图逐像素零差异，配色保持地雷TNT原样。
"""
import os
from PIL import Image

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX_DIR = os.path.join(BASE, "src", "main", "resources", "assets",
                       "machinery_legend", "textures", "item")
SRC = os.path.join(TEX_DIR, "emitter_blueprint.png")
DST = os.path.join(TEX_DIR, "mine_tnt_blueprint.png")

# 发射器纹理的不透明配色 -> 地雷TNT纹理自己的配色
# 纸张：深蓝描边->深棕，主蓝->主棕，亮蓝高光->浅米色
# 徽记：浅蓝圆->红色炸弹（#c8a0a0 主体、#c85050 亮红中心）
# 红点：#780028 -> #a02828（地雷TNT自己的暗红）
REMAP = {
    # ---- 纸张（蓝 -> 米棕系）----
    (0x28, 0x50, 0xc8, 255): (0xa0, 0x78, 0x50, 255),  # 纸面主体
    (0x00, 0x28, 0x78, 255): (0x78, 0x50, 0x28, 255),  # 深色描边
    (0x00, 0x28, 0xa0, 255): (0x78, 0x50, 0x28, 255),  # 次深描边
    (0x28, 0x28, 0xa0, 255): (0x78, 0x50, 0x28, 255),  # 次深描边
    (0x00, 0x50, 0xc8, 255): (0xc8, 0xa0, 0x78, 255),  # 中间调棕
    (0x00, 0x50, 0xa0, 255): (0xc8, 0xa0, 0x78, 255),  # 中间调棕
    (0x28, 0x50, 0xa0, 255): (0xa0, 0x78, 0x50, 255),  # 纸面主体
    (0x00, 0x28, 0x50, 255): (0x50, 0x50, 0x28, 255),  # 暗橄榄
    (0x28, 0x28, 0x78, 255): (0x50, 0x50, 0x28, 255),  # 暗橄榄
    (0x00, 0x00, 0x50, 255): (0x50, 0x28, 0x00, 255),  # 最深棕
    (0x50, 0x50, 0x78, 255): (0xa0, 0xa0, 0x78, 255),  # 卡其
    (0x28, 0x50, 0x78, 255): (0xa0, 0xa0, 0x78, 255),  # 卡其
    (0x28, 0x78, 0xc8, 255): (0xc8, 0xc8, 0xa0, 255),  # 浅卡其高光
    (0x28, 0x78, 0xf0, 255): (0xf0, 0xc8, 0xa0, 255),  # 浅米高光
    (0x28, 0x50, 0xf0, 255): (0xf0, 0xc8, 0xa0, 255),  # 浅米高光（左上边缘）
    (0x50, 0x78, 0xf0, 255): (0xf0, 0xf0, 0xc8, 255),  # 米白高光
    # ---- 中央圆徽记（浅蓝 -> 红色炸弹）----
    (0x50, 0x78, 0xc8, 255): (0xc8, 0xa0, 0xa0, 255),  # 徽记主体 -> 粉红弹体
    (0x78, 0x78, 0xc8, 255): (0xc8, 0x50, 0x50, 255),  # 最亮中心 -> 亮红
    (0x78, 0x78, 0xa0, 255): (0xa0, 0x50, 0x50, 255),  # 中心 -> 红
    (0x50, 0x50, 0xc8, 255): (0xa0, 0x78, 0x78, 255),  # 徽记边缘 -> 暗粉
    (0x50, 0x50, 0xa0, 255): (0xa0, 0x78, 0x78, 255),  # 徽记边缘 -> 暗粉
    # ---- 右下红点 ----
    (0x78, 0x00, 0x28, 255): (0xa0, 0x28, 0x28, 255),  # 红点 -> 地雷TNT暗红
}

def main():
    img = Image.open(SRC).convert("RGBA")
    px = img.load()
    unmapped = set()
    changed = 0
    for y in range(img.height):
        for x in range(img.width):
            p = px[x, y]
            if p[3] == 255:  # 不透明像素必须全部有映射
                if p not in REMAP:
                    unmapped.add(p)
                    continue
                if REMAP[p] != p:
                    px[x, y] = REMAP[p]
                    changed += 1
            # alpha=0 的像素原样保留，保证逐像素一致
    assert not unmapped, f"unmapped opaque colors: {unmapped}"
    img.save(DST)

    # 自检：两张纹理的 alpha 轮廓与不透明像素位置必须逐像素一致
    a = Image.open(SRC).convert("RGBA").load()
    b = Image.open(DST).convert("RGBA").load()
    sil = sum(1 for y in range(16) for x in range(16)
              if (a[x, y][3] == 0) != (b[x, y][3] == 0))
    alpha_exact = sum(1 for y in range(16) for x in range(16)
                      if a[x, y][3] != b[x, y][3])
    print(f"saved {DST}")
    print(f"pixels recolored: {changed}")
    print(f"silhouette mismatch pixels vs emitter: {sil}")
    print(f"alpha mask differences: {alpha_exact}")
    assert sil == 0 and alpha_exact == 0, "shape must match exactly"

if __name__ == "__main__":
    main()
