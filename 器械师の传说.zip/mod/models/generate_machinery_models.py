from bbmodel import Model


def base_model(name):
    m = Model(name, tex_size=64)
    m.region("wood", 0, 0, 24, 24)
    m.region("metal", 24, 0, 48, 24)
    m.region("dark", 48, 0, 64, 16)
    m.fill("wood", (126, 84, 48))
    m.fill("metal", (112, 116, 120))
    m.fill("dark", (38, 42, 48))
    return m


def emitter():
    m = base_model("emitter")
    support = m.group("support", origin=(8, 0, 8))
    head = m.group("dispenser", origin=(8, 8, 8), parent=support)
    m.cube("fence_post", (6, 0, 6), (10, 10, 10), tex="wood", parent=support)
    m.cube("fence_arm_x", (2, 7, 6), (14, 9, 10), tex="wood", parent=support)
    m.cube("fence_arm_z", (6, 7, 2), (10, 9, 14), tex="wood", parent=support)
    m.cube("dispenser_body", (1, 9, 1), (15, 16, 15), tex="metal", parent=head)
    m.cube("dispenser_face", (4, 11, -0.2), (12, 14, 1), tex="dark", parent=head)
    m.cube("nozzle", (6.5, 12, -2), (9.5, 14, 0), tex="metal", parent=head)
    m.save("models/emitter.bbmodel")


def furnace():
    m = base_model("furnace_machine")
    body = m.group("furnace", origin=(8, 0, 8))
    m.cube("furnace_body", (1, 0, 1), (15, 15, 15), tex="metal", parent=body)
    m.cube("front_panel", (4, 4, -0.2), (12, 12, 1), tex="dark", parent=body)
    m.cube("fire_core", (6, 6, -1), (10, 10, 0), tex="wood", parent=body)
    m.cube("chimney", (5, 15, 5), (11, 17, 11), tex="dark", parent=body)
    m.save("models/furnace_machine.bbmodel")


def obsidian():
    m = base_model("obsidian_machine")
    m.region("shell", 0, 24, 32, 56)
    m.fill("shell", (42, 38, 44))
    body = m.group("obsidian", origin=(8, 0, 8))
    shell = m.group("netherite_shell", origin=(8, 0, 8))
    m.cube("lower_core", (2, 0, 2), (14, 6, 14), tex="dark", parent=body)
    m.cube("upper_core", (3, 6, 3), (13, 14, 13), tex="dark", parent=body)
    m.cube("shell_lower", (1.7, -0.02, 1.7), (14.3, 6.1, 14.3), tex="shell", parent=shell, inflate=0.02)
    m.cube("shell_upper", (2.7, 5.9, 2.7), (13.3, 14.1, 13.3), tex="shell", parent=shell, inflate=0.02)
    m.cube("shell_rim", (2.2, 13.9, 2.2), (13.8, 14.5, 13.8), tex="shell", parent=shell, inflate=0.02)
    m.save("models/obsidian_machine.bbmodel")


emitter()
furnace()
obsidian()
