#!/usr/bin/env python3
"""让“月光传感器蓝图”物品纹理与“小型发射器蓝图”形状完全一致。

做法：直接以 small_emitter_blueprint.png 的像素网格为模板（倾斜纸张 +
边缘装订耳片的轮廓逐像素复制），只把中央圆形徽记的灰色替换为月光蓝图
自己的深色/青色传感器配色（505050 / 507878 / 78a0a0）。
纸张与耳片的棕米色系两个蓝图本来就共用，保持不变。
"""
import os
from PIL import Image

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX_DIR = os.path.join(BASE, "src", "main", "resources", "assets",
                       "machinery_legend", "textures", "item")
SRC = os.path.join(TEX_DIR, "small_emitter_blueprint.png")
DST = os.path.join(TEX_DIR, "moonlight_sensor_blueprint.png")

# 发射器徽记灰阶 -> 月光传感器徽记配色（与旧月光纹理的中央徽记一致）
REMAP = {
    (200, 200, 200, 255): (120, 160, 160, 255),  # c8c8c8 -> 78a0a0 青色高光
    (160, 160, 160, 255): ( 80, 120, 120, 255),  # a0a0a0 -> 507878 暗青
    (120, 120, 120, 255): ( 80,  80,  80, 255),  # 787878 -> 505050 深色主体
}

def main():
    img = Image.open(SRC).convert("RGBA")
    px = img.load()
    changed = 0
    for y in range(img.height):
        for x in range(img.width):
            p = px[x, y]
            if p in REMAP:
                px[x, y] = REMAP[p]
                changed += 1
    img.save(DST)

    # 自检：两张纹理的 alpha 轮廓必须逐像素一致
    a = Image.open(SRC).convert("RGBA").load()
    b = Image.open(DST).convert("RGBA").load()
    mismatch = sum(1 for y in range(16) for x in range(16)
                   if (a[x, y][3] == 0) != (b[x, y][3] == 0))
    print(f"saved {DST}")
    print(f"emblem pixels recolored: {changed}")
    print(f"silhouette mismatch pixels vs small_emitter: {mismatch}")
    assert mismatch == 0, "shape must match exactly"

if __name__ == "__main__":
    main()
