from __future__ import annotations

import base64
import io
import json
from pathlib import Path

from PIL import Image
from bbmodel import Model

ROOT = Path(__file__).resolve().parents[1]
SOURCE_TEXTURE = ROOT / "src/main/resources/assets/machinery_legend/textures/entity/ghost.png"
OUTPUT = ROOT / "models" / "ghost.bbmodel"


def uv_box(u: float, v: float, width: float, height: float, depth: float, mirror: bool = False):
    faces = {
        "north": (u + depth, v + depth, u + depth + width, v + depth + height),
        "east": (u, v + depth, u + depth, v + depth + height),
        "south": (u + depth + width + depth, v + depth, u + depth + width + depth + width, v + depth + height),
        "west": (u + depth + width, v + depth, u + depth + width + depth, v + depth + height),
        "up": (u + depth, v, u + depth + width, v + depth),
        "down": (u + depth + width, v, u + depth + width + width, v + depth),
    }
    if mirror:
        faces = {face: (x1, y0, x0, y1) for face, (x0, y0, x1, y1) in faces.items()}
    return faces


m = Model("ghost", tex_size=64)
root = m.group("root", origin=(8, 0, 8))
body = m.group("body", origin=(8, 24, 8), parent=root)
head = m.group("head", origin=(8, 24, 8), parent=root)
right_arm = m.group("right_arm", origin=(3, 22, 8), parent=root)
left_arm = m.group("left_arm", origin=(13, 22, 8), parent=root)
right_leg = m.group("right_leg", origin=(6, 12, 8), parent=root)
left_leg = m.group("left_leg", origin=(10, 12, 8), parent=root)

m.cube("body", (4, 12, 6), (12, 24, 10), uv=uv_box(16, 16, 8, 12, 4), parent=body)
m.cube("head", (4, 24, 4), (12, 32, 12), uv=uv_box(0, 0, 8, 8, 8), parent=head)
m.cube("right_arm", (2, 12, 7), (4, 24, 9), uv=uv_box(40, 16, 4, 12, 4), parent=right_arm)
m.cube("left_arm", (12, 12, 7), (14, 24, 9), uv=uv_box(40, 16, 4, 12, 4, mirror=True), parent=left_arm)
m.cube("right_leg", (5, 0, 7), (7, 12, 9), uv=uv_box(0, 16, 4, 12, 4), parent=right_leg)
m.cube("left_leg", (9, 0, 7), (11, 12, 9), uv=uv_box(0, 16, 4, 12, 4, mirror=True), parent=left_leg)

walk = m.animation("walk", length=1.0, loop="loop")
walk.rot("right_arm", 0.0, (-35, 0, 0))
walk.rot("right_arm", 0.5, (35, 0, 0))
walk.rot("right_arm", 1.0, (-35, 0, 0))
walk.rot("left_arm", 0.0, (35, 0, 0))
walk.rot("left_arm", 0.5, (-35, 0, 0))
walk.rot("left_arm", 1.0, (35, 0, 0))
walk.rot("right_leg", 0.0, (0, 0, 0))
walk.rot("right_leg", 1.0, (0, 0, 0))
walk.rot("left_leg", 0.0, (0, 0, 0))
walk.rot("left_leg", 1.0, (0, 0, 0))

m.save(str(OUTPUT))

data = json.loads(OUTPUT.read_text(encoding="utf-8"))
# 只转换 PNG 的存储色彩类型，逐像素 RGBA 值保持不变，供模型校验器读取。
with Image.open(SOURCE_TEXTURE) as source:
    rgba = source.convert("RGBA")
    memory = io.BytesIO()
    rgba.save(memory, format="PNG")
png = memory.getvalue()
encoded = base64.b64encode(png).decode("ascii")
data["resolution"] = {"width": 64, "height": 32}
texture = data["textures"][0]
texture["name"] = "ghost.png"
texture["path"] = "ghost.png"
texture["folder"] = "textures/entity"
texture["namespace"] = "machinery_legend"
texture["width"] = 64
texture["height"] = 32
texture["uv_width"] = 64
texture["uv_height"] = 32
texture["source"] = "data:image/png;base64," + encoded
OUTPUT.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
print(f"已生成 {OUTPUT}")
