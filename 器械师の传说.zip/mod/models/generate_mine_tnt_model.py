from bbmodel import Model

m = Model("mine_tnt", tex_size=64)
m.region("tnt", 0, 0, 32, 32)
m.region("plate", 32, 0, 48, 16)
m.region("dirt", 48, 0, 64, 16)
m.fill("tnt", (178, 38, 28))
m.fill("plate", (112, 112, 108))
m.fill("dirt", (111, 73, 39))

mine = m.group("mine", origin=(8, 0, 8))
tnt = m.group("tnt", origin=(8, 0, 8), parent=mine)
plate = m.group("pressure_plate", origin=(8, 0, 8), parent=tnt)
dirt = m.group("dirt_bits", origin=(8, 0, 8), parent=mine)

# Emerged silhouette: low dirt clods form a grounded ring outside the TNT footprint.
# The clods start at y=0 so they sit on the terrain instead of floating.
for name, box in [
    ("dirt_north_left", (1, 0, -2, 5, 2, 0)),
    ("dirt_north_center", (6, 0, -1, 10, 1.5, 0)),
    ("dirt_north_right", (11, 0, -2, 15, 2.5, 0)),
    ("dirt_south_left", (1, 0, 16, 5, 1.5, 18)),
    ("dirt_south_center", (6, 0, 16, 10, 2, 17.5)),
    ("dirt_south_right", (11, 0, 16, 15, 2.2, 18)),
    ("dirt_west_north", (-2, 0, 1, 0, 2.2, 5)),
    ("dirt_west_center", (-1, 0, 6, 0, 1.2, 10)),
    ("dirt_west_south", (-2, 0, 11, 0, 2, 15)),
    ("dirt_east_north", (16, 0, 1, 18, 2.4, 5)),
    ("dirt_east_center", (16, 0, 6, 17.5, 1.3, 10)),
    ("dirt_east_south", (16, 0, 11, 18, 2.1, 15)),
]:
    m.cube(name, box[:3], box[3:], tex="dirt", parent=dirt)

# Emerged silhouette: a ground-level TNT with a stone pressure plate on top.
# The animation moves the whole TNT group down by 6 units for the buried state.
m.cube("tnt_body", (1, 0, 1), (15, 16, 15), tex="tnt", parent=tnt)
m.cube("plate_top", (0, 16, 0), (16, 17, 16), tex="plate", parent=plate)

emerge = m.animation("emerge", length=15.0, loop="once")
emerge.pos("tnt", 0.0, (0, -6.0, 0))
emerge.pos("tnt", 15.0, (0, 0.0, 0))

m.save("models/mine_tnt.bbmodel")
