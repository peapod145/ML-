from bbmodel import Model


m = Model("mine_field", tex_size=64)
m.region("iron", 0, 0, 24, 24)
m.region("dark", 24, 0, 48, 24)
m.region("accent", 48, 0, 64, 16)
m.region("drill", 0, 24, 24, 48)
m.fill("iron", (118, 124, 128))
m.fill("dark", (35, 40, 46))
m.fill("accent", (184, 76, 28))
m.fill("drill", (164, 173, 178))

base = m.group("base", origin=(8, 0, 8))
front = m.group("front", origin=(8, 8, 1), parent=base)
drive = m.group("drive", origin=(8, 11, 8), parent=base)

# Low, wide chassis matching the compact silhouette in the reference sprite.
m.cube("base_plate", (0.5, 0, 0.5), (15.5, 2.5, 15.5), tex="dark", parent=base)
m.cube("lower_skirt", (1.5, 2.2, 1.5), (14.5, 4, 14.5), tex="iron", parent=base)
m.cube("left_frame", (1.5, 3.5, 2), (4.0, 13, 14), tex="iron", parent=base)
m.cube("right_frame", (12, 3.5, 2), (14.5, 13, 14), tex="iron", parent=base)
m.cube("rear_frame", (4, 3.5, 12), (12, 13, 14), tex="dark", parent=base)
m.cube("top_left_rail", (2, 12, 2), (7, 14, 4), tex="dark", parent=base)
m.cube("top_right_rail", (9, 12, 2), (14, 14, 4), tex="dark", parent=base)

# Recessed orange service panel and dark intake on the north-facing side.
m.cube("front_housing", (4, 4, 1), (12, 11.5, 3.5), tex="iron", parent=front)
m.cube("panel_top", (4.1, 10, 0.7), (11.9, 11.4, 1.0), tex="accent", parent=front, inflate=0.02)
m.cube("panel_bottom", (4.1, 4.1, 0.7), (11.9, 5.5, 1.0), tex="accent", parent=front, inflate=0.02)
m.cube("panel_left", (4.1, 5.3, 0.7), (5.5, 10.2, 1.0), tex="accent", parent=front, inflate=0.02)
m.cube("panel_right", (10.5, 5.3, 0.7), (11.9, 10.2, 1.0), tex="accent", parent=front, inflate=0.02)
m.cube("intake_grille", (5.45, 5.35, 0.55), (10.55, 10.15, 0.85), tex="dark", parent=front, inflate=0.025)
m.cube("warning_lamp", (6.5, 5.8, 0.45), (9.5, 6.7, 0.75), tex="accent", parent=front, inflate=0.04)

# Centered top drive and stepped steel drill, all below the 16-unit block ceiling.
m.cube("drive_mount", (5.5, 11.5, 5), (10.5, 13.5, 11), tex="iron", parent=drive)
m.cube("drive_ring", (6.2, 13.2, 5.7), (9.8, 14.1, 10.3), tex="accent", parent=drive, inflate=0.01)
m.cube("drill_shaft", (7, 13.8, 7), (9, 15.1, 9), tex="dark", parent=drive)
m.cube("drill_tip", (6.4, 14.6, 6.4), (9.6, 15.9, 9.6), tex="drill", parent=drive, inflate=0.01)
m.cube("redstone_pipe", (3.8, 4.2, 3.8), (4.9, 11.8, 4.9), tex="accent", parent=base)

idle = m.animation("idle", length=1.0, loop="loop")
idle.rot("drive", 0.0, (0, 0, 0))
idle.rot("drive", 0.5, (0, 180, 0))
idle.rot("drive", 1.0, (0, 360, 0))

m.save("models/mine_field.bbmodel")
