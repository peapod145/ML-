import os

from bbmodel import Model
from pngio import read_png

m = Model("sniper_emitter", tex_size=64)

# 五张 16×16 面贴图按固定区域嵌入模型图集，保持原始像素密度。
regions = {
    "top_bottom": (0, 0, "sniper_emitter_top_bottom.png"),
    "sides": (16, 0, "sniper_emitter_sides.png"),
    "front": (32, 0, "sniper_emitter_front.png"),
    "back": (48, 0, "sniper_emitter_back.png"),
    "fence": (0, 16, "sniper_emitter_fence.png"),
}
for name, (x0, y0, filename) in regions.items():
    m.region(name, x0, y0, x0 + 16, y0 + 16)
    width, height, pixels = read_png(os.path.join(
        "src", "main", "resources", "assets", "machinery_legend", "textures", "entity", filename))
    assert (width, height) == (16, 16), f"{filename}: 需要 16×16，实际为 {width}×{height}"
    for y, row in enumerate(pixels):
        for x, pixel in enumerate(row):
            m.tex[y0 + y][x0 + x] = pixel

body_faces = {
    "north": "front", "east": "sides", "south": "back", "west": "sides",
    "up": "top_bottom", "down": "top_bottom",
}

# 严格复刻游戏中普通发射器的两块结构：无连接的橡木栅栏柱位于下方，
# 完整 16×16×16 发射器方块位于上方。只替换各面的贴图，不增加额外几何。
support = m.group("support", origin=(8, 0, 8))
head = m.group("dispenser", origin=(8, 16, 8), parent=support)
m.cube("fence_post", (6, 0, 6), (10, 16, 10), tex="fence", parent=support)
m.cube("dispenser_body", (0, 16, 0), (16, 32, 16), tex=body_faces, parent=head)

m.save("models/sniper_emitter.bbmodel")
