from collections import deque
from PIL import Image
import os

TEX = ("/workspace/mod/src/main/resources/assets"
       "/machinery_legend/textures/item")
OUT = "/workspace/mod/models/bp_preview"
